import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { subscriptionService, usageService, DbSubscription, DbUsageTracking, DbSubscriptionPlan } from '@/lib/database';
import { toast } from '@/components/ui/use-toast';
import {
  UserIcon,
  CreditCardIcon,
  ReceiptIcon,
  BarChartIcon,
  CalendarIcon,
  DownloadIcon,
  TrendingUpIcon,
  ShieldIcon,
  StarIcon,
  ZapIcon,
  ClockIcon,
  MessageSquareIcon,
  ChevronRightIcon,
  AlertCircleIcon,
  CheckIcon,
  CloseIcon,
  PlusIcon,
  TrashIcon,
  EditIcon,
  EarIcon,
  HeartIcon,
  ArrowUpIcon,
  HandsIcon,
  VideoIcon,
} from '@/components/icons/Icons';

// Types
interface BillingHistoryItem {
  id: string;
  date: string;
  description: string;
  amount: number;
  status: 'paid' | 'pending' | 'failed';
  invoiceUrl?: string;
}

interface PaymentMethod {
  id: string;
  type: 'card' | 'bank';
  last4: string;
  brand?: string;
  expiryMonth?: number;
  expiryYear?: number;
  isDefault: boolean;
}

interface UsageDataPoint {
  date: string;
  minutes: number;
  calls: number;
  messages: number;
  aslTranslations: number;
}

interface ExportSettings {
  format: 'csv' | 'pdf';
  dataTypes: {
    usage: boolean;
    conversations: boolean;
    billing: boolean;
  };
  dateRange: {
    start: string;
    end: string;
  };
}

interface ScheduledReport {
  id: string;
  email: string;
  frequency: 'monthly' | 'weekly';
  dataTypes: string[];
  format: 'csv' | 'pdf';
  nextSendDate: string;
  isActive: boolean;
}

// Mock data for demonstration
const mockBillingHistory: BillingHistoryItem[] = [
  { id: '1', date: '2025-12-01', description: 'Pro Plan - Monthly', amount: 999, status: 'paid', invoiceUrl: '#' },
  { id: '2', date: '2025-11-01', description: 'Pro Plan - Monthly', amount: 999, status: 'paid', invoiceUrl: '#' },
  { id: '3', date: '2025-10-01', description: 'Pro Plan - Monthly', amount: 999, status: 'paid', invoiceUrl: '#' },
  { id: '4', date: '2025-09-01', description: 'Pro Plan - Monthly', amount: 999, status: 'paid', invoiceUrl: '#' },
  { id: '5', date: '2025-08-01', description: 'Free Plan Upgrade', amount: 0, status: 'paid' },
];

const mockPaymentMethods: PaymentMethod[] = [
  { id: '1', type: 'card', last4: '4242', brand: 'Visa', expiryMonth: 12, expiryYear: 2027, isDefault: true },
  { id: '2', type: 'card', last4: '5555', brand: 'Mastercard', expiryMonth: 6, expiryYear: 2026, isDefault: false },
];

const mockUsageHistory: UsageDataPoint[] = [
  { date: '2025-12-14', minutes: 45, calls: 3, messages: 120, aslTranslations: 15 },
  { date: '2025-12-15', minutes: 62, calls: 4, messages: 89, aslTranslations: 22 },
  { date: '2025-12-16', minutes: 38, calls: 2, messages: 156, aslTranslations: 8 },
  { date: '2025-12-17', minutes: 95, calls: 6, messages: 201, aslTranslations: 31 },
  { date: '2025-12-18', minutes: 72, calls: 5, messages: 178, aslTranslations: 19 },
  { date: '2025-12-19', minutes: 58, calls: 4, messages: 145, aslTranslations: 25 },
  { date: '2025-12-20', minutes: 28, calls: 2, messages: 67, aslTranslations: 12 },
];

const mockScheduledReports: ScheduledReport[] = [
  {
    id: '1',
    email: 'user@example.com',
    frequency: 'monthly',
    dataTypes: ['usage', 'billing'],
    format: 'pdf',
    nextSendDate: '2026-01-01',
    isActive: true,
  },
];

// Mail Icon Component
const MailIcon: React.FC<{ size?: number; className?: string }> = ({ size = 24, className = '' }) => (
  <svg xmlns="http://www.w3.org/2000/svg" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <rect width="20" height="16" x="2" y="4" rx="2" />
    <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" />
  </svg>
);

// FileText Icon Component
const FileTextIcon: React.FC<{ size?: number; className?: string }> = ({ size = 24, className = '' }) => (
  <svg xmlns="http://www.w3.org/2000/svg" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z" />
    <polyline points="14 2 14 8 20 8" />
    <line x1="16" x2="8" y1="13" y2="13" />
    <line x1="16" x2="8" y1="17" y2="17" />
    <line x1="10" x2="8" y1="9" y2="9" />
  </svg>
);

const AccountDashboard: React.FC = () => {
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const navigate = useNavigate();
  
  const [activeTab, setActiveTab] = useState<'overview' | 'billing' | 'payment' | 'usage' | 'export'>('overview');
  const [subscription, setSubscription] = useState<DbSubscription | null>(null);
  const [currentPlan, setCurrentPlan] = useState<DbSubscriptionPlan | null>(null);
  const [plans, setPlans] = useState<DbSubscriptionPlan[]>([]);
  const [usage, setUsage] = useState<DbUsageTracking | null>(null);
  const [billingHistory, setBillingHistory] = useState<BillingHistoryItem[]>(mockBillingHistory);
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>(mockPaymentMethods);
  const [usageHistory, setUsageHistory] = useState<UsageDataPoint[]>(mockUsageHistory);
  const [isLoading, setIsLoading] = useState(true);
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);
  const [showAddPaymentModal, setShowAddPaymentModal] = useState(false);
  
  // Export state
  const [exportSettings, setExportSettings] = useState<ExportSettings>({
    format: 'csv',
    dataTypes: {
      usage: true,
      conversations: false,
      billing: false,
    },
    dateRange: {
      start: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      end: new Date().toISOString().split('T')[0],
    },
  });
  const [isExporting, setIsExporting] = useState(false);
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [scheduledReports, setScheduledReports] = useState<ScheduledReport[]>(mockScheduledReports);
  const [newSchedule, setNewSchedule] = useState({
    email: '',
    frequency: 'monthly' as 'monthly' | 'weekly',
    dataTypes: ['usage'],
    format: 'pdf' as 'csv' | 'pdf',
  });

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      navigate('/');
      toast({
        title: 'Authentication Required',
        description: 'Please sign in to access your account dashboard.',
        variant: 'destructive',
      });
    }
  }, [authLoading, isAuthenticated, navigate]);

  useEffect(() => {
    const loadData = async () => {
      if (!user) return;
      
      setIsLoading(true);
      try {
        const plansData = await subscriptionService.getPlans();
        setPlans(plansData);
        
        const subData = await subscriptionService.getUserSubscription(user.id);
        setSubscription(subData);
        
        if (subData?.plan_id) {
          const plan = plansData.find(p => p.id === subData.plan_id);
          setCurrentPlan(plan || null);
        } else {
          const freePlan = plansData.find(p => p.price_cents === 0);
          setCurrentPlan(freePlan || null);
        }
        
        const usageData = await usageService.getUsage(user.id);
        setUsage(usageData);
        
      } catch (error) {
        console.error('Error loading dashboard data:', error);
      } finally {
        setIsLoading(false);
      }
    };
    
    loadData();
  }, [user]);

  const handleCancelSubscription = async () => {
    if (!user || !subscription) return;
    
    try {
      const { data, error } = await supabase.functions.invoke('manage-subscription', {
        body: { action: 'cancel', userId: user.id },
      });
      
      if (error) throw error;
      
      toast({
        title: 'Subscription Cancelled',
        description: 'Your subscription will remain active until the end of the billing period.',
      });
      
      setShowCancelModal(false);
      const subData = await subscriptionService.getUserSubscription(user.id);
      setSubscription(subData);
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to cancel subscription',
        variant: 'destructive',
      });
    }
  };

  // Export Functions
  const generateCSV = (data: any[], headers: string[]): string => {
    const csvRows = [headers.join(',')];
    data.forEach(row => {
      const values = headers.map(header => {
        const value = row[header.toLowerCase().replace(/ /g, '')] || row[header] || '';
        return `"${String(value).replace(/"/g, '""')}"`;
      });
      csvRows.push(values.join(','));
    });
    return csvRows.join('\n');
  };

  const downloadFile = (content: string, filename: string, mimeType: string) => {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleExport = async () => {
    setIsExporting(true);
    
    try {
      const { format, dataTypes, dateRange } = exportSettings;
      const exportData: any = {};
      
      // Filter data by date range
      const startDate = new Date(dateRange.start);
      const endDate = new Date(dateRange.end);
      
      if (dataTypes.usage) {
        const filteredUsage = usageHistory.filter(item => {
          const itemDate = new Date(item.date);
          return itemDate >= startDate && itemDate <= endDate;
        });
        exportData.usage = filteredUsage;
      }
      
      if (dataTypes.billing) {
        const filteredBilling = billingHistory.filter(item => {
          const itemDate = new Date(item.date);
          return itemDate >= startDate && itemDate <= endDate;
        });
        exportData.billing = filteredBilling;
      }
      
      if (dataTypes.conversations) {
        // Mock conversation data
        exportData.conversations = [
          { date: '2025-12-20', duration: '15 min', participants: 2, type: 'Video Call' },
          { date: '2025-12-19', duration: '8 min', participants: 2, type: 'Voice Call' },
          { date: '2025-12-18', duration: '22 min', participants: 3, type: 'Video Call' },
        ];
      }
      
      if (format === 'csv') {
        // Generate separate CSV files for each data type
        if (exportData.usage && exportData.usage.length > 0) {
          const csv = generateCSV(exportData.usage, ['date', 'minutes', 'calls', 'messages', 'aslTranslations']);
          downloadFile(csv, `bridgetalk-usage-${dateRange.start}-to-${dateRange.end}.csv`, 'text/csv');
        }
        
        if (exportData.billing && exportData.billing.length > 0) {
          const csv = generateCSV(exportData.billing, ['date', 'description', 'amount', 'status']);
          downloadFile(csv, `bridgetalk-billing-${dateRange.start}-to-${dateRange.end}.csv`, 'text/csv');
        }
        
        if (exportData.conversations && exportData.conversations.length > 0) {
          const csv = generateCSV(exportData.conversations, ['date', 'duration', 'participants', 'type']);
          downloadFile(csv, `bridgetalk-conversations-${dateRange.start}-to-${dateRange.end}.csv`, 'text/csv');
        }
      } else {
        // Generate PDF-like text report
        let pdfContent = `BridgeTalk Data Export Report\n`;
        pdfContent += `Generated: ${new Date().toLocaleString()}\n`;
        pdfContent += `Date Range: ${dateRange.start} to ${dateRange.end}\n`;
        pdfContent += `${'='.repeat(50)}\n\n`;
        
        if (exportData.usage && exportData.usage.length > 0) {
          pdfContent += `USAGE DATA\n${'-'.repeat(30)}\n`;
          exportData.usage.forEach((item: UsageDataPoint) => {
            pdfContent += `Date: ${item.date}\n`;
            pdfContent += `  Minutes: ${item.minutes}, Calls: ${item.calls}, Messages: ${item.messages}, ASL: ${item.aslTranslations}\n`;
          });
          pdfContent += '\n';
        }
        
        if (exportData.billing && exportData.billing.length > 0) {
          pdfContent += `BILLING HISTORY\n${'-'.repeat(30)}\n`;
          exportData.billing.forEach((item: BillingHistoryItem) => {
            pdfContent += `Date: ${item.date} - ${item.description} - $${(item.amount / 100).toFixed(2)} (${item.status})\n`;
          });
          pdfContent += '\n';
        }
        
        if (exportData.conversations && exportData.conversations.length > 0) {
          pdfContent += `CONVERSATION HISTORY\n${'-'.repeat(30)}\n`;
          exportData.conversations.forEach((item: any) => {
            pdfContent += `Date: ${item.date} - ${item.type} - ${item.duration} - ${item.participants} participants\n`;
          });
        }
        
        downloadFile(pdfContent, `bridgetalk-report-${dateRange.start}-to-${dateRange.end}.txt`, 'text/plain');
      }
      
      toast({
        title: 'Export Successful',
        description: `Your data has been exported as ${format.toUpperCase()}.`,
      });
    } catch (error) {
      toast({
        title: 'Export Failed',
        description: 'There was an error exporting your data. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsExporting(false);
    }
  };

  const handleScheduleReport = () => {
    if (!newSchedule.email) {
      toast({
        title: 'Email Required',
        description: 'Please enter an email address for the scheduled report.',
        variant: 'destructive',
      });
      return;
    }
    
    const nextDate = new Date();
    if (newSchedule.frequency === 'monthly') {
      nextDate.setMonth(nextDate.getMonth() + 1);
      nextDate.setDate(1);
    } else {
      nextDate.setDate(nextDate.getDate() + 7);
    }
    
    const newReport: ScheduledReport = {
      id: Date.now().toString(),
      email: newSchedule.email,
      frequency: newSchedule.frequency,
      dataTypes: newSchedule.dataTypes,
      format: newSchedule.format,
      nextSendDate: nextDate.toISOString().split('T')[0],
      isActive: true,
    };
    
    setScheduledReports([...scheduledReports, newReport]);
    setShowScheduleModal(false);
    setNewSchedule({
      email: user?.email || '',
      frequency: 'monthly',
      dataTypes: ['usage'],
      format: 'pdf',
    });
    
    toast({
      title: 'Report Scheduled',
      description: `Your ${newSchedule.frequency} report will be sent to ${newSchedule.email}.`,
    });
  };

  const toggleReportActive = (id: string) => {
    setScheduledReports(reports =>
      reports.map(report =>
        report.id === id ? { ...report, isActive: !report.isActive } : report
      )
    );
  };

  const deleteScheduledReport = (id: string) => {
    setScheduledReports(reports => reports.filter(report => report.id !== id));
    toast({
      title: 'Report Deleted',
      description: 'The scheduled report has been removed.',
    });
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const formatCurrency = (cents: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(cents / 100);
  };

  if (authLoading || isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-[#00bfa5] border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  // Calculate usage stats
  const totalMinutesThisMonth = usageHistory.reduce((sum, d) => sum + d.minutes, 0);
  const totalCallsThisMonth = usageHistory.reduce((sum, d) => sum + d.calls, 0);
  const totalMessagesThisMonth = usageHistory.reduce((sum, d) => sum + d.messages, 0);
  const totalASLThisMonth = usageHistory.reduce((sum, d) => sum + d.aslTranslations, 0);
  const maxMinutes = currentPlan?.limits?.call_minutes || 30;
  const usagePercentage = Math.min((totalMinutesThisMonth / maxMinutes) * 100, 100);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      {/* Header */}
      <header className="bg-[#1a2332] text-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 sm:h-20">
            <a href="/" className="flex items-center gap-3">
              <div className="relative">
                <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-[#00bfa5] to-[#00897b] rounded-xl flex items-center justify-center shadow-lg">
                  <EarIcon className="text-white" size={24} />
                </div>
                <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-[#ff6b35] rounded-full flex items-center justify-center">
                  <HeartIcon className="text-white" size={10} />
                </div>
              </div>
              <div>
                <h1 className="text-xl sm:text-2xl font-bold tracking-tight">
                  Bridge<span className="text-[#00bfa5]">Talk</span>
                </h1>
                <p className="text-xs text-gray-400 hidden sm:block">Account Dashboard</p>
              </div>
            </a>
            
            <div className="flex items-center gap-4">
              <div className="text-right hidden sm:block">
                <p className="text-sm font-medium">{user?.displayName || user?.email?.split('@')[0]}</p>
                <p className="text-xs text-gray-400">{user?.email}</p>
              </div>
              <div className="w-10 h-10 bg-gradient-to-br from-[#00bfa5] to-[#00897b] rounded-full flex items-center justify-center">
                <UserIcon className="text-white" size={20} />
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Navigation Tabs */}
        <div className="flex flex-wrap gap-2 mb-8">
          {[
            { id: 'overview', label: 'Overview', icon: UserIcon },
            { id: 'billing', label: 'Billing History', icon: ReceiptIcon },
            { id: 'payment', label: 'Payment Methods', icon: CreditCardIcon },
            { id: 'usage', label: 'Usage Analytics', icon: BarChartIcon },
            { id: 'export', label: 'Data Export', icon: DownloadIcon },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl font-medium transition-all duration-200 ${
                activeTab === tab.id
                  ? 'bg-[#00bfa5] text-white shadow-lg'
                  : 'bg-white text-gray-600 hover:bg-gray-50 border border-gray-200'
              }`}
            >
              <tab.icon size={18} />
              {tab.label}
            </button>
          ))}
        </div>

        {/* Overview Tab */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {/* Subscription Card */}
            <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
              <div className="bg-gradient-to-r from-[#00bfa5] to-[#00897b] p-6 text-white">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm opacity-80">Current Plan</p>
                    <h2 className="text-3xl font-bold">{currentPlan?.name || 'Free'}</h2>
                    <p className="text-sm opacity-80 mt-1">
                      {currentPlan?.price_cents ? `${formatCurrency(currentPlan.price_cents)}/month` : 'No charge'}
                    </p>
                  </div>
                  <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center">
                    {currentPlan?.name === 'Enterprise' ? (
                      <ZapIcon size={32} />
                    ) : currentPlan?.name === 'Pro' ? (
                      <StarIcon size={32} />
                    ) : (
                      <ShieldIcon size={32} />
                    )}
                  </div>
                </div>
              </div>
              
              <div className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="font-semibold text-gray-800 mb-3">Plan Features</h3>
                    <ul className="space-y-2">
                      {currentPlan?.features?.map((feature, idx) => (
                        <li key={idx} className="flex items-center gap-2 text-sm text-gray-600">
                          <CheckIcon size={16} className="text-[#00bfa5]" />
                          {feature}
                        </li>
                      )) || (
                        <>
                          <li className="flex items-center gap-2 text-sm text-gray-600">
                            <CheckIcon size={16} className="text-[#00bfa5]" />
                            30 minutes of calls per month
                          </li>
                          <li className="flex items-center gap-2 text-sm text-gray-600">
                            <CheckIcon size={16} className="text-[#00bfa5]" />
                            Basic speech-to-text
                          </li>
                          <li className="flex items-center gap-2 text-sm text-gray-600">
                            <CheckIcon size={16} className="text-[#00bfa5]" />
                            Standard video quality
                          </li>
                        </>
                      )}
                    </ul>
                  </div>
                  
                  <div>
                    <h3 className="font-semibold text-gray-800 mb-3">Subscription Details</h3>
                    <div className="space-y-3">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-500">Status</span>
                        <span className={`font-medium ${
                          subscription?.status === 'active' ? 'text-green-600' : 
                          subscription?.status === 'canceled' ? 'text-red-600' : 'text-gray-600'
                        }`}>
                          {subscription?.status ? subscription.status.charAt(0).toUpperCase() + subscription.status.slice(1) : 'Active'}
                        </span>
                      </div>
                      {subscription?.current_period_end && (
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-500">Next billing date</span>
                          <span className="font-medium text-gray-800">
                            {formatDate(subscription.current_period_end)}
                          </span>
                        </div>
                      )}
                      {subscription?.cancel_at_period_end && (
                        <div className="flex items-center gap-2 p-3 bg-amber-50 rounded-lg">
                          <AlertCircleIcon size={16} className="text-amber-600" />
                          <span className="text-sm text-amber-700">
                            Your subscription will end on {formatDate(subscription.current_period_end!)}
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                
                <div className="flex flex-wrap gap-3 mt-6 pt-6 border-t border-gray-100">
                  {currentPlan?.price_cents === 0 ? (
                    <button
                      onClick={() => setShowUpgradeModal(true)}
                      className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-[#00bfa5] to-[#00897b] text-white rounded-xl font-semibold hover:shadow-lg transition-all duration-200"
                    >
                      <ArrowUpIcon size={18} />
                      Upgrade Plan
                    </button>
                  ) : (
                    <>
                      <button
                        onClick={() => setShowUpgradeModal(true)}
                        className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-[#00bfa5] to-[#00897b] text-white rounded-xl font-semibold hover:shadow-lg transition-all duration-200"
                      >
                        <ArrowUpIcon size={18} />
                        Change Plan
                      </button>
                      {!subscription?.cancel_at_period_end && (
                        <button
                          onClick={() => setShowCancelModal(true)}
                          className="flex items-center gap-2 px-6 py-3 border border-red-200 text-red-600 rounded-xl font-semibold hover:bg-red-50 transition-all duration-200"
                        >
                          <CloseIcon size={18} />
                          Cancel Subscription
                        </button>
                      )}
                    </>
                  )}
                </div>
              </div>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-white rounded-xl p-5 shadow-md">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                    <ClockIcon size={24} className="text-blue-600" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-gray-800">{totalMinutesThisMonth}</p>
                    <p className="text-sm text-gray-500">Minutes Used</p>
                  </div>
                </div>
                <div className="mt-3">
                  <div className="flex justify-between text-xs text-gray-500 mb-1">
                    <span>{totalMinutesThisMonth} / {maxMinutes === -1 ? '∞' : maxMinutes}</span>
                    <span>{maxMinutes === -1 ? 'Unlimited' : `${usagePercentage.toFixed(0)}%`}</span>
                  </div>
                  <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                    <div 
                      className={`h-full rounded-full transition-all duration-500 ${
                        usagePercentage > 80 ? 'bg-red-500' : usagePercentage > 50 ? 'bg-amber-500' : 'bg-[#00bfa5]'
                      }`}
                      style={{ width: maxMinutes === -1 ? '30%' : `${usagePercentage}%` }}
                    />
                  </div>
                </div>
              </div>
              
              <div className="bg-white rounded-xl p-5 shadow-md">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                    <VideoIcon size={24} className="text-purple-600" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-gray-800">{totalCallsThisMonth}</p>
                    <p className="text-sm text-gray-500">Calls Made</p>
                  </div>
                </div>
              </div>
              
              <div className="bg-white rounded-xl p-5 shadow-md">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                    <MessageSquareIcon size={24} className="text-green-600" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-gray-800">{totalMessagesThisMonth}</p>
                    <p className="text-sm text-gray-500">Messages Sent</p>
                  </div>
                </div>
              </div>
              
              <div className="bg-white rounded-xl p-5 shadow-md">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center">
                    <HandsIcon size={24} className="text-orange-600" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-gray-800">{totalASLThisMonth}</p>
                    <p className="text-sm text-gray-500">ASL Translations</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Billing History Tab */}
        {activeTab === 'billing' && (
          <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
            <div className="p-6 border-b border-gray-100">
              <h2 className="text-xl font-bold text-gray-800">Billing History</h2>
              <p className="text-sm text-gray-500 mt-1">View and download your past invoices</p>
            </div>
            
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Date</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Description</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Amount</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Status</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Invoice</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {billingHistory.map((item) => (
                    <tr key={item.id} className="hover:bg-gray-50 transition-colors">
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-800">
                        {formatDate(item.date)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                        {item.description}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-800">
                        {formatCurrency(item.amount)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          item.status === 'paid' ? 'bg-green-100 text-green-800' :
                          item.status === 'pending' ? 'bg-amber-100 text-amber-800' :
                          'bg-red-100 text-red-800'
                        }`}>
                          {item.status.charAt(0).toUpperCase() + item.status.slice(1)}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {item.invoiceUrl && (
                          <button className="flex items-center gap-1 text-[#00bfa5] hover:text-[#00897b] text-sm font-medium transition-colors">
                            <DownloadIcon size={16} />
                            Download
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            
            {billingHistory.length === 0 && (
              <div className="p-12 text-center">
                <ReceiptIcon size={48} className="text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500">No billing history yet</p>
              </div>
            )}
          </div>
        )}

        {/* Payment Methods Tab */}
        {activeTab === 'payment' && (
          <div className="space-y-6">
            <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
              <div className="p-6 border-b border-gray-100 flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-bold text-gray-800">Payment Methods</h2>
                  <p className="text-sm text-gray-500 mt-1">Manage your payment methods</p>
                </div>
                <button
                  onClick={() => setShowAddPaymentModal(true)}
                  className="flex items-center gap-2 px-4 py-2 bg-[#00bfa5] text-white rounded-xl font-medium hover:bg-[#00897b] transition-colors"
                >
                  <PlusIcon size={18} />
                  Add New
                </button>
              </div>
              
              <div className="p-6 space-y-4">
                {paymentMethods.map((method) => (
                  <div
                    key={method.id}
                    className={`flex items-center justify-between p-4 rounded-xl border-2 transition-all ${
                      method.isDefault ? 'border-[#00bfa5] bg-[#00bfa5]/5' : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-8 bg-gradient-to-r from-gray-700 to-gray-900 rounded-md flex items-center justify-center">
                        <CreditCardIcon size={20} className="text-white" />
                      </div>
                      <div>
                        <p className="font-medium text-gray-800">
                          {method.brand} •••• {method.last4}
                        </p>
                        <p className="text-sm text-gray-500">
                          Expires {method.expiryMonth}/{method.expiryYear}
                        </p>
                      </div>
                      {method.isDefault && (
                        <span className="px-2 py-1 bg-[#00bfa5] text-white text-xs font-medium rounded-full">
                          Default
                        </span>
                      )}
                    </div>
                    
                    <div className="flex items-center gap-2">
                      {!method.isDefault && (
                        <button className="p-2 text-gray-400 hover:text-[#00bfa5] transition-colors">
                          <CheckIcon size={18} />
                        </button>
                      )}
                      <button className="p-2 text-gray-400 hover:text-gray-600 transition-colors">
                        <EditIcon size={18} />
                      </button>
                      <button className="p-2 text-gray-400 hover:text-red-500 transition-colors">
                        <TrashIcon size={18} />
                      </button>
                    </div>
                  </div>
                ))}
                
                {paymentMethods.length === 0 && (
                  <div className="p-12 text-center">
                    <CreditCardIcon size={48} className="text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-500">No payment methods added yet</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Usage Analytics Tab */}
        {activeTab === 'usage' && (
          <div className="space-y-6">
            {/* Usage Chart */}
            <div className="bg-white rounded-2xl shadow-lg p-6">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-xl font-bold text-gray-800">Call Minutes Over Time</h2>
                  <p className="text-sm text-gray-500 mt-1">Last 7 days</p>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <div className="flex items-center gap-1">
                    <div className="w-3 h-3 bg-[#00bfa5] rounded-full"></div>
                    <span className="text-gray-600">Minutes</span>
                  </div>
                </div>
              </div>
              
              {/* Simple Bar Chart */}
              <div className="h-64 flex items-end justify-between gap-2">
                {usageHistory.map((data, idx) => {
                  const maxValue = Math.max(...usageHistory.map(d => d.minutes));
                  const height = (data.minutes / maxValue) * 100;
                  return (
                    <div key={idx} className="flex-1 flex flex-col items-center gap-2">
                      <div className="w-full flex flex-col items-center">
                        <span className="text-xs font-medium text-gray-600 mb-1">{data.minutes}m</span>
                        <div 
                          className="w-full bg-gradient-to-t from-[#00bfa5] to-[#00897b] rounded-t-lg transition-all duration-500 hover:opacity-80"
                          style={{ height: `${height}%`, minHeight: '20px' }}
                        />
                      </div>
                      <span className="text-xs text-gray-500">
                        {new Date(data.date).toLocaleDateString('en-US', { weekday: 'short' })}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Detailed Stats */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white rounded-2xl shadow-lg p-6">
                <h3 className="text-lg font-bold text-gray-800 mb-4">Usage Breakdown</h3>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-gray-600">Call Minutes</span>
                      <span className="font-medium text-gray-800">{totalMinutesThisMonth} min</span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                      <div className="h-full bg-blue-500 rounded-full" style={{ width: '65%' }} />
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-gray-600">Video Calls</span>
                      <span className="font-medium text-gray-800">{totalCallsThisMonth} calls</span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                      <div className="h-full bg-purple-500 rounded-full" style={{ width: '45%' }} />
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-gray-600">Messages</span>
                      <span className="font-medium text-gray-800">{totalMessagesThisMonth} sent</span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                      <div className="h-full bg-green-500 rounded-full" style={{ width: '80%' }} />
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-gray-600">ASL Translations</span>
                      <span className="font-medium text-gray-800">{totalASLThisMonth} translations</span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                      <div className="h-full bg-orange-500 rounded-full" style={{ width: '35%' }} />
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="bg-white rounded-2xl shadow-lg p-6">
                <h3 className="text-lg font-bold text-gray-800 mb-4">Daily Average</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 bg-blue-50 rounded-xl">
                    <p className="text-2xl font-bold text-blue-600">
                      {Math.round(totalMinutesThisMonth / 7)}
                    </p>
                    <p className="text-sm text-blue-600/70">Minutes/day</p>
                  </div>
                  <div className="p-4 bg-purple-50 rounded-xl">
                    <p className="text-2xl font-bold text-purple-600">
                      {(totalCallsThisMonth / 7).toFixed(1)}
                    </p>
                    <p className="text-sm text-purple-600/70">Calls/day</p>
                  </div>
                  <div className="p-4 bg-green-50 rounded-xl">
                    <p className="text-2xl font-bold text-green-600">
                      {Math.round(totalMessagesThisMonth / 7)}
                    </p>
                    <p className="text-sm text-green-600/70">Messages/day</p>
                  </div>
                  <div className="p-4 bg-orange-50 rounded-xl">
                    <p className="text-2xl font-bold text-orange-600">
                      {Math.round(totalASLThisMonth / 7)}
                    </p>
                    <p className="text-sm text-orange-600/70">ASL/day</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Data Export Tab */}
        {activeTab === 'export' && (
          <div className="space-y-6">
            {/* Export Data Section */}
            <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
              <div className="p-6 border-b border-gray-100">
                <h2 className="text-xl font-bold text-gray-800">Export Your Data</h2>
                <p className="text-sm text-gray-500 mt-1">Download your usage data, conversation history, and billing records</p>
              </div>
              
              <div className="p-6 space-y-6">
                {/* Date Range */}
                <div>
                  <h3 className="font-semibold text-gray-800 mb-3">Date Range</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-600 mb-1">Start Date</label>
                      <input
                        type="date"
                        value={exportSettings.dateRange.start}
                        onChange={(e) => setExportSettings({
                          ...exportSettings,
                          dateRange: { ...exportSettings.dateRange, start: e.target.value }
                        })}
                        className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#00bfa5] focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-600 mb-1">End Date</label>
                      <input
                        type="date"
                        value={exportSettings.dateRange.end}
                        onChange={(e) => setExportSettings({
                          ...exportSettings,
                          dateRange: { ...exportSettings.dateRange, end: e.target.value }
                        })}
                        className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#00bfa5] focus:border-transparent"
                      />
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-2 mt-3">
                    {[
                      { label: 'Last 7 days', days: 7 },
                      { label: 'Last 30 days', days: 30 },
                      { label: 'Last 90 days', days: 90 },
                      { label: 'Last year', days: 365 },
                    ].map((preset) => (
                      <button
                        key={preset.days}
                        onClick={() => setExportSettings({
                          ...exportSettings,
                          dateRange: {
                            start: new Date(Date.now() - preset.days * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
                            end: new Date().toISOString().split('T')[0],
                          }
                        })}
                        className="px-3 py-1.5 text-sm bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200 transition-colors"
                      >
                        {preset.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Data Types */}
                <div>
                  <h3 className="font-semibold text-gray-800 mb-3">Data to Export</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <label className={`flex items-center gap-3 p-4 rounded-xl border-2 cursor-pointer transition-all ${
                      exportSettings.dataTypes.usage ? 'border-[#00bfa5] bg-[#00bfa5]/5' : 'border-gray-200 hover:border-gray-300'
                    }`}>
                      <input
                        type="checkbox"
                        checked={exportSettings.dataTypes.usage}
                        onChange={(e) => setExportSettings({
                          ...exportSettings,
                          dataTypes: { ...exportSettings.dataTypes, usage: e.target.checked }
                        })}
                        className="w-5 h-5 rounded border-gray-300 text-[#00bfa5] focus:ring-[#00bfa5]"
                      />
                      <div>
                        <div className="flex items-center gap-2">
                          <BarChartIcon size={18} className="text-[#00bfa5]" />
                          <span className="font-medium text-gray-800">Usage Data</span>
                        </div>
                        <p className="text-xs text-gray-500 mt-1">Call minutes, messages, ASL translations</p>
                      </div>
                    </label>
                    
                    <label className={`flex items-center gap-3 p-4 rounded-xl border-2 cursor-pointer transition-all ${
                      exportSettings.dataTypes.conversations ? 'border-[#00bfa5] bg-[#00bfa5]/5' : 'border-gray-200 hover:border-gray-300'
                    }`}>
                      <input
                        type="checkbox"
                        checked={exportSettings.dataTypes.conversations}
                        onChange={(e) => setExportSettings({
                          ...exportSettings,
                          dataTypes: { ...exportSettings.dataTypes, conversations: e.target.checked }
                        })}
                        className="w-5 h-5 rounded border-gray-300 text-[#00bfa5] focus:ring-[#00bfa5]"
                      />
                      <div>
                        <div className="flex items-center gap-2">
                          <MessageSquareIcon size={18} className="text-[#00bfa5]" />
                          <span className="font-medium text-gray-800">Conversations</span>
                        </div>
                        <p className="text-xs text-gray-500 mt-1">Call history and chat logs</p>
                      </div>
                    </label>
                    
                    <label className={`flex items-center gap-3 p-4 rounded-xl border-2 cursor-pointer transition-all ${
                      exportSettings.dataTypes.billing ? 'border-[#00bfa5] bg-[#00bfa5]/5' : 'border-gray-200 hover:border-gray-300'
                    }`}>
                      <input
                        type="checkbox"
                        checked={exportSettings.dataTypes.billing}
                        onChange={(e) => setExportSettings({
                          ...exportSettings,
                          dataTypes: { ...exportSettings.dataTypes, billing: e.target.checked }
                        })}
                        className="w-5 h-5 rounded border-gray-300 text-[#00bfa5] focus:ring-[#00bfa5]"
                      />
                      <div>
                        <div className="flex items-center gap-2">
                          <ReceiptIcon size={18} className="text-[#00bfa5]" />
                          <span className="font-medium text-gray-800">Billing Records</span>
                        </div>
                        <p className="text-xs text-gray-500 mt-1">Invoices and payment history</p>
                      </div>
                    </label>
                  </div>
                </div>

                {/* Export Format */}
                <div>
                  <h3 className="font-semibold text-gray-800 mb-3">Export Format</h3>
                  <div className="flex gap-4">
                    <label className={`flex items-center gap-3 px-6 py-4 rounded-xl border-2 cursor-pointer transition-all ${
                      exportSettings.format === 'csv' ? 'border-[#00bfa5] bg-[#00bfa5]/5' : 'border-gray-200 hover:border-gray-300'
                    }`}>
                      <input
                        type="radio"
                        name="format"
                        value="csv"
                        checked={exportSettings.format === 'csv'}
                        onChange={() => setExportSettings({ ...exportSettings, format: 'csv' })}
                        className="w-5 h-5 text-[#00bfa5] focus:ring-[#00bfa5]"
                      />
                      <div>
                        <span className="font-medium text-gray-800">CSV</span>
                        <p className="text-xs text-gray-500">Spreadsheet compatible</p>
                      </div>
                    </label>
                    
                    <label className={`flex items-center gap-3 px-6 py-4 rounded-xl border-2 cursor-pointer transition-all ${
                      exportSettings.format === 'pdf' ? 'border-[#00bfa5] bg-[#00bfa5]/5' : 'border-gray-200 hover:border-gray-300'
                    }`}>
                      <input
                        type="radio"
                        name="format"
                        value="pdf"
                        checked={exportSettings.format === 'pdf'}
                        onChange={() => setExportSettings({ ...exportSettings, format: 'pdf' })}
                        className="w-5 h-5 text-[#00bfa5] focus:ring-[#00bfa5]"
                      />
                      <div>
                        <span className="font-medium text-gray-800">PDF Report</span>
                        <p className="text-xs text-gray-500">Formatted document</p>
                      </div>
                    </label>
                  </div>
                </div>

                {/* Export Button */}
                <div className="pt-4 border-t border-gray-100">
                  <button
                    onClick={handleExport}
                    disabled={isExporting || (!exportSettings.dataTypes.usage && !exportSettings.dataTypes.conversations && !exportSettings.dataTypes.billing)}
                    className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-[#00bfa5] to-[#00897b] text-white rounded-xl font-semibold hover:shadow-lg transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isExporting ? (
                      <>
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        Exporting...
                      </>
                    ) : (
                      <>
                        <DownloadIcon size={18} />
                        Export Data
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>

            {/* Scheduled Reports Section */}
            <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
              <div className="p-6 border-b border-gray-100 flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-bold text-gray-800">Scheduled Reports</h2>
                  <p className="text-sm text-gray-500 mt-1">Automatically receive reports via email</p>
                </div>
                <button
                  onClick={() => {
                    setNewSchedule({
                      email: user?.email || '',
                      frequency: 'monthly',
                      dataTypes: ['usage'],
                      format: 'pdf',
                    });
                    setShowScheduleModal(true);
                  }}
                  className="flex items-center gap-2 px-4 py-2 bg-[#00bfa5] text-white rounded-xl font-medium hover:bg-[#00897b] transition-colors"
                >
                  <PlusIcon size={18} />
                  Schedule Report
                </button>
              </div>
              
              <div className="p-6">
                {scheduledReports.length > 0 ? (
                  <div className="space-y-4">
                    {scheduledReports.map((report) => (
                      <div
                        key={report.id}
                        className={`flex items-center justify-between p-4 rounded-xl border-2 transition-all ${
                          report.isActive ? 'border-[#00bfa5] bg-[#00bfa5]/5' : 'border-gray-200 bg-gray-50'
                        }`}
                      >
                        <div className="flex items-center gap-4">
                          <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                            report.isActive ? 'bg-[#00bfa5]/20' : 'bg-gray-200'
                          }`}>
                            <MailIcon size={24} className={report.isActive ? 'text-[#00bfa5]' : 'text-gray-400'} />
                          </div>
                          <div>
                            <p className="font-medium text-gray-800">{report.email}</p>
                            <div className="flex items-center gap-2 mt-1">
                              <span className="text-xs px-2 py-0.5 bg-gray-100 text-gray-600 rounded-full capitalize">
                                {report.frequency}
                              </span>
                              <span className="text-xs px-2 py-0.5 bg-gray-100 text-gray-600 rounded-full uppercase">
                                {report.format}
                              </span>
                              <span className="text-xs text-gray-500">
                                {report.dataTypes.join(', ')}
                              </span>
                            </div>
                            <p className="text-xs text-gray-500 mt-1">
                              Next: {formatDate(report.nextSendDate)}
                            </p>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => toggleReportActive(report.id)}
                            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                              report.isActive
                                ? 'bg-amber-100 text-amber-700 hover:bg-amber-200'
                                : 'bg-green-100 text-green-700 hover:bg-green-200'
                            }`}
                          >
                            {report.isActive ? 'Pause' : 'Resume'}
                          </button>
                          <button
                            onClick={() => deleteScheduledReport(report.id)}
                            className="p-2 text-gray-400 hover:text-red-500 transition-colors"
                          >
                            <TrashIcon size={18} />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-12 text-center">
                    <CalendarIcon size={48} className="text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-500 mb-2">No scheduled reports</p>
                    <p className="text-sm text-gray-400">Set up automatic monthly reports to receive your data via email</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Cancel Subscription Modal */}
      {showCancelModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 animate-in fade-in zoom-in duration-200">
            <div className="text-center">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <AlertCircleIcon size={32} className="text-red-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">Cancel Subscription?</h3>
              <p className="text-gray-600 mb-6">
                Are you sure you want to cancel your subscription? You'll lose access to premium features at the end of your billing period.
              </p>
              <div className="flex gap-3">
                <button
                  onClick={() => setShowCancelModal(false)}
                  className="flex-1 px-4 py-3 border border-gray-200 text-gray-600 rounded-xl font-medium hover:bg-gray-50 transition-colors"
                >
                  Keep Subscription
                </button>
                <button
                  onClick={handleCancelSubscription}
                  className="flex-1 px-4 py-3 bg-red-600 text-white rounded-xl font-medium hover:bg-red-700 transition-colors"
                >
                  Yes, Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Upgrade Modal */}
      {showUpgradeModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-4xl w-full p-6 my-8 animate-in fade-in zoom-in duration-200">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-gray-800">Choose Your Plan</h3>
              <button
                onClick={() => setShowUpgradeModal(false)}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <CloseIcon size={20} className="text-gray-500" />
              </button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Free Plan */}
              <div className={`rounded-xl border-2 p-5 transition-all ${
                currentPlan?.price_cents === 0 ? 'border-[#00bfa5] bg-[#00bfa5]/5' : 'border-gray-200'
              }`}>
                <h4 className="text-lg font-bold text-gray-800">Free</h4>
                <p className="text-3xl font-bold text-gray-800 mt-2">$0<span className="text-sm font-normal text-gray-500">/month</span></p>
                <ul className="mt-4 space-y-2">
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <CheckIcon size={16} className="text-[#00bfa5]" />
                    30 min calls/month
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <CheckIcon size={16} className="text-[#00bfa5]" />
                    Basic speech-to-text
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <CheckIcon size={16} className="text-[#00bfa5]" />
                    Standard video
                  </li>
                </ul>
                {currentPlan?.price_cents === 0 && (
                  <div className="mt-4 py-2 text-center text-[#00bfa5] font-medium">Current Plan</div>
                )}
              </div>
              
              {/* Pro Plan */}
              <div className={`rounded-xl border-2 p-5 transition-all relative ${
                currentPlan?.name === 'Pro' ? 'border-[#00bfa5] bg-[#00bfa5]/5' : 'border-gray-200'
              }`}>
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 bg-[#00bfa5] text-white text-xs font-bold rounded-full">
                  POPULAR
                </div>
                <h4 className="text-lg font-bold text-gray-800">Pro</h4>
                <p className="text-3xl font-bold text-gray-800 mt-2">$9.99<span className="text-sm font-normal text-gray-500">/month</span></p>
                <ul className="mt-4 space-y-2">
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <CheckIcon size={16} className="text-[#00bfa5]" />
                    Unlimited calls
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <CheckIcon size={16} className="text-[#00bfa5]" />
                    HD video quality
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <CheckIcon size={16} className="text-[#00bfa5]" />
                    Priority support
                  </li>
                </ul>
                {currentPlan?.name === 'Pro' ? (
                  <div className="mt-4 py-2 text-center text-[#00bfa5] font-medium">Current Plan</div>
                ) : (
                  <button className="mt-4 w-full py-2 bg-[#00bfa5] text-white rounded-lg font-medium hover:bg-[#00897b] transition-colors">
                    {currentPlan?.price_cents === 0 ? 'Upgrade' : 'Switch'}
                  </button>
                )}
              </div>
              
              {/* Enterprise Plan */}
              <div className={`rounded-xl border-2 p-5 transition-all ${
                currentPlan?.name === 'Enterprise' ? 'border-[#00bfa5] bg-[#00bfa5]/5' : 'border-gray-200'
              }`}>
                <h4 className="text-lg font-bold text-gray-800">Enterprise</h4>
                <p className="text-3xl font-bold text-gray-800 mt-2">$29.99<span className="text-sm font-normal text-gray-500">/month</span></p>
                <ul className="mt-4 space-y-2">
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <CheckIcon size={16} className="text-[#00bfa5]" />
                    Everything in Pro
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <CheckIcon size={16} className="text-[#00bfa5]" />
                    Team features
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <CheckIcon size={16} className="text-[#00bfa5]" />
                    Analytics & branding
                  </li>
                </ul>
                {currentPlan?.name === 'Enterprise' ? (
                  <div className="mt-4 py-2 text-center text-[#00bfa5] font-medium">Current Plan</div>
                ) : (
                  <button className="mt-4 w-full py-2 bg-gray-800 text-white rounded-lg font-medium hover:bg-gray-900 transition-colors">
                    {currentPlan?.price_cents === 0 ? 'Upgrade' : 'Switch'}
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add Payment Method Modal */}
      {showAddPaymentModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 animate-in fade-in zoom-in duration-200">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-gray-800">Add Payment Method</h3>
              <button
                onClick={() => setShowAddPaymentModal(false)}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <CloseIcon size={20} className="text-gray-500" />
              </button>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Card Number</label>
                <input
                  type="text"
                  placeholder="1234 5678 9012 3456"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#00bfa5] focus:border-transparent"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Expiry Date</label>
                  <input
                    type="text"
                    placeholder="MM/YY"
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#00bfa5] focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">CVC</label>
                  <input
                    type="text"
                    placeholder="123"
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#00bfa5] focus:border-transparent"
                  />
                </div>
              </div>
              <div className="flex items-center gap-2">
                <input type="checkbox" id="default" className="rounded border-gray-300 text-[#00bfa5] focus:ring-[#00bfa5]" />
                <label htmlFor="default" className="text-sm text-gray-600">Set as default payment method</label>
              </div>
              <button className="w-full py-3 bg-[#00bfa5] text-white rounded-xl font-semibold hover:bg-[#00897b] transition-colors">
                Add Payment Method
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Schedule Report Modal */}
      {showScheduleModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 animate-in fade-in zoom-in duration-200">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-gray-800">Schedule Automatic Report</h3>
              <button
                onClick={() => setShowScheduleModal(false)}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <CloseIcon size={20} className="text-gray-500" />
              </button>
            </div>
            
            <div className="space-y-5">
              {/* Email */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                <input
                  type="email"
                  value={newSchedule.email}
                  onChange={(e) => setNewSchedule({ ...newSchedule, email: e.target.value })}
                  placeholder="your@email.com"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#00bfa5] focus:border-transparent"
                />
              </div>
              
              {/* Frequency */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Frequency</label>
                <div className="flex gap-4">
                  <label className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-xl border-2 cursor-pointer transition-all ${
                    newSchedule.frequency === 'monthly' ? 'border-[#00bfa5] bg-[#00bfa5]/5' : 'border-gray-200'
                  }`}>
                    <input
                      type="radio"
                      name="frequency"
                      value="monthly"
                      checked={newSchedule.frequency === 'monthly'}
                      onChange={() => setNewSchedule({ ...newSchedule, frequency: 'monthly' })}
                      className="sr-only"
                    />
                    <CalendarIcon size={18} className={newSchedule.frequency === 'monthly' ? 'text-[#00bfa5]' : 'text-gray-400'} />
                    <span className="font-medium">Monthly</span>
                  </label>
                  <label className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-xl border-2 cursor-pointer transition-all ${
                    newSchedule.frequency === 'weekly' ? 'border-[#00bfa5] bg-[#00bfa5]/5' : 'border-gray-200'
                  }`}>
                    <input
                      type="radio"
                      name="frequency"
                      value="weekly"
                      checked={newSchedule.frequency === 'weekly'}
                      onChange={() => setNewSchedule({ ...newSchedule, frequency: 'weekly' })}
                      className="sr-only"
                    />
                    <CalendarIcon size={18} className={newSchedule.frequency === 'weekly' ? 'text-[#00bfa5]' : 'text-gray-400'} />
                    <span className="font-medium">Weekly</span>
                  </label>
                </div>
              </div>
              
              {/* Data Types */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Include Data</label>
                <div className="space-y-2">
                  {[
                    { id: 'usage', label: 'Usage Data', icon: BarChartIcon },
                    { id: 'conversations', label: 'Conversation History', icon: MessageSquareIcon },
                    { id: 'billing', label: 'Billing Records', icon: ReceiptIcon },
                  ].map((type) => (
                    <label
                      key={type.id}
                      className={`flex items-center gap-3 p-3 rounded-xl border-2 cursor-pointer transition-all ${
                        newSchedule.dataTypes.includes(type.id) ? 'border-[#00bfa5] bg-[#00bfa5]/5' : 'border-gray-200'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={newSchedule.dataTypes.includes(type.id)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setNewSchedule({ ...newSchedule, dataTypes: [...newSchedule.dataTypes, type.id] });
                          } else {
                            setNewSchedule({ ...newSchedule, dataTypes: newSchedule.dataTypes.filter(t => t !== type.id) });
                          }
                        }}
                        className="w-4 h-4 rounded border-gray-300 text-[#00bfa5] focus:ring-[#00bfa5]"
                      />
                      <type.icon size={18} className={newSchedule.dataTypes.includes(type.id) ? 'text-[#00bfa5]' : 'text-gray-400'} />
                      <span className="font-medium text-gray-700">{type.label}</span>
                    </label>
                  ))}
                </div>
              </div>
              
              {/* Format */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Report Format</label>
                <div className="flex gap-4">
                  <label className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-xl border-2 cursor-pointer transition-all ${
                    newSchedule.format === 'pdf' ? 'border-[#00bfa5] bg-[#00bfa5]/5' : 'border-gray-200'
                  }`}>
                    <input
                      type="radio"
                      name="report-format"
                      value="pdf"
                      checked={newSchedule.format === 'pdf'}
                      onChange={() => setNewSchedule({ ...newSchedule, format: 'pdf' })}
                      className="sr-only"
                    />
                    <FileTextIcon size={18} className={newSchedule.format === 'pdf' ? 'text-[#00bfa5]' : 'text-gray-400'} />
                    <span className="font-medium">PDF</span>
                  </label>
                  <label className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-xl border-2 cursor-pointer transition-all ${
                    newSchedule.format === 'csv' ? 'border-[#00bfa5] bg-[#00bfa5]/5' : 'border-gray-200'
                  }`}>
                    <input
                      type="radio"
                      name="report-format"
                      value="csv"
                      checked={newSchedule.format === 'csv'}
                      onChange={() => setNewSchedule({ ...newSchedule, format: 'csv' })}
                      className="sr-only"
                    />
                    <FileTextIcon size={18} className={newSchedule.format === 'csv' ? 'text-[#00bfa5]' : 'text-gray-400'} />
                    <span className="font-medium">CSV</span>
                  </label>
                </div>
              </div>
              
              {/* Submit Button */}
              <button
                onClick={handleScheduleReport}
                disabled={!newSchedule.email || newSchedule.dataTypes.length === 0}
                className="w-full py-3 bg-gradient-to-r from-[#00bfa5] to-[#00897b] text-white rounded-xl font-semibold hover:shadow-lg transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Schedule Report
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AccountDashboard;
