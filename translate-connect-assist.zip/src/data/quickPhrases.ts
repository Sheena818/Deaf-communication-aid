import { QuickPhrase } from '@/types';

export const quickPhrases: QuickPhrase[] = [
  // Greetings
  { id: '1', text: 'Hello! Nice to meet you.', category: 'Greetings', icon: 'wave' },
  { id: '2', text: 'Good morning!', category: 'Greetings', icon: 'sun' },
  { id: '3', text: 'Good afternoon!', category: 'Greetings', icon: 'sun' },
  { id: '4', text: 'Good evening!', category: 'Greetings', icon: 'moon' },
  { id: '5', text: 'How are you doing today?', category: 'Greetings', icon: 'smile' },
  { id: '6', text: 'It was nice talking to you!', category: 'Greetings', icon: 'heart' },
  { id: '7', text: 'See you later!', category: 'Greetings', icon: 'wave' },
  { id: '8', text: 'Take care!', category: 'Greetings', icon: 'heart' },
  
  // Questions
  { id: '9', text: 'Could you please repeat that?', category: 'Questions', icon: 'refresh' },
  { id: '10', text: 'Could you speak slower please?', category: 'Questions', icon: 'slow' },
  { id: '11', text: 'What is your name?', category: 'Questions', icon: 'user' },
  { id: '12', text: 'Where is the restroom?', category: 'Questions', icon: 'location' },
  { id: '13', text: 'What time is it?', category: 'Questions', icon: 'clock' },
  { id: '14', text: 'How much does this cost?', category: 'Questions', icon: 'dollar' },
  { id: '15', text: 'Can you help me please?', category: 'Questions', icon: 'help' },
  { id: '16', text: 'Do you understand sign language?', category: 'Questions', icon: 'hands' },
  
  // Responses
  { id: '17', text: 'Yes, I understand.', category: 'Responses', icon: 'check' },
  { id: '18', text: 'No, I don\'t understand.', category: 'Responses', icon: 'x' },
  { id: '19', text: 'Please wait a moment.', category: 'Responses', icon: 'clock' },
  { id: '20', text: 'Thank you very much!', category: 'Responses', icon: 'heart' },
  { id: '21', text: 'You\'re welcome!', category: 'Responses', icon: 'smile' },
  { id: '22', text: 'I agree with you.', category: 'Responses', icon: 'check' },
  { id: '23', text: 'I\'m not sure about that.', category: 'Responses', icon: 'question' },
  { id: '24', text: 'That sounds great!', category: 'Responses', icon: 'star' },
  
  // Emergencies
  { id: '25', text: 'I need help immediately!', category: 'Emergencies', icon: 'alert' },
  { id: '26', text: 'Please call 911!', category: 'Emergencies', icon: 'phone' },
  { id: '27', text: 'I am deaf and need assistance.', category: 'Emergencies', icon: 'ear' },
  { id: '28', text: 'I have a medical emergency.', category: 'Emergencies', icon: 'medical' },
  { id: '29', text: 'I am lost and need directions.', category: 'Emergencies', icon: 'location' },
  { id: '30', text: 'Please contact my emergency contact.', category: 'Emergencies', icon: 'phone' },
  
  // Social
  { id: '31', text: 'Would you like to get coffee?', category: 'Social', icon: 'coffee' },
  { id: '32', text: 'What do you do for work?', category: 'Social', icon: 'briefcase' },
  { id: '33', text: 'Do you have any hobbies?', category: 'Social', icon: 'star' },
  { id: '34', text: 'I really enjoyed our conversation.', category: 'Social', icon: 'heart' },
  { id: '35', text: 'Can I get your contact information?', category: 'Social', icon: 'phone' },
  { id: '36', text: 'Let\'s meet again sometime!', category: 'Social', icon: 'calendar' },
  
  // Medical
  { id: '37', text: 'I have an appointment.', category: 'Medical', icon: 'calendar' },
  { id: '38', text: 'I need to see a doctor.', category: 'Medical', icon: 'medical' },
  { id: '39', text: 'I am allergic to...', category: 'Medical', icon: 'alert' },
  { id: '40', text: 'I take medication for...', category: 'Medical', icon: 'medical' },
  { id: '41', text: 'Where is the pharmacy?', category: 'Medical', icon: 'location' },
  { id: '42', text: 'I need an interpreter.', category: 'Medical', icon: 'hands' },
];

export const categories = [
  'All',
  'Greetings',
  'Questions',
  'Responses',
  'Emergencies',
  'Social',
  'Medical',
];
