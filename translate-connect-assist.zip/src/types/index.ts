export interface Message {
  id: string;
  text: string;
  sender: 'user' | 'other';
  timestamp: Date;
  type: 'speech' | 'text' | 'phrase';
}

export interface QuickPhrase {
  id: string;
  text: string;
  category: string;
  icon: string;
}

export interface Settings {
  textSize: 'small' | 'medium' | 'large' | 'extra-large';
  theme: 'light' | 'dark' | 'high-contrast';
  vibrationEnabled: boolean;
  speechRate: number;
  speechPitch: number;
  speechVolume: number;
  preferredMode: 'speech-to-text' | 'text-to-speech' | 'both';
}

export interface EmergencyContact {
  id: string;
  name: string;
  phone: string;
  relationship: string;
}
