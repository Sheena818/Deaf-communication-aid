import { useState, useEffect, useRef, useCallback } from 'react';
import { supabase } from '@/lib/supabase';

interface Reaction {
  id: string;
  emoji: string;
  senderId: string;
  senderName: string;
  timestamp: string;
}

export interface AnimatedReaction {
  id: string;
  emoji: string;
  senderName: string;
  x: number;
  y: number;
  isLocal: boolean;
}

interface UseVideoReactionsProps {
  roomCode: string;
  participantId: string;
  displayName: string;
  isInCall: boolean;
}

export const useVideoReactions = ({
  roomCode,
  participantId,
  displayName,
  isInCall,
}: UseVideoReactionsProps) => {
  const [isPickerOpen, setIsPickerOpen] = useState(false);
  const [animatedReactions, setAnimatedReactions] = useState<AnimatedReaction[]>([]);
  const [lastReactionId, setLastReactionId] = useState<string | null>(null);
  const [seenReactionIds, setSeenReactionIds] = useState<Set<string>>(new Set());
  const pollIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Add an animated reaction to the display
  const addAnimatedReaction = useCallback((reaction: Reaction, isLocal: boolean) => {
    // Random position for the reaction
    const x = Math.random() * 60 + 20; // 20-80% from left
    const y = Math.random() * 40 + 30; // 30-70% from top

    const animatedReaction: AnimatedReaction = {
      id: `${reaction.id}-${Date.now()}`,
      emoji: reaction.emoji,
      senderName: reaction.senderName,
      x,
      y,
      isLocal,
    };

    setAnimatedReactions(prev => [...prev, animatedReaction]);

    // Remove the reaction after animation completes (3 seconds)
    setTimeout(() => {
      setAnimatedReactions(prev => prev.filter(r => r.id !== animatedReaction.id));
    }, 3000);
  }, []);

  // Send a reaction
  const sendReaction = useCallback(async (emoji: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('video-signaling', {
        body: {
          action: 'send-reaction',
          roomCode,
          participantId,
          emoji,
          senderName: displayName,
        },
      });

      if (error) {
        console.error('Error sending reaction:', error);
        return;
      }

      if (data?.success && data?.reaction) {
        // Add local reaction immediately for instant feedback
        addAnimatedReaction({
          id: data.reaction.id,
          emoji,
          senderId: participantId,
          senderName: displayName,
          timestamp: new Date().toISOString(),
        }, true);
        
        // Track this reaction as seen
        setSeenReactionIds(prev => new Set([...prev, data.reaction.id]));
      }

      // Close picker after sending
      setIsPickerOpen(false);
    } catch (err) {
      console.error('Error sending reaction:', err);
    }
  }, [roomCode, participantId, displayName, addAnimatedReaction]);

  // Poll for new reactions
  const pollReactions = useCallback(async () => {
    if (!roomCode || !isInCall) return;

    try {
      const { data, error } = await supabase.functions.invoke('video-signaling', {
        body: {
          action: 'get-reactions',
          roomCode,
          participantId,
          lastReactionId,
          limit: 10,
        },
      });

      if (error) {
        console.error('Error polling reactions:', error);
        return;
      }

      if (data?.success && data?.reactions) {
        const reactions = data.reactions as Reaction[];
        
        // Process new reactions (excluding ones we've already seen)
        reactions.forEach((reaction) => {
          if (!seenReactionIds.has(reaction.id)) {
            // Only show remote reactions (local ones are shown immediately)
            if (reaction.senderId !== participantId) {
              addAnimatedReaction(reaction, false);
            }
            setSeenReactionIds(prev => new Set([...prev, reaction.id]));
          }
        });

        // Update last reaction ID for pagination
        if (reactions.length > 0) {
          setLastReactionId(reactions[0].id);
        }
      }
    } catch (err) {
      console.error('Error polling reactions:', err);
    }
  }, [roomCode, participantId, isInCall, lastReactionId, seenReactionIds, addAnimatedReaction]);

  // Start/stop polling when in call
  useEffect(() => {
    if (isInCall && roomCode) {
      // Poll every 500ms for quick reaction updates
      pollIntervalRef.current = setInterval(pollReactions, 500);
      
      return () => {
        if (pollIntervalRef.current) {
          clearInterval(pollIntervalRef.current);
          pollIntervalRef.current = null;
        }
      };
    }
  }, [isInCall, roomCode, pollReactions]);

  // Reset state when leaving call
  useEffect(() => {
    if (!isInCall) {
      setAnimatedReactions([]);
      setLastReactionId(null);
      setSeenReactionIds(new Set());
      setIsPickerOpen(false);
    }
  }, [isInCall]);

  return {
    animatedReactions,
    isPickerOpen,
    setIsPickerOpen,
    sendReaction,
  };
};
