import { useState, useEffect, useRef, useCallback } from 'react';

export type BackgroundType = 'none' | 'blur' | 'color' | 'image';

export interface BackgroundOption {
  id: string;
  type: BackgroundType;
  name: string;
  value?: string; // color hex or image URL
  thumbnail?: string;
}

export const DEFAULT_BACKGROUNDS: BackgroundOption[] = [
  { id: 'none', type: 'none', name: 'None' },
  { id: 'blur-light', type: 'blur', name: 'Light Blur', value: '5' },
  { id: 'blur-medium', type: 'blur', name: 'Medium Blur', value: '10' },
  { id: 'blur-strong', type: 'blur', name: 'Strong Blur', value: '20' },
  { id: 'color-gray', type: 'color', name: 'Gray', value: '#374151' },
  { id: 'color-blue', type: 'color', name: 'Blue', value: '#1e40af' },
  { id: 'color-green', type: 'color', name: 'Green', value: '#166534' },
  { id: 'color-purple', type: 'color', name: 'Purple', value: '#7c3aed' },
  { id: 'color-red', type: 'color', name: 'Red', value: '#dc2626' },
  { id: 'color-teal', type: 'color', name: 'Teal', value: '#0d9488' },
  { 
    id: 'img-office-1', 
    type: 'image', 
    name: 'Modern Office', 
    value: 'https://d64gsuwffb70l.cloudfront.net/6945ed0ba05f1477c272f404_1766198167435_78540c37.jpg',
    thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6945ed0ba05f1477c272f404_1766198167435_78540c37.jpg'
  },
  { 
    id: 'img-office-2', 
    type: 'image', 
    name: 'Office View', 
    value: 'https://d64gsuwffb70l.cloudfront.net/6945ed0ba05f1477c272f404_1766198167885_db3db703.jpg',
    thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6945ed0ba05f1477c272f404_1766198167885_db3db703.jpg'
  },
  { 
    id: 'img-office-3', 
    type: 'image', 
    name: 'Workspace', 
    value: 'https://d64gsuwffb70l.cloudfront.net/6945ed0ba05f1477c272f404_1766198169797_5389e7a7.jpg',
    thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6945ed0ba05f1477c272f404_1766198169797_5389e7a7.jpg'
  },
  { 
    id: 'img-nature-1', 
    type: 'image', 
    name: 'Mountain Lake', 
    value: 'https://d64gsuwffb70l.cloudfront.net/6945ed0ba05f1477c272f404_1766198186797_083ec09e.png',
    thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6945ed0ba05f1477c272f404_1766198186797_083ec09e.png'
  },
  { 
    id: 'img-nature-2', 
    type: 'image', 
    name: 'Scenic View', 
    value: 'https://d64gsuwffb70l.cloudfront.net/6945ed0ba05f1477c272f404_1766198186994_a08dce2c.png',
    thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6945ed0ba05f1477c272f404_1766198186994_a08dce2c.png'
  },
  { 
    id: 'img-nature-3', 
    type: 'image', 
    name: 'Nature', 
    value: 'https://d64gsuwffb70l.cloudfront.net/6945ed0ba05f1477c272f404_1766198189218_fa5575b2.png',
    thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6945ed0ba05f1477c272f404_1766198189218_fa5575b2.png'
  },
  { 
    id: 'img-library-1', 
    type: 'image', 
    name: 'Library', 
    value: 'https://d64gsuwffb70l.cloudfront.net/6945ed0ba05f1477c272f404_1766198212655_a0f7ad7b.png',
    thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6945ed0ba05f1477c272f404_1766198212655_a0f7ad7b.png'
  },
  { 
    id: 'img-library-2', 
    type: 'image', 
    name: 'Bookshelf', 
    value: 'https://d64gsuwffb70l.cloudfront.net/6945ed0ba05f1477c272f404_1766198213324_373623b2.png',
    thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6945ed0ba05f1477c272f404_1766198213324_373623b2.png'
  },
];

const STORAGE_KEY = 'virtual-background-preferences';
const CUSTOM_BACKGROUNDS_KEY = 'custom-backgrounds';

interface UseVirtualBackgroundProps {
  inputStream: MediaStream | null;
  enabled: boolean;
}

interface VirtualBackgroundState {
  isLoading: boolean;
  isModelLoaded: boolean;
  error: string | null;
  selectedBackground: BackgroundOption;
  customBackgrounds: BackgroundOption[];
  processedStream: MediaStream | null;
}

// Load TensorFlow.js and body segmentation model dynamically
let segmenter: any = null;
let tf: any = null;
let bodySegmentation: any = null;

const loadTensorFlow = async () => {
  if (tf && bodySegmentation) return { tf, bodySegmentation };
  
  try {
    // Dynamic imports for TensorFlow.js - use the full package
    const tfModule = await import('@tensorflow/tfjs');
    const bodySegmentationModule = await import('@tensorflow-models/body-segmentation');
    
    tf = tfModule;
    bodySegmentation = bodySegmentationModule;
    
    // Set backend
    await tf.setBackend('webgl');
    await tf.ready();
    
    return { tf, bodySegmentation };
  } catch (error) {
    console.error('Failed to load TensorFlow.js:', error);
    throw error;
  }
};

const createSegmenter = async () => {
  if (segmenter) return segmenter;
  
  const { bodySegmentation } = await loadTensorFlow();
  
  // Use MediaPipe Selfie Segmentation model
  const model = bodySegmentation.SupportedModels.MediaPipeSelfieSegmentation;
  const segmenterConfig = {
    runtime: 'tfjs' as const,
    modelType: 'general' as const,
  };
  
  segmenter = await bodySegmentation.createSegmenter(model, segmenterConfig);
  return segmenter;
};

export const useVirtualBackground = ({
  inputStream,
  enabled,
}: UseVirtualBackgroundProps) => {
  const [state, setState] = useState<VirtualBackgroundState>({
    isLoading: false,
    isModelLoaded: false,
    error: null,
    selectedBackground: DEFAULT_BACKGROUNDS[0],
    customBackgrounds: [],
    processedStream: null,
  });

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const backgroundImageRef = useRef<HTMLImageElement | null>(null);
  const isProcessingRef = useRef(false);

  // Load saved preferences
  useEffect(() => {
    try {
      const savedPrefs = localStorage.getItem(STORAGE_KEY);
      const savedCustom = localStorage.getItem(CUSTOM_BACKGROUNDS_KEY);
      
      if (savedPrefs) {
        const prefs = JSON.parse(savedPrefs);
        const background = [...DEFAULT_BACKGROUNDS, ...(savedCustom ? JSON.parse(savedCustom) : [])]
          .find(b => b.id === prefs.selectedBackgroundId);
        if (background) {
          setState(prev => ({ ...prev, selectedBackground: background }));
        }
      }
      
      if (savedCustom) {
        setState(prev => ({ ...prev, customBackgrounds: JSON.parse(savedCustom) }));
      }
    } catch (error) {
      console.error('Error loading preferences:', error);
    }
  }, []);

  // Save preferences when background changes
  const savePreferences = useCallback((backgroundId: string) => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ selectedBackgroundId: backgroundId }));
    } catch (error) {
      console.error('Error saving preferences:', error);
    }
  }, []);

  // Load background image when needed
  useEffect(() => {
    if (state.selectedBackground.type === 'image' && state.selectedBackground.value) {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        backgroundImageRef.current = img;
      };
      img.onerror = () => {
        console.error('Failed to load background image');
        backgroundImageRef.current = null;
      };
      img.src = state.selectedBackground.value;
    } else {
      backgroundImageRef.current = null;
    }
  }, [state.selectedBackground]);

  // Initialize model
  const initializeModel = useCallback(async () => {
    if (state.isModelLoaded) return;
    
    setState(prev => ({ ...prev, isLoading: true, error: null }));
    
    try {
      await createSegmenter();
      setState(prev => ({ ...prev, isModelLoaded: true, isLoading: false }));
    } catch (error) {
      console.error('Failed to initialize segmentation model:', error);
      setState(prev => ({
        ...prev,
        isLoading: false,
        error: 'Failed to load background model. Using original video.',
      }));
    }
  }, [state.isModelLoaded]);

  // Process video frame with segmentation
  const processFrame = useCallback(async () => {
    if (!videoRef.current || !canvasRef.current || !segmenter || isProcessingRef.current) {
      return;
    }

    const video = videoRef.current;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    
    if (!ctx || video.readyState < 2) {
      return;
    }

    isProcessingRef.current = true;

    try {
      // Get segmentation
      const segmentation = await segmenter.segmentPeople(video, {
        flipHorizontal: false,
        multiSegmentation: false,
        segmentBodyParts: false,
      });

      if (!segmentation || segmentation.length === 0) {
        // No person detected, just draw original video
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        isProcessingRef.current = false;
        return;
      }

      const mask = segmentation[0].mask;
      const maskData = await mask.toImageData();

      // Draw background first
      const background = state.selectedBackground;
      
      if (background.type === 'blur') {
        // Draw blurred video as background
        ctx.filter = `blur(${background.value || '10'}px)`;
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        ctx.filter = 'none';
      } else if (background.type === 'color') {
        // Draw solid color background
        ctx.fillStyle = background.value || '#374151';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      } else if (background.type === 'image' && backgroundImageRef.current) {
        // Draw image background (cover mode)
        const img = backgroundImageRef.current;
        const imgRatio = img.width / img.height;
        const canvasRatio = canvas.width / canvas.height;
        
        let drawWidth, drawHeight, drawX, drawY;
        
        if (imgRatio > canvasRatio) {
          drawHeight = canvas.height;
          drawWidth = img.width * (canvas.height / img.height);
          drawX = (canvas.width - drawWidth) / 2;
          drawY = 0;
        } else {
          drawWidth = canvas.width;
          drawHeight = img.height * (canvas.width / img.width);
          drawX = 0;
          drawY = (canvas.height - drawHeight) / 2;
        }
        
        ctx.drawImage(img, drawX, drawY, drawWidth, drawHeight);
      } else {
        // No background effect, just draw original
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        isProcessingRef.current = false;
        return;
      }

      // Create temporary canvas for the person
      const tempCanvas = document.createElement('canvas');
      tempCanvas.width = canvas.width;
      tempCanvas.height = canvas.height;
      const tempCtx = tempCanvas.getContext('2d', { willReadFrequently: true });
      
      if (tempCtx) {
        // Draw original video to temp canvas
        tempCtx.drawImage(video, 0, 0, canvas.width, canvas.height);
        
        // Get image data
        const imageData = tempCtx.getImageData(0, 0, canvas.width, canvas.height);
        const pixels = imageData.data;
        
        // Apply mask - keep person, make background transparent
        for (let i = 0; i < maskData.data.length; i += 4) {
          const maskValue = maskData.data[i]; // Person mask value (255 = person, 0 = background)
          const pixelIndex = i;
          
          // If background (mask is 0), make transparent
          if (maskValue < 128) {
            pixels[pixelIndex + 3] = 0; // Set alpha to 0
          }
        }
        
        tempCtx.putImageData(imageData, 0, 0);
        
        // Draw person on top of background
        ctx.drawImage(tempCanvas, 0, 0);
      }
    } catch (error) {
      // On error, just draw original video
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    }

    isProcessingRef.current = false;
  }, [state.selectedBackground]);

  // Animation loop
  const startProcessing = useCallback(() => {
    const loop = async () => {
      if (enabled && state.selectedBackground.type !== 'none') {
        await processFrame();
      }
      animationFrameRef.current = requestAnimationFrame(loop);
    };
    
    loop();
  }, [enabled, state.selectedBackground.type, processFrame]);

  // Setup video processing pipeline
  useEffect(() => {
    if (!inputStream || !enabled) {
      setState(prev => ({ ...prev, processedStream: null }));
      return;
    }

    if (state.selectedBackground.type === 'none') {
      setState(prev => ({ ...prev, processedStream: inputStream }));
      return;
    }

    // Initialize model if not loaded
    if (!state.isModelLoaded && !state.isLoading) {
      initializeModel();
      // Return original stream while loading
      setState(prev => ({ ...prev, processedStream: inputStream }));
      return;
    }

    // Create video element for input
    const video = document.createElement('video');
    video.srcObject = inputStream;
    video.autoplay = true;
    video.playsInline = true;
    video.muted = true;
    videoRef.current = video;

    // Create canvas for output
    const canvas = document.createElement('canvas');
    canvas.width = 640;
    canvas.height = 480;
    canvasRef.current = canvas;

    // Wait for video to be ready
    video.onloadedmetadata = () => {
      canvas.width = video.videoWidth || 640;
      canvas.height = video.videoHeight || 480;
      video.play();
      
      // Start processing loop
      startProcessing();
      
      // Create output stream from canvas
      const outputStream = canvas.captureStream(30);
      
      // Add audio tracks from original stream
      inputStream.getAudioTracks().forEach(track => {
        outputStream.addTrack(track);
      });
      
      setState(prev => ({ ...prev, processedStream: outputStream }));
    };

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
      video.pause();
      video.srcObject = null;
    };
  }, [inputStream, enabled, state.selectedBackground, state.isModelLoaded, state.isLoading, initializeModel, startProcessing]);

  // Select background
  const selectBackground = useCallback((background: BackgroundOption) => {
    setState(prev => ({ ...prev, selectedBackground: background }));
    savePreferences(background.id);
  }, [savePreferences]);

  // Add custom background
  const addCustomBackground = useCallback((imageUrl: string, name: string) => {
    const newBackground: BackgroundOption = {
      id: `custom-${Date.now()}`,
      type: 'image',
      name,
      value: imageUrl,
      thumbnail: imageUrl,
    };

    setState(prev => {
      const newCustomBackgrounds = [...prev.customBackgrounds, newBackground];
      try {
        localStorage.setItem(CUSTOM_BACKGROUNDS_KEY, JSON.stringify(newCustomBackgrounds));
      } catch (error) {
        console.error('Error saving custom backgrounds:', error);
      }
      return { ...prev, customBackgrounds: newCustomBackgrounds };
    });

    return newBackground;
  }, []);

  // Remove custom background
  const removeCustomBackground = useCallback((id: string) => {
    setState(prev => {
      const newCustomBackgrounds = prev.customBackgrounds.filter(b => b.id !== id);
      try {
        localStorage.setItem(CUSTOM_BACKGROUNDS_KEY, JSON.stringify(newCustomBackgrounds));
      } catch (error) {
        console.error('Error saving custom backgrounds:', error);
      }
      
      // If the removed background was selected, switch to none
      if (prev.selectedBackground.id === id) {
        return {
          ...prev,
          customBackgrounds: newCustomBackgrounds,
          selectedBackground: DEFAULT_BACKGROUNDS[0],
        };
      }
      
      return { ...prev, customBackgrounds: newCustomBackgrounds };
    });
  }, []);

  return {
    ...state,
    allBackgrounds: [...DEFAULT_BACKGROUNDS, ...state.customBackgrounds],
    selectBackground,
    addCustomBackground,
    removeCustomBackground,
    initializeModel,
  };
};
