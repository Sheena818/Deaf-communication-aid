import { useState, useRef, useCallback, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { RealtimeChannel } from '@supabase/supabase-js';

interface Participant {
  id: string;
  name: string;
  isLocal: boolean;
  isMuted: boolean;
  isVideoOff: boolean;
  stream?: MediaStream;
}

interface SignalingMessage {
  id: string;
  room_code: string;
  sender_id: string;
  target_id?: string;
  message_type: string;
  payload: any;
  created_at: string;
}

interface RTCIceServerConfig {
  urls: string | string[];
  username?: string;
  credential?: string;
}

interface TurnCredentialsResponse {
  success: boolean;
  iceServers: RTCIceServerConfig[];
  provider: string;
  expiresAt: string;
  hasTurn: boolean;
  message: string;
}

interface UseWebRTCOptions {
  roomCode: string;
  participantId: string;
  displayName: string;
  onParticipantJoined?: (participant: Participant) => void;
  onParticipantLeft?: (participantId: string) => void;
  onRemoteStream?: (participantId: string, stream: MediaStream) => void;
  onError?: (error: Error) => void;
  onIceServerInfo?: (info: { provider: string; hasTurn: boolean; message: string }) => void;
}

// Default STUN servers (fallback if TURN fetch fails)
const DEFAULT_ICE_SERVERS: RTCConfiguration = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
    { urls: 'stun:stun2.l.google.com:19302' },
  ],
};

export function useWebRTC(options: UseWebRTCOptions) {
  const { 
    roomCode, 
    participantId, 
    displayName, 
    onParticipantJoined, 
    onParticipantLeft, 
    onRemoteStream, 
    onError,
    onIceServerInfo 
  } = options;

  const [isConnected, setIsConnected] = useState(false);
  const [participants, setParticipants] = useState<Participant[]>([]);
  const [connectionState, setConnectionState] = useState<string>('new');
  const [iceConnectionType, setIceConnectionType] = useState<'direct' | 'relay' | 'unknown'>('unknown');
  const [turnProvider, setTurnProvider] = useState<string>('');

  const localStreamRef = useRef<MediaStream | null>(null);
  const peerConnectionsRef = useRef<Map<string, RTCPeerConnection>>(new Map());
  const channelRef = useRef<RealtimeChannel | null>(null);
  const pollingIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const processedMessagesRef = useRef<Set<string>>(new Set());
  const isNegotiatingRef = useRef<Map<string, boolean>>(new Map());
  const iceServersRef = useRef<RTCConfiguration>(DEFAULT_ICE_SERVERS);
  const iceCredentialsExpiryRef = useRef<Date | null>(null);
  const credentialRefreshIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Fetch TURN credentials from edge function
  const fetchTurnCredentials = useCallback(async (): Promise<RTCConfiguration> => {
    try {
      console.log('Fetching TURN credentials...');
      const { data, error } = await supabase.functions.invoke('turn-credentials', {
        body: {},
      });

      if (error) {
        console.error('Error fetching TURN credentials:', error);
        return DEFAULT_ICE_SERVERS;
      }

      const response = data as TurnCredentialsResponse;
      
      if (response.success && response.iceServers) {
        console.log('TURN credentials fetched successfully:', {
          provider: response.provider,
          hasTurn: response.hasTurn,
          serverCount: response.iceServers.length,
          expiresAt: response.expiresAt
        });

        // Update state with provider info
        setTurnProvider(response.provider);
        onIceServerInfo?.({
          provider: response.provider,
          hasTurn: response.hasTurn,
          message: response.message
        });

        // Set expiry time for credential refresh
        if (response.expiresAt) {
          iceCredentialsExpiryRef.current = new Date(response.expiresAt);
        }

        const config: RTCConfiguration = {
          iceServers: response.iceServers,
          iceCandidatePoolSize: 10,
          iceTransportPolicy: 'all', // Use 'relay' to force TURN usage for testing
        };

        iceServersRef.current = config;
        return config;
      }

      return DEFAULT_ICE_SERVERS;
    } catch (err) {
      console.error('Failed to fetch TURN credentials:', err);
      return DEFAULT_ICE_SERVERS;
    }
  }, [onIceServerInfo]);

  // Schedule credential refresh before expiry
  const scheduleCredentialRefresh = useCallback(() => {
    if (credentialRefreshIntervalRef.current) {
      clearTimeout(credentialRefreshIntervalRef.current);
    }

    const expiryTime = iceCredentialsExpiryRef.current;
    if (!expiryTime) return;

    // Refresh 5 minutes before expiry
    const refreshTime = expiryTime.getTime() - Date.now() - 5 * 60 * 1000;
    
    if (refreshTime > 0) {
      console.log('Scheduling TURN credential refresh in', Math.round(refreshTime / 1000 / 60), 'minutes');
      credentialRefreshIntervalRef.current = setTimeout(async () => {
        console.log('Refreshing TURN credentials...');
        await fetchTurnCredentials();
        
        // Update existing peer connections with new ICE servers
        peerConnectionsRef.current.forEach((pc, peerId) => {
          console.log('Restarting ICE for peer:', peerId);
          pc.restartIce();
        });
        
        // Schedule next refresh
        scheduleCredentialRefresh();
      }, refreshTime);
    }
  }, [fetchTurnCredentials]);

  // Analyze ICE connection type from stats
  const analyzeConnectionType = useCallback(async (pc: RTCPeerConnection) => {
    try {
      const stats = await pc.getStats();
      stats.forEach((report) => {
        if (report.type === 'candidate-pair' && report.state === 'succeeded') {
          const localCandidateId = report.localCandidateId;
          const remoteCandidateId = report.remoteCandidateId;
          
          stats.forEach((candidateReport) => {
            if (candidateReport.id === localCandidateId || candidateReport.id === remoteCandidateId) {
              if (candidateReport.candidateType === 'relay') {
                console.log('Connection using TURN relay');
                setIceConnectionType('relay');
              } else if (candidateReport.candidateType === 'srflx' || candidateReport.candidateType === 'host') {
                console.log('Connection using direct/STUN:', candidateReport.candidateType);
                setIceConnectionType('direct');
              }
            }
          });
        }
      });
    } catch (err) {
      console.error('Error analyzing connection type:', err);
    }
  }, []);

  // Send signaling message via edge function
  const sendSignal = useCallback(async (targetId: string | null, messageType: string, payload: any) => {
    if (!roomCode) return;
    
    try {
      const { data, error } = await supabase.functions.invoke('video-signaling', {
        body: { 
          action: 'signal', 
          roomCode, 
          participantId, 
          targetId, 
          messageType, 
          payload 
        },
      });
      
      if (error) {
        console.error('Signal error:', error);
      }
      return data;
    } catch (err) {
      console.error('Failed to send signal:', err);
    }
  }, [roomCode, participantId]);

  // Create a new peer connection for a remote participant
  const createPeerConnection = useCallback((remoteParticipantId: string): RTCPeerConnection => {
    // Close existing connection if any
    const existingPc = peerConnectionsRef.current.get(remoteParticipantId);
    if (existingPc) {
      existingPc.close();
    }

    console.log('Creating peer connection for:', remoteParticipantId);
    console.log('Using ICE servers:', iceServersRef.current);
    
    const pc = new RTCPeerConnection(iceServersRef.current);

    // Add local tracks to the connection
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach(track => {
        console.log('Adding local track:', track.kind);
        pc.addTrack(track, localStreamRef.current!);
      });
    }

    // Handle ICE candidates
    pc.onicecandidate = (event) => {
      if (event.candidate) {
        console.log('Sending ICE candidate to:', remoteParticipantId, 'type:', event.candidate.type);
        sendSignal(remoteParticipantId, 'ice-candidate', { 
          candidate: event.candidate.toJSON() 
        });
      }
    };

    // Handle ICE gathering state
    pc.onicegatheringstatechange = () => {
      console.log('ICE gathering state:', pc.iceGatheringState);
    };

    // Handle connection state changes
    pc.onconnectionstatechange = () => {
      console.log('Connection state:', pc.connectionState, 'for:', remoteParticipantId);
      setConnectionState(pc.connectionState);
      
      if (pc.connectionState === 'connected') {
        setIsConnected(true);
        // Analyze what type of connection was established
        analyzeConnectionType(pc);
      } else if (pc.connectionState === 'failed') {
        console.log('Connection failed, attempting ICE restart...');
        pc.restartIce();
      } else if (pc.connectionState === 'disconnected') {
        // Wait a bit before restarting, as it might recover
        setTimeout(() => {
          if (pc.connectionState === 'disconnected') {
            console.log('Still disconnected, attempting ICE restart...');
            pc.restartIce();
          }
        }, 3000);
      }
    };

    // Handle ICE connection state
    pc.oniceconnectionstatechange = () => {
      console.log('ICE connection state:', pc.iceConnectionState);
      
      if (pc.iceConnectionState === 'connected' || pc.iceConnectionState === 'completed') {
        analyzeConnectionType(pc);
      }
    };

    // Handle negotiation needed
    pc.onnegotiationneeded = async () => {
      console.log('Negotiation needed for:', remoteParticipantId);
      
      // Prevent multiple simultaneous negotiations
      if (isNegotiatingRef.current.get(remoteParticipantId)) {
        console.log('Already negotiating, skipping');
        return;
      }
      
      // Only the participant with the "lower" ID initiates the offer
      // This prevents both sides from sending offers simultaneously
      if (participantId > remoteParticipantId) {
        console.log('Waiting for offer from other participant');
        return;
      }

      try {
        isNegotiatingRef.current.set(remoteParticipantId, true);
        
        const offer = await pc.createOffer();
        await pc.setLocalDescription(offer);
        
        console.log('Sending offer to:', remoteParticipantId);
        await sendSignal(remoteParticipantId, 'offer', { 
          sdp: pc.localDescription 
        });
      } catch (err) {
        console.error('Error creating offer:', err);
      } finally {
        isNegotiatingRef.current.set(remoteParticipantId, false);
      }
    };

    // Handle incoming tracks
    pc.ontrack = (event) => {
      console.log('Received remote track:', event.track.kind, 'from:', remoteParticipantId);
      const [remoteStream] = event.streams;
      if (remoteStream) {
        onRemoteStream?.(remoteParticipantId, remoteStream);
      }
    };

    peerConnectionsRef.current.set(remoteParticipantId, pc);
    return pc;
  }, [participantId, sendSignal, onRemoteStream, analyzeConnectionType]);

  // Handle incoming signaling message
  const handleSignalingMessage = useCallback(async (message: SignalingMessage) => {
    // Skip if we've already processed this message
    if (processedMessagesRef.current.has(message.id)) {
      return;
    }
    processedMessagesRef.current.add(message.id);

    // Skip messages from ourselves
    if (message.sender_id === participantId) {
      return;
    }

    // Skip messages not meant for us (if target is specified)
    if (message.target_id && message.target_id !== participantId) {
      return;
    }

    console.log('Processing signal:', message.message_type, 'from:', message.sender_id);

    const senderId = message.sender_id;

    switch (message.message_type) {
      case 'participant-joined': {
        const { displayName: name } = message.payload;
        console.log('Participant joined:', senderId, name);
        
        // Create peer connection for new participant
        const pc = createPeerConnection(senderId);
        
        // Notify about new participant
        onParticipantJoined?.({
          id: senderId,
          name: name || 'Guest',
          isLocal: false,
          isMuted: false,
          isVideoOff: false,
        });

        // If we have a lower ID, we initiate the offer
        if (participantId < senderId && localStreamRef.current) {
          try {
            const offer = await pc.createOffer();
            await pc.setLocalDescription(offer);
            console.log('Sending offer to new participant:', senderId);
            await sendSignal(senderId, 'offer', { sdp: pc.localDescription });
          } catch (err) {
            console.error('Error sending offer to new participant:', err);
          }
        }
        break;
      }

      case 'offer': {
        console.log('Received offer from:', senderId);
        let pc = peerConnectionsRef.current.get(senderId);
        
        if (!pc) {
          pc = createPeerConnection(senderId);
          onParticipantJoined?.({
            id: senderId,
            name: 'Guest',
            isLocal: false,
            isMuted: false,
            isVideoOff: false,
          });
        }

        try {
          const { sdp } = message.payload;
          await pc.setRemoteDescription(new RTCSessionDescription(sdp));
          
          const answer = await pc.createAnswer();
          await pc.setLocalDescription(answer);
          
          console.log('Sending answer to:', senderId);
          await sendSignal(senderId, 'answer', { sdp: pc.localDescription });
        } catch (err) {
          console.error('Error handling offer:', err);
        }
        break;
      }

      case 'answer': {
        console.log('Received answer from:', senderId);
        const pc = peerConnectionsRef.current.get(senderId);
        
        if (pc) {
          try {
            const { sdp } = message.payload;
            await pc.setRemoteDescription(new RTCSessionDescription(sdp));
          } catch (err) {
            console.error('Error handling answer:', err);
          }
        }
        break;
      }

      case 'ice-candidate': {
        console.log('Received ICE candidate from:', senderId);
        const pc = peerConnectionsRef.current.get(senderId);
        
        if (pc) {
          try {
            const { candidate } = message.payload;
            if (candidate) {
              await pc.addIceCandidate(new RTCIceCandidate(candidate));
            }
          } catch (err) {
            console.error('Error adding ICE candidate:', err);
          }
        }
        break;
      }

      case 'participant-left': {
        console.log('Participant left:', senderId);
        const pc = peerConnectionsRef.current.get(senderId);
        if (pc) {
          pc.close();
          peerConnectionsRef.current.delete(senderId);
        }
        onParticipantLeft?.(senderId);
        break;
      }
    }
  }, [participantId, createPeerConnection, sendSignal, onParticipantJoined, onParticipantLeft]);

  // Poll for signaling messages
  const pollSignals = useCallback(async () => {
    if (!roomCode) return;

    try {
      const { data, error } = await supabase.functions.invoke('video-signaling', {
        body: { 
          action: 'get-signals', 
          roomCode, 
          participantId 
        },
      });

      if (error) {
        console.error('Poll signals error:', error);
        return;
      }

      if (data?.signals && Array.isArray(data.signals)) {
        // Process signals in chronological order
        const sortedSignals = [...data.signals].sort(
          (a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
        );

        for (const signal of sortedSignals) {
          await handleSignalingMessage(signal);
        }
      }
    } catch (err) {
      console.error('Error polling signals:', err);
    }
  }, [roomCode, participantId, handleSignalingMessage]);

  // Start polling for signals
  const startPolling = useCallback(() => {
    if (pollingIntervalRef.current) {
      clearInterval(pollingIntervalRef.current);
    }

    // Poll immediately
    pollSignals();

    // Then poll every 1 second
    pollingIntervalRef.current = setInterval(pollSignals, 1000);
  }, [pollSignals]);

  // Stop polling
  const stopPolling = useCallback(() => {
    if (pollingIntervalRef.current) {
      clearInterval(pollingIntervalRef.current);
      pollingIntervalRef.current = null;
    }
  }, []);

  // Subscribe to realtime changes (backup/enhancement to polling)
  const subscribeToRoom = useCallback(() => {
    if (channelRef.current) {
      supabase.removeChannel(channelRef.current);
    }

    const channel = supabase
      .channel(`room:${roomCode}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'signaling_messages',
          filter: `room_code=eq.${roomCode}`,
        },
        (payload) => {
          console.log('Realtime signal received:', payload);
          if (payload.new) {
            handleSignalingMessage(payload.new as SignalingMessage);
          }
        }
      )
      .subscribe((status) => {
        console.log('Realtime subscription status:', status);
        if (status === 'SUBSCRIBED') {
          setIsConnected(true);
        }
      });

    channelRef.current = channel;
  }, [roomCode, handleSignalingMessage]);

  // Join an existing room
  const joinRoom = useCallback(async (localStream: MediaStream) => {
    localStreamRef.current = localStream;
    processedMessagesRef.current.clear();

    // Fetch TURN credentials before joining
    await fetchTurnCredentials();
    scheduleCredentialRefresh();

    try {
      const { data, error } = await supabase.functions.invoke('video-signaling', {
        body: { 
          action: 'join-room', 
          roomCode, 
          participantId, 
          displayName 
        },
      });

      if (error) {
        console.error('Join room error:', error);
        onError?.(new Error('Failed to join room'));
        setIsConnected(true); // Still allow local video
        return data;
      }

      console.log('Joined room:', data);

      // Create peer connections for existing participants
      if (data?.participants && Array.isArray(data.participants)) {
        for (const p of data.participants) {
          if (p.participant_id !== participantId) {
            console.log('Creating connection for existing participant:', p.participant_id);
            createPeerConnection(p.participant_id);
            
            onParticipantJoined?.({
              id: p.participant_id,
              name: p.display_name || 'Guest',
              isLocal: false,
              isMuted: false,
              isVideoOff: false,
            });
          }
        }
      }

      // Subscribe to realtime updates
      subscribeToRoom();
      
      // Start polling for signals
      startPolling();

      setIsConnected(true);
      return data;
    } catch (err) {
      console.error('Failed to join room:', err);
      onError?.(err instanceof Error ? err : new Error('Failed to join room'));
      setIsConnected(true); // Still allow local video
    }
  }, [roomCode, participantId, displayName, fetchTurnCredentials, scheduleCredentialRefresh, createPeerConnection, subscribeToRoom, startPolling, onParticipantJoined, onError]);

  // Create a new room
  const createRoom = useCallback(async (localStream: MediaStream) => {
    localStreamRef.current = localStream;
    processedMessagesRef.current.clear();

    // Fetch TURN credentials before creating room
    await fetchTurnCredentials();
    scheduleCredentialRefresh();

    try {
      const { data, error } = await supabase.functions.invoke('video-signaling', {
        body: { 
          action: 'create-room', 
          roomCode, 
          participantId, 
          displayName 
        },
      });

      if (error) {
        console.error('Create room error:', error);
        onError?.(new Error('Failed to create room'));
        setIsConnected(true); // Still allow local video
        return data;
      }

      console.log('Created room:', data);

      // Subscribe to realtime updates
      subscribeToRoom();
      
      // Start polling for signals
      startPolling();

      setIsConnected(true);
      return data;
    } catch (err) {
      console.error('Failed to create room:', err);
      onError?.(err instanceof Error ? err : new Error('Failed to create room'));
      setIsConnected(true); // Still allow local video
    }
  }, [roomCode, participantId, displayName, fetchTurnCredentials, scheduleCredentialRefresh, subscribeToRoom, startPolling, onError]);

  // Leave the room
  const leaveRoom = useCallback(async () => {
    stopPolling();

    // Clear credential refresh timer
    if (credentialRefreshIntervalRef.current) {
      clearTimeout(credentialRefreshIntervalRef.current);
      credentialRefreshIntervalRef.current = null;
    }

    try {
      await supabase.functions.invoke('video-signaling', {
        body: { 
          action: 'leave-room', 
          roomCode, 
          participantId 
        },
      });
    } catch (err) {
      console.error('Error leaving room:', err);
    }

    // Close all peer connections
    peerConnectionsRef.current.forEach((pc) => {
      pc.close();
    });
    peerConnectionsRef.current.clear();

    // Stop local stream
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach(track => track.stop());
      localStreamRef.current = null;
    }

    // Unsubscribe from realtime
    if (channelRef.current) {
      supabase.removeChannel(channelRef.current);
      channelRef.current = null;
    }

    // Clear processed messages
    processedMessagesRef.current.clear();
    isNegotiatingRef.current.clear();

    setParticipants([]);
    setIsConnected(false);
    setConnectionState('closed');
    setIceConnectionType('unknown');
  }, [roomCode, participantId, stopPolling]);

  // Force TURN relay (for testing or when direct connection fails)
  const forceTurnRelay = useCallback(async () => {
    console.log('Forcing TURN relay mode...');
    
    // Update ICE configuration to relay-only
    const currentConfig = iceServersRef.current;
    iceServersRef.current = {
      ...currentConfig,
      iceTransportPolicy: 'relay'
    };

    // Restart ICE on all connections
    peerConnectionsRef.current.forEach((pc, peerId) => {
      console.log('Restarting ICE (relay-only) for peer:', peerId);
      pc.restartIce();
    });
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopPolling();
      
      if (credentialRefreshIntervalRef.current) {
        clearTimeout(credentialRefreshIntervalRef.current);
      }
      
      peerConnectionsRef.current.forEach((pc) => {
        pc.close();
      });
      peerConnectionsRef.current.clear();

      if (localStreamRef.current) {
        localStreamRef.current.getTracks().forEach(track => track.stop());
      }

      if (channelRef.current) {
        supabase.removeChannel(channelRef.current);
      }
    };
  }, [stopPolling]);

  return {
    isConnected,
    participants,
    connectionState,
    iceConnectionType,
    turnProvider,
    joinRoom,
    createRoom,
    leaveRoom,
    forceTurnRelay,
    peerConnections: peerConnectionsRef.current,
  };
}
