import { useState, useEffect, useRef, useCallback } from 'react';

interface UseNoiseCancellationOptions {
  inputStream: MediaStream | null;
  enabled: boolean;
}

interface NoiseStats {
  inputLevel: number;
  outputLevel: number;
  noiseReduction: number;
}

export function useNoiseCancellation({ inputStream, enabled }: UseNoiseCancellationOptions) {
  const [isProcessing, setIsProcessing] = useState(false);
  const [processedStream, setProcessedStream] = useState<MediaStream | null>(null);
  const [noiseStats, setNoiseStats] = useState<NoiseStats>({ inputLevel: 0, outputLevel: 0, noiseReduction: 0 });
  const [error, setError] = useState<string | null>(null);

  const audioContextRef = useRef<AudioContext | null>(null);
  const sourceNodeRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const destinationNodeRef = useRef<MediaStreamAudioDestinationNode | null>(null);
  const analyserInputRef = useRef<AnalyserNode | null>(null);
  const analyserOutputRef = useRef<AnalyserNode | null>(null);
  const noiseGateRef = useRef<GainNode | null>(null);
  const highPassFilterRef = useRef<BiquadFilterNode | null>(null);
  const lowPassFilterRef = useRef<BiquadFilterNode | null>(null);
  const compressorRef = useRef<DynamicsCompressorNode | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  // Initialize audio processing pipeline
  const initializeAudioProcessing = useCallback(async () => {
    if (!inputStream) return;

    try {
      setError(null);
      
      // Create audio context
      const audioContext = new AudioContext({ sampleRate: 48000 });
      audioContextRef.current = audioContext;

      // Create source from input stream
      const audioTrack = inputStream.getAudioTracks()[0];
      if (!audioTrack) {
        throw new Error('No audio track found in input stream');
      }

      const sourceStream = new MediaStream([audioTrack]);
      const source = audioContext.createMediaStreamSource(sourceStream);
      sourceNodeRef.current = source;

      // Create destination for processed audio
      const destination = audioContext.createMediaStreamDestination();
      destinationNodeRef.current = destination;

      // Create input analyser for level monitoring
      const analyserInput = audioContext.createAnalyser();
      analyserInput.fftSize = 2048;
      analyserInput.smoothingTimeConstant = 0.8;
      analyserInputRef.current = analyserInput;

      // Create output analyser for level monitoring
      const analyserOutput = audioContext.createAnalyser();
      analyserOutput.fftSize = 2048;
      analyserOutput.smoothingTimeConstant = 0.8;
      analyserOutputRef.current = analyserOutput;

      // High-pass filter to remove low-frequency rumble (below 80Hz)
      const highPassFilter = audioContext.createBiquadFilter();
      highPassFilter.type = 'highpass';
      highPassFilter.frequency.value = 80;
      highPassFilter.Q.value = 0.7;
      highPassFilterRef.current = highPassFilter;

      // Low-pass filter to remove high-frequency hiss (above 12kHz)
      const lowPassFilter = audioContext.createBiquadFilter();
      lowPassFilter.type = 'lowpass';
      lowPassFilter.frequency.value = 12000;
      lowPassFilter.Q.value = 0.7;
      lowPassFilterRef.current = lowPassFilter;

      // Noise gate to suppress low-level background noise
      const noiseGate = audioContext.createGain();
      noiseGate.gain.value = 1;
      noiseGateRef.current = noiseGate;

      // Dynamics compressor for consistent volume levels
      const compressor = audioContext.createDynamicsCompressor();
      compressor.threshold.value = -24;
      compressor.knee.value = 30;
      compressor.ratio.value = 12;
      compressor.attack.value = 0.003;
      compressor.release.value = 0.25;
      compressorRef.current = compressor;

      // Connect the audio processing chain
      source.connect(analyserInput);
      analyserInput.connect(highPassFilter);
      highPassFilter.connect(lowPassFilter);
      lowPassFilter.connect(noiseGate);
      noiseGate.connect(compressor);
      compressor.connect(analyserOutput);
      analyserOutput.connect(destination);

      // Create processed stream with original video (if any) and processed audio
      const videoTrack = inputStream.getVideoTracks()[0];
      const processedTracks: MediaStreamTrack[] = [...destination.stream.getAudioTracks()];
      if (videoTrack) {
        processedTracks.push(videoTrack);
      }
      const newProcessedStream = new MediaStream(processedTracks);
      setProcessedStream(newProcessedStream);
      setIsProcessing(true);

      // Start level monitoring
      startLevelMonitoring();

    } catch (err) {
      console.error('Error initializing noise cancellation:', err);
      setError(err instanceof Error ? err.message : 'Failed to initialize noise cancellation');
      setIsProcessing(false);
    }
  }, [inputStream]);

  // Start monitoring audio levels
  const startLevelMonitoring = useCallback(() => {
    const updateLevels = () => {
      if (!analyserInputRef.current || !analyserOutputRef.current) return;

      const inputData = new Uint8Array(analyserInputRef.current.frequencyBinCount);
      const outputData = new Uint8Array(analyserOutputRef.current.frequencyBinCount);

      analyserInputRef.current.getByteFrequencyData(inputData);
      analyserOutputRef.current.getByteFrequencyData(outputData);

      // Calculate RMS levels
      const inputLevel = calculateRMS(inputData);
      const outputLevel = calculateRMS(outputData);
      const noiseReduction = inputLevel > 0 ? Math.max(0, ((inputLevel - outputLevel) / inputLevel) * 100) : 0;

      setNoiseStats({
        inputLevel: Math.round(inputLevel),
        outputLevel: Math.round(outputLevel),
        noiseReduction: Math.round(noiseReduction),
      });

      // Apply dynamic noise gate based on input level
      if (noiseGateRef.current) {
        // If input level is very low, it's likely just noise - reduce gain
        const threshold = 15; // Noise threshold
        if (inputLevel < threshold) {
          noiseGateRef.current.gain.setTargetAtTime(0.1, audioContextRef.current?.currentTime || 0, 0.01);
        } else {
          noiseGateRef.current.gain.setTargetAtTime(1, audioContextRef.current?.currentTime || 0, 0.01);
        }
      }

      animationFrameRef.current = requestAnimationFrame(updateLevels);
    };

    updateLevels();
  }, []);

  // Calculate RMS (Root Mean Square) for audio level
  const calculateRMS = (data: Uint8Array): number => {
    let sum = 0;
    for (let i = 0; i < data.length; i++) {
      sum += data[i] * data[i];
    }
    return Math.sqrt(sum / data.length);
  };

  // Cleanup audio processing
  const cleanup = useCallback(() => {
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }

    if (sourceNodeRef.current) {
      sourceNodeRef.current.disconnect();
      sourceNodeRef.current = null;
    }

    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      audioContextRef.current.close();
      audioContextRef.current = null;
    }

    analyserInputRef.current = null;
    analyserOutputRef.current = null;
    highPassFilterRef.current = null;
    lowPassFilterRef.current = null;
    noiseGateRef.current = null;
    compressorRef.current = null;
    destinationNodeRef.current = null;

    setProcessedStream(null);
    setIsProcessing(false);
    setNoiseStats({ inputLevel: 0, outputLevel: 0, noiseReduction: 0 });
  }, []);

  // Effect to handle enabling/disabling noise cancellation
  useEffect(() => {
    if (enabled && inputStream) {
      initializeAudioProcessing();
    } else {
      cleanup();
    }

    return () => {
      cleanup();
    };
  }, [enabled, inputStream, initializeAudioProcessing, cleanup]);

  return {
    isProcessing,
    processedStream,
    noiseStats,
    error,
  };
}

export default useNoiseCancellation;
