import React, { useState, useEffect } from 'react';
import { loadStripe } from '@stripe/stripe-js';
import { Elements, PaymentElement, useStripe, useElements } from '@stripe/react-stripe-js';
import { X, Crown, Building2, Loader2, Check, AlertCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';

// Initialize Stripe with the publishable key and connected account
const stripePromise = loadStripe('pk_live_51OJhJBHdGQpsHqInIzu7c6PzGPSH0yImD4xfpofvxvFZs0VFhPRXZCyEgYkkhOtBOXFWvssYASs851mflwQvjnrl00T6DbUwWZ', {
  stripeAccount: 'acct_1SgGd7HtkmPIWYN3'
});

interface SubscriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
  planType: 'pro' | 'enterprise';
}

interface PaymentFormProps {
  customerId: string;
  planType: 'pro' | 'enterprise';
  onSuccess: () => void;
  onCancel: () => void;
}

// Payment form component - used inside Elements provider
const PaymentForm: React.FC<PaymentFormProps> = ({ customerId, planType, onSuccess, onCancel }) => {
  const stripe = useStripe();
  const elements = useElements();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!stripe || !elements) return;
    setLoading(true);
    setError(null);

    try {
      // Confirm the SetupIntent to save payment method
      const { error: setupError, setupIntent } = await stripe.confirmSetup({
        elements,
        confirmParams: { return_url: window.location.origin },
        redirect: 'if_required',
      });

      if (setupError) {
        setError(setupError.message || 'Payment setup failed');
        setLoading(false);
        return;
      }

      // If setup succeeded, create the subscription
      if (setupIntent?.status === 'succeeded') {
        const { data, error: subError } = await supabase.functions.invoke('create-subscription', {
          body: { 
            action: 'activate-subscription', 
            customerId,
            planType
          }
        });

        if (subError || data?.error) {
          setError(data?.error || subError?.message || 'Failed to activate subscription');
          setLoading(false);
          return;
        }
        onSuccess();
      }
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="bg-gray-50 rounded-xl p-4">
        <PaymentElement 
          options={{ 
            layout: 'tabs',
          }} 
        />
      </div>
      
      {error && (
        <div className="flex items-center gap-2 p-4 bg-red-50 border border-red-200 rounded-xl text-red-700">
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <span className="text-sm">{error}</span>
        </div>
      )}
      
      <div className="flex gap-3">
        <button 
          type="button" 
          onClick={onCancel}
          disabled={loading}
          className="flex-1 px-4 py-3 border border-gray-300 rounded-xl font-medium text-gray-700 hover:bg-gray-50 transition-colors disabled:opacity-50"
        >
          Cancel
        </button>
        <button 
          type="submit" 
          disabled={!stripe || loading}
          className="flex-1 px-4 py-3 bg-indigo-600 text-white rounded-xl font-medium hover:bg-indigo-700 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
        >
          {loading ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              Processing...
            </>
          ) : (
            'Subscribe Now'
          )}
        </button>
      </div>
    </form>
  );
};

const SubscriptionModal: React.FC<SubscriptionModalProps> = ({ isOpen, onClose, planType }) => {
  const [step, setStep] = useState<'info' | 'payment' | 'success'>('info');
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [clientSecret, setClientSecret] = useState<string | null>(null);
  const [customerId, setCustomerId] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();

  // Pre-fill email if user is logged in
  useEffect(() => {
    if (user?.email) {
      setEmail(user.email);
    }
  }, [user]);

  // Reset state when modal opens/closes
  useEffect(() => {
    if (!isOpen) {
      setStep('info');
      setClientSecret(null);
      setCustomerId(null);
      setError(null);
    }
  }, [isOpen]);

  const planDetails = {
    pro: {
      name: 'Pro',
      price: '$9.99',
      icon: <Crown className="w-8 h-8 text-indigo-600" />,
      features: [
        'Unlimited video calls',
        'HD video quality',
        'Advanced noise cancellation',
        'Priority support',
      ],
    },
    enterprise: {
      name: 'Enterprise',
      price: '$29.99',
      icon: <Building2 className="w-8 h-8 text-purple-600" />,
      features: [
        'Everything in Pro',
        'Team collaboration',
        'Analytics dashboard',
        'Custom branding',
      ],
    },
  };

  const plan = planDetails[planType];

  const handleStartSubscription = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setLoading(true);
    setError(null);

    try {
      const { data, error: fnError } = await supabase.functions.invoke('create-subscription', {
        body: { 
          email, 
          name,
          planType,
          action: 'create-setup-intent' 
        }
      });
      
      if (fnError || data?.error) {
        throw new Error(data?.error || fnError?.message || 'Failed to initialize payment');
      }
      
      setClientSecret(data.clientSecret);
      setCustomerId(data.customerId);
      setStep('payment');
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred');
    } finally {
      setLoading(false);
    }
  };

  const handleSuccess = () => {
    setStep('success');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        onClick={onClose}
      />
      
      {/* Modal */}
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden">
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-gray-400 hover:text-gray-600 transition-colors z-10"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Success State */}
        {step === 'success' && (
          <div className="p-8 text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <Check className="w-8 h-8 text-green-600" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Welcome to {plan.name}!</h2>
            <p className="text-gray-600 mb-6">
              Your subscription is now active. Enjoy unlimited access to all {plan.name} features.
            </p>
            <button
              onClick={onClose}
              className="w-full py-3 px-6 bg-indigo-600 text-white rounded-xl font-semibold hover:bg-indigo-700 transition-colors"
            >
              Start Using ClearSpeak
            </button>
          </div>
        )}

        {/* Info Step */}
        {step === 'info' && (
          <div className="p-8">
            {/* Plan Header */}
            <div className="flex items-center gap-4 mb-6">
              <div className="p-3 bg-indigo-50 rounded-xl">
                {plan.icon}
              </div>
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Upgrade to {plan.name}</h2>
                <p className="text-gray-500">{plan.price}/month</p>
              </div>
            </div>

            {/* Features */}
            <div className="bg-gray-50 rounded-xl p-4 mb-6">
              <p className="text-sm font-medium text-gray-700 mb-3">What you'll get:</p>
              <ul className="space-y-2">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-center gap-2 text-sm text-gray-600">
                    <Check className="w-4 h-4 text-green-500" />
                    {feature}
                  </li>
                ))}
              </ul>
            </div>

            {/* Email Form */}
            <form onSubmit={handleStartSubscription} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="John Doe"
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Email Address <span className="text-red-500">*</span>
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors"
                />
              </div>

              {error && (
                <div className="flex items-center gap-2 p-4 bg-red-50 border border-red-200 rounded-xl text-red-700">
                  <AlertCircle className="w-5 h-5 flex-shrink-0" />
                  <span className="text-sm">{error}</span>
                </div>
              )}

              <button
                type="submit"
                disabled={loading || !email}
                className="w-full py-3 px-6 bg-indigo-600 text-white rounded-xl font-semibold hover:bg-indigo-700 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Loading...
                  </>
                ) : (
                  'Continue to Payment'
                )}
              </button>
            </form>

            <p className="text-xs text-gray-500 text-center mt-4">
              By subscribing, you agree to our Terms of Service and Privacy Policy.
              Cancel anytime.
            </p>
          </div>
        )}

        {/* Payment Step */}
        {step === 'payment' && clientSecret && customerId && (
          <div className="p-8">
            <div className="flex items-center gap-4 mb-6">
              <div className="p-3 bg-indigo-50 rounded-xl">
                {plan.icon}
              </div>
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Payment Details</h2>
                <p className="text-gray-500">{plan.name} - {plan.price}/month</p>
              </div>
            </div>

            <Elements 
              stripe={stripePromise} 
              options={{ 
                clientSecret,
                appearance: { 
                  theme: 'stripe',
                  variables: {
                    colorPrimary: '#4f46e5',
                    borderRadius: '12px',
                  }
                }
              }}
            >
              <PaymentForm 
                customerId={customerId}
                planType={planType}
                onSuccess={handleSuccess} 
                onCancel={() => { 
                  setStep('info'); 
                  setClientSecret(null); 
                }}
              />
            </Elements>

            <div className="mt-6 flex items-center justify-center gap-2 text-gray-400">
              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 5.225-3.34 9.67-8 11.317C5.34 16.67 2 12.225 2 7c0-.682.057-1.35.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
              </svg>
              <span className="text-xs">Secured by Stripe</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default SubscriptionModal;
