import React, { useState, useRef, useEffect } from 'react';
import { Message, Settings } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { 
  userService, 
  conversationsService, 
  DbConversation 
} from '@/lib/database';
import Header from './Header';
import HeroSection from './HeroSection';
import CommunicationPanel from './CommunicationPanel';
import QuickPhrasesSection from './QuickPhrasesSection';
import FeaturesSection from './FeaturesSection';
import ASLLearningSection from './ASLLearningSection';
import ASLTranslator from './ASLTranslator';
import VideoCallSection from './VideoCallSection';
import EmergencySection from './EmergencySection';
import SettingsModal from './SettingsModal';
import MobileMenu from './MobileMenu';
import AuthModal from './AuthModal';
import Footer from './Footer';
import PricingSection from './PricingSection';
import UsageTracker from './UsageTracker';
import SubscriptionModal from './SubscriptionModal';
import InstallPrompt from './InstallPrompt';

const AppLayout: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [showSettings, setShowSettings] = useState(false);
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<'pro' | 'enterprise'>('pro');
  const [isLoading, setIsLoading] = useState(true);
  const [settings, setSettings] = useState<Settings>({
    textSize: 'medium',
    theme: 'light',
    vibrationEnabled: true,
    speechRate: 1,
    speechPitch: 1,
    speechVolume: 1,
    preferredMode: 'both',
  });

  const communicationRef = useRef<HTMLDivElement>(null);
  const { anonymousId, isAuthenticated, user } = useAuth();
  
  // Use authenticated user ID if available, otherwise use anonymous ID
  const userId = user?.id || anonymousId;

  // Initialize user and load data
  useEffect(() => {
    const initializeUser = async () => {
      setIsLoading(true);
      
      // Get or create user
      await userService.getOrCreateUser(userId);
      
      // Load settings
      const savedSettings = await userService.getSettings(userId);
      if (savedSettings) {
        setSettings(savedSettings);
        applySettings(savedSettings);
      }
      
      // Load conversation history
      const conversations = await conversationsService.getRecent(userId);
      const loadedMessages: Message[] = conversations.map((conv: DbConversation) => ({
        id: conv.id,
        text: conv.text,
        sender: conv.sender,
        type: conv.message_type,
        timestamp: new Date(conv.created_at),
      }));
      setMessages(loadedMessages);
      
      setIsLoading(false);
    };

    initializeUser();

    // Subscribe to real-time conversation changes
    const unsubscribe = conversationsService.subscribeToChanges(userId, (conversations) => {
      const updatedMessages: Message[] = conversations.map((conv: DbConversation) => ({
        id: conv.id,
        text: conv.text,
        sender: conv.sender,
        type: conv.message_type,
        timestamp: new Date(conv.created_at),
      }));
      setMessages(updatedMessages);
    });

    return () => {
      unsubscribe();
    };
  }, [userId]);

  const applySettings = (newSettings: Settings) => {
    document.documentElement.style.setProperty('--base-font-size', 
      newSettings.textSize === 'small' ? '14px' :
      newSettings.textSize === 'medium' ? '16px' :
      newSettings.textSize === 'large' ? '18px' : '20px'
    );
    
    // Apply theme
    if (newSettings.theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    
    if (newSettings.theme === 'high-contrast') {
      document.documentElement.classList.add('high-contrast');
    } else {
      document.documentElement.classList.remove('high-contrast');
    }
  };

  const handleAddMessage = async (message: Omit<Message, 'id' | 'timestamp'>) => {
    // Add to database
    const savedMessage = await conversationsService.add(userId, message);
    
    if (savedMessage) {
      const newMessage: Message = {
        id: savedMessage.id,
        text: savedMessage.text,
        sender: savedMessage.sender,
        type: savedMessage.message_type,
        timestamp: new Date(savedMessage.created_at),
      };
      
      // Update local state (will also be updated by subscription)
      setMessages(prev => [...prev, newMessage].slice(-20));
    }
  };

  const handleClearMessages = async () => {
    await conversationsService.clearAll(userId);
    setMessages([]);
  };

  const handleStartCommunicating = () => {
    communicationRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleUpdateSettings = async (newSettings: Settings) => {
    setSettings(newSettings);
    applySettings(newSettings);
    
    // Save to database
    await userService.updateSettings(userId, newSettings);
  };

  const handleUpgrade = (plan: 'pro' | 'enterprise' = 'pro') => {
    setSelectedPlan(plan);
    setShowSubscriptionModal(true);
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <Header
        onOpenSettings={() => setShowSettings(true)}
        onOpenMenu={() => setShowMobileMenu(true)}
        onOpenAuth={() => setShowAuthModal(true)}
      />

      {/* Hero Section */}
      <HeroSection onStartCommunicating={handleStartCommunicating} />

      {/* Features Section */}
      <FeaturesSection />

      {/* Communication Panel */}
      <div ref={communicationRef} id="communicate">
        <CommunicationPanel
          messages={messages}
          onAddMessage={handleAddMessage}
          onClearMessages={handleClearMessages}
          isLoading={isLoading}
        />
      </div>

      {/* Quick Phrases Section */}
      <QuickPhrasesSection onAddMessage={handleAddMessage} />

      {/* Video Call Section */}
      <VideoCallSection />

      {/* ASL Translator Section */}
      <ASLTranslator />

      {/* ASL Learning Section */}
      <ASLLearningSection />

      {/* Pricing Section */}
      <PricingSection />

      {/* Usage Tracker Section - Only show for authenticated users */}
      {isAuthenticated && (
        <section className="py-12 bg-gray-50">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <UsageTracker onUpgrade={() => handleUpgrade('pro')} />
          </div>
        </section>
      )}

      {/* Emergency Section */}
      <EmergencySection />

      {/* Footer */}
      <Footer />

      {/* Settings Modal */}
      <SettingsModal
        isOpen={showSettings}
        onClose={() => setShowSettings(false)}
        settings={settings}
        onUpdateSettings={handleUpdateSettings}
      />

      {/* Mobile Menu */}
      <MobileMenu
        isOpen={showMobileMenu}
        onClose={() => setShowMobileMenu(false)}
        onOpenSettings={() => setShowSettings(true)}
      />

      {/* Auth Modal */}
      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
      />

      {/* Subscription Modal */}
      <SubscriptionModal
        isOpen={showSubscriptionModal}
        onClose={() => setShowSubscriptionModal(false)}
        planType={selectedPlan}
      />

      {/* PWA Install Prompt */}
      <InstallPrompt />

      {/* Sync Status Indicator */}
      {isAuthenticated && (
        <div className="fixed bottom-4 right-4 z-40">
          <div className="flex items-center gap-2 px-3 py-2 bg-green-100 text-green-700 rounded-full text-sm font-medium shadow-lg">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
            Synced
          </div>
        </div>
      )}
    </div>

  );
};

export default AppLayout;
