import React, { useState, useEffect } from 'react';
import { useTextToSpeech } from '@/hooks/useTextToSpeech';
import { useAuth } from '@/contexts/AuthContext';
import { contactsService, DbEmergencyContact } from '@/lib/database';
import {
  AlertIcon,
  PhoneIcon,
  LocationIcon,
  SpeakerIcon,
  PlusIcon,
  TrashIcon,
} from './icons/Icons';

const EmergencySection: React.FC = () => {
  const [contacts, setContacts] = useState<DbEmergencyContact[]>([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newContact, setNewContact] = useState({ name: '', phone: '', relationship: '' });
  const [locationShared, setLocationShared] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const { speak, isSpeaking } = useTextToSpeech();
  const { anonymousId, user } = useAuth();
  const userId = user?.id || anonymousId;

  const emergencyPhrases = [
    { text: 'I need help immediately!', priority: 'high' },
    { text: 'Please call 911!', priority: 'high' },
    { text: 'I am deaf and need assistance.', priority: 'medium' },
    { text: 'I have a medical emergency.', priority: 'high' },
    { text: 'I am lost and need directions.', priority: 'medium' },
    { text: 'Please contact my emergency contact.', priority: 'medium' },
  ];

  // Load contacts from database
  useEffect(() => {
    const loadContacts = async () => {
      setIsLoading(true);
      const dbContacts = await contactsService.getAll(userId);
      setContacts(dbContacts);
      setIsLoading(false);
    };

    loadContacts();

    // Subscribe to real-time changes
    const unsubscribe = contactsService.subscribeToChanges(userId, (updatedContacts) => {
      setContacts(updatedContacts);
    });

    return () => {
      unsubscribe();
    };
  }, [userId]);

  const handleAddContact = async () => {
    if (newContact.name && newContact.phone) {
      setIsSaving(true);
      const contact = await contactsService.add(userId, {
        name: newContact.name,
        phone: newContact.phone,
        relationship: newContact.relationship,
      });
      if (contact) {
        setNewContact({ name: '', phone: '', relationship: '' });
        setShowAddForm(false);
      }
      setIsSaving(false);
    }
  };

  const handleDeleteContact = async (id: string) => {
    await contactsService.delete(id);
  };

  const handleShareLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocationShared(true);
          setTimeout(() => setLocationShared(false), 3000);
          // In a real app, this would send the location to emergency contacts
          console.log('Location shared:', position.coords);
        },
        (error) => {
          console.error('Error getting location:', error);
          alert('Unable to get your location. Please enable location services.');
        }
      );
    }
  };

  const handleEmergencyPhrase = (text: string) => {
    speak(text);
    // Vibrate if supported
    if (navigator.vibrate) {
      navigator.vibrate([200, 100, 200]);
    }
  };

  return (
    <section id="emergency" className="py-12 sm:py-20 bg-gradient-to-br from-red-50 to-orange-50">

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-red-100 text-red-600 rounded-full mb-4">
            <AlertIcon size={18} />
            <span className="font-medium">Emergency Features</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-[#1a2332] mb-4">
            Quick Emergency Access
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Stay prepared with instant access to emergency phrases, contacts, 
            and location sharing. Your safety is our priority.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Emergency Phrases */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-xl">
            <h3 className="text-xl font-bold text-[#1a2332] mb-6 flex items-center gap-2">
              <SpeakerIcon size={24} className="text-red-500" />
              Emergency Phrases
            </h3>
            <div className="space-y-3">
              {emergencyPhrases.map((phrase, index) => (
                <button
                  key={index}
                  onClick={() => handleEmergencyPhrase(phrase.text)}
                  disabled={isSpeaking}
                  className={`w-full flex items-center justify-between p-4 rounded-xl border-2 transition-all duration-200 hover:scale-[1.01] disabled:opacity-50 ${
                    phrase.priority === 'high'
                      ? 'border-red-200 bg-red-50 hover:bg-red-100 hover:border-red-300'
                      : 'border-orange-200 bg-orange-50 hover:bg-orange-100 hover:border-orange-300'
                  }`}
                >
                  <span className={`font-medium text-lg ${
                    phrase.priority === 'high' ? 'text-red-700' : 'text-orange-700'
                  }`}>
                    {phrase.text}
                  </span>
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    phrase.priority === 'high' ? 'bg-red-500' : 'bg-orange-500'
                  }`}>
                    <SpeakerIcon size={18} className="text-white" />
                  </div>
                </button>
              ))}
            </div>

            {/* Location Sharing */}
            <div className="mt-6 pt-6 border-t border-gray-200">
              <button
                onClick={handleShareLocation}
                className={`w-full flex items-center justify-center gap-3 p-4 rounded-xl font-semibold transition-all duration-200 ${
                  locationShared
                    ? 'bg-green-500 text-white'
                    : 'bg-[#1a2332] text-white hover:bg-[#2d3e50]'
                }`}
              >
                <LocationIcon size={20} />
                {locationShared ? 'Location Shared!' : 'Share My Location'}
              </button>
              <p className="text-sm text-gray-500 text-center mt-2">
                Shares your current location with emergency contacts
              </p>
            </div>
          </div>

          {/* Emergency Contacts */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-xl">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-[#1a2332] flex items-center gap-2">
                <PhoneIcon size={24} className="text-[#00bfa5]" />
                Emergency Contacts
                {isLoading && (
                  <span className="w-2 h-2 bg-[#00bfa5] rounded-full animate-pulse"></span>
                )}
              </h3>
              <button
                onClick={() => setShowAddForm(true)}
                className="flex items-center gap-2 px-4 py-2 bg-[#00bfa5] text-white rounded-xl font-medium hover:bg-[#00a08a] transition-colors"
              >
                <PlusIcon size={16} />
                Add
              </button>
            </div>

            <div className="space-y-4">
              {isLoading ? (
                <div className="flex items-center justify-center py-8">
                  <div className="animate-spin w-8 h-8 border-2 border-[#00bfa5] border-t-transparent rounded-full"></div>
                </div>
              ) : (
                <>
                  {contacts.map((contact) => (
                    <div
                      key={contact.id}
                      className="flex items-center justify-between p-4 bg-gray-50 rounded-xl border border-gray-200"
                    >
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-[#00bfa5]/20 rounded-full flex items-center justify-center">
                          <span className="text-lg font-bold text-[#00bfa5]">
                            {contact.name.charAt(0)}
                          </span>
                        </div>
                        <div>
                          <h4 className="font-semibold text-[#1a2332]">{contact.name}</h4>
                          <p className="text-sm text-gray-500">{contact.phone}</p>
                          {contact.relationship && (
                            <span className="inline-block px-2 py-0.5 bg-gray-200 text-gray-600 rounded text-xs mt-1">
                              {contact.relationship}
                            </span>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <a
                          href={`tel:${contact.phone}`}
                          className="w-10 h-10 bg-green-500 hover:bg-green-600 rounded-full flex items-center justify-center transition-colors"
                        >
                          <PhoneIcon size={18} className="text-white" />
                        </a>
                        <button
                          onClick={() => handleDeleteContact(contact.id)}
                          className="w-10 h-10 bg-gray-200 hover:bg-red-100 hover:text-red-500 rounded-full flex items-center justify-center transition-colors text-gray-500"
                        >
                          <TrashIcon size={18} />
                        </button>
                      </div>
                    </div>
                  ))}

                  {/* Add Contact Form */}
                  {showAddForm && (
                    <div className="p-4 bg-[#00bfa5]/5 rounded-xl border-2 border-[#00bfa5]">
                      <h4 className="font-semibold text-[#1a2332] mb-4">Add New Contact</h4>
                      <div className="space-y-3">
                        <input
                          type="text"
                          placeholder="Name"
                          value={newContact.name}
                          onChange={(e) => setNewContact(prev => ({ ...prev, name: e.target.value }))}
                          className="w-full p-3 border border-gray-200 rounded-xl focus:outline-none focus:border-[#00bfa5]"
                        />
                        <input
                          type="tel"
                          placeholder="Phone Number"
                          value={newContact.phone}
                          onChange={(e) => setNewContact(prev => ({ ...prev, phone: e.target.value }))}
                          className="w-full p-3 border border-gray-200 rounded-xl focus:outline-none focus:border-[#00bfa5]"
                        />
                        <input
                          type="text"
                          placeholder="Relationship (optional)"
                          value={newContact.relationship}
                          onChange={(e) => setNewContact(prev => ({ ...prev, relationship: e.target.value }))}
                          className="w-full p-3 border border-gray-200 rounded-xl focus:outline-none focus:border-[#00bfa5]"
                        />
                        <div className="flex gap-2">
                          <button
                            onClick={handleAddContact}
                            disabled={!newContact.name || !newContact.phone || isSaving}
                            className="flex-1 py-3 bg-[#00bfa5] text-white rounded-xl font-medium disabled:opacity-50 hover:bg-[#00a08a] transition-colors flex items-center justify-center gap-2"
                          >
                            {isSaving ? (
                              <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full"></div>
                            ) : null}
                            {isSaving ? 'Saving...' : 'Save Contact'}
                          </button>
                          <button
                            onClick={() => {
                              setShowAddForm(false);
                              setNewContact({ name: '', phone: '', relationship: '' });
                            }}
                            className="px-4 py-3 bg-gray-200 text-gray-600 rounded-xl font-medium hover:bg-gray-300 transition-colors"
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    </div>
                  )}

                  {contacts.length === 0 && !showAddForm && (
                    <div className="text-center py-8 text-gray-500">
                      <PhoneIcon size={48} className="mx-auto mb-4 opacity-50" />
                      <p>No emergency contacts added yet.</p>
                      <p className="text-sm">Add contacts for quick access during emergencies.</p>
                    </div>
                  )}
                </>
              )}
            </div>

            {/* Sync indicator */}
            <div className="mt-4 pt-4 border-t border-gray-200 flex items-center justify-center gap-2 text-xs text-gray-400">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span>Contacts synced across devices</span>
            </div>

            {/* 911 Quick Dial */}
            <div className="mt-6 pt-6 border-t border-gray-200">
              <a
                href="tel:911"
                className="flex items-center justify-center gap-3 p-4 bg-red-500 hover:bg-red-600 text-white rounded-xl font-bold text-lg transition-colors"
              >
                <PhoneIcon size={24} />
                Call 911
              </a>
              <p className="text-sm text-gray-500 text-center mt-2">
                For life-threatening emergencies only
              </p>
            </div>
          </div>
        </div>

        {/* Safety Tips */}
        <div className="mt-12 bg-[#1a2332] rounded-3xl p-6 sm:p-8 text-white">
          <h3 className="text-xl font-bold mb-6">Safety Tips for Deaf Individuals</h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { title: 'Visual Alerts', desc: 'Use flashing lights for doorbells and alarms' },
              { title: 'ID Card', desc: 'Carry a card explaining you are deaf' },
              { title: 'Text 911', desc: 'Many areas support texting 911 for emergencies' },
              { title: 'Video Relay', desc: 'Use VRS for phone calls with interpreters' },
            ].map((tip, index) => (
              <div key={index} className="p-4 bg-white/10 rounded-xl">
                <h4 className="font-semibold text-[#00bfa5] mb-2">{tip.title}</h4>
                <p className="text-sm text-gray-300">{tip.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default EmergencySection;
