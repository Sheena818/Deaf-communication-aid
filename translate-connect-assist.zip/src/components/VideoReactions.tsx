import React from 'react';
import { AnimatedReaction } from '@/hooks/useVideoReactions';

// Common reaction emojis
export const REACTION_EMOJIS = [
  { emoji: '👍', label: 'Thumbs Up' },
  { emoji: '👏', label: 'Clap' },
  { emoji: '❤️', label: 'Heart' },
  { emoji: '😂', label: 'Laugh' },
  { emoji: '😮', label: 'Wow' },
  { emoji: '🎉', label: 'Party' },
  { emoji: '🔥', label: 'Fire' },
  { emoji: '👋', label: 'Wave' },
  { emoji: '✅', label: 'Check' },
  { emoji: '💯', label: '100' },
  { emoji: '🙌', label: 'Raised Hands' },
  { emoji: '💪', label: 'Strong' },
];

// Smile icon for the reactions button
const SmileIcon: React.FC<{ size?: number; className?: string }> = ({ size = 24, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <circle cx="12" cy="12" r="10" />
    <path d="M8 14s1.5 2 4 2 4-2 4-2" />
    <line x1="9" y1="9" x2="9.01" y2="9" />
    <line x1="15" y1="9" x2="15.01" y2="9" />
  </svg>
);

// X icon for closing
const XIcon: React.FC<{ size?: number; className?: string }> = ({ size = 24, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <line x1="18" y1="6" x2="6" y2="18" />
    <line x1="6" y1="6" x2="18" y2="18" />
  </svg>
);

// Reaction Overlay Component - displays animated reactions on the video
export const ReactionOverlay: React.FC<{
  animatedReactions: AnimatedReaction[];
}> = ({ animatedReactions }) => {
  if (animatedReactions.length === 0) return null;
  
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden z-20">
      {animatedReactions.map((reaction) => (
        <div
          key={reaction.id}
          className="absolute animate-reaction-float pointer-events-none"
          style={{
            left: `${reaction.x}%`,
            top: `${reaction.y}%`,
            transform: 'translate(-50%, -50%)',
          }}
        >
          <div className="flex flex-col items-center">
            <span className="text-6xl sm:text-7xl drop-shadow-lg animate-reaction-pulse">
              {reaction.emoji}
            </span>
            <span className={`text-xs font-medium px-2 py-0.5 rounded-full mt-1 ${
              reaction.isLocal 
                ? 'bg-purple-500/80 text-white' 
                : 'bg-gray-800/80 text-white'
            }`}>
              {reaction.isLocal ? 'You' : reaction.senderName}
            </span>
          </div>
        </div>
      ))}
    </div>
  );
};

// Reaction Button with Picker Component - for use in call controls
export const ReactionButton: React.FC<{
  onSelectReaction: (emoji: string) => void;
  isPickerOpen: boolean;
  setIsPickerOpen: (open: boolean) => void;
}> = ({ onSelectReaction, isPickerOpen, setIsPickerOpen }) => {
  return (
    <div className="relative">
      <button
        onClick={() => setIsPickerOpen(!isPickerOpen)}
        className={`p-4 rounded-full transition-all duration-200 hover:scale-110 ${
          isPickerOpen 
            ? 'bg-yellow-500 hover:bg-yellow-600 text-white' 
            : 'bg-gray-700 hover:bg-gray-600 text-white'
        }`}
        title="Send reaction"
      >
        <SmileIcon size={24} />
      </button>

      {/* Reaction Picker */}
      {isPickerOpen && (
        <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-3 z-50">
          <div className="bg-gray-800 rounded-2xl shadow-2xl border border-gray-700 p-3 animate-in fade-in slide-in-from-bottom-2 duration-200">
            {/* Close button */}
            <button
              onClick={() => setIsPickerOpen(false)}
              className="absolute -top-2 -right-2 w-6 h-6 bg-gray-700 hover:bg-gray-600 rounded-full flex items-center justify-center text-gray-400 hover:text-white transition-colors"
            >
              <XIcon size={14} />
            </button>

            {/* Emoji grid */}
            <div className="grid grid-cols-6 gap-1">
              {REACTION_EMOJIS.map((item) => (
                <button
                  key={item.emoji}
                  onClick={() => onSelectReaction(item.emoji)}
                  className="w-12 h-12 flex items-center justify-center text-2xl hover:bg-gray-700 rounded-xl transition-all duration-150 hover:scale-125"
                  title={item.label}
                >
                  {item.emoji}
                </button>
              ))}
            </div>

            {/* Hint text */}
            <p className="text-gray-500 text-xs text-center mt-2">
              Click to react
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

// Re-export the hook for convenience
export { useVideoReactions } from '@/hooks/useVideoReactions';
