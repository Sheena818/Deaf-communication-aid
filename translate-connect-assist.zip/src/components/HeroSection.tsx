import React from 'react';
import { MicrophoneIcon, TextIcon, HandsIcon, VideoIcon, CaptionsIcon } from './icons/Icons';

interface HeroSectionProps {
  onStartCommunicating: () => void;
}

const HeroSection: React.FC<HeroSectionProps> = ({ onStartCommunicating }) => {
  const scrollToVideoCall = () => {
    const element = document.querySelector('#video-call');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-[#1a2332] via-[#243447] to-[#1a2332] text-white">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-20 left-10 w-64 h-64 bg-[#00bfa5] rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-[#ff6b35] rounded-full blur-3xl"></div>
        <div className="absolute top-1/2 left-1/2 w-72 h-72 bg-purple-500 rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-20 lg:py-28">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className="text-center lg:text-left z-10">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 rounded-full mb-6">
              <span className="w-2 h-2 bg-[#00bfa5] rounded-full animate-pulse"></span>
              <span className="text-sm font-medium">Breaking Communication Barriers</span>
            </div>
            
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight mb-6">
              Connect Without
              <span className="block text-transparent bg-clip-text bg-gradient-to-r from-[#00bfa5] to-[#4dd0e1]">
                Boundaries
              </span>
            </h1>
            
            <p className="text-lg sm:text-xl text-gray-300 mb-8 max-w-xl mx-auto lg:mx-0">
              BridgeTalk empowers seamless conversations between hearing and deaf individuals 
              through real-time speech-to-text, text-to-speech, video calling with live captions, and ASL translation.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <button
                onClick={onStartCommunicating}
                className="group flex items-center justify-center gap-3 px-8 py-4 bg-gradient-to-r from-[#00bfa5] to-[#00897b] hover:from-[#00d4b8] hover:to-[#00a08a] rounded-2xl font-bold text-lg transition-all duration-300 hover:scale-105 shadow-xl shadow-[#00bfa5]/25"
              >
                <MicrophoneIcon size={24} />
                Start Communicating
                <span className="group-hover:translate-x-1 transition-transform">→</span>
              </button>
              
              <button 
                onClick={scrollToVideoCall}
                className="flex items-center justify-center gap-3 px-8 py-4 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 rounded-2xl font-semibold text-lg transition-all duration-200 shadow-lg"
              >
                <VideoIcon size={24} />
                Video Call with Captions
              </button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6 mt-12 pt-8 border-t border-white/10">
              <div>
                <div className="text-3xl sm:text-4xl font-bold text-[#00bfa5]">48M+</div>
                <div className="text-sm text-gray-400">Deaf Americans</div>
              </div>
              <div>
                <div className="text-3xl sm:text-4xl font-bold text-[#ff6b35]">95%</div>
                <div className="text-sm text-gray-400">Accuracy Rate</div>
              </div>
              <div>
                <div className="text-3xl sm:text-4xl font-bold text-[#4dd0e1]">Real-time</div>
                <div className="text-sm text-gray-400">Translation</div>
              </div>
            </div>
          </div>

          {/* Hero Image */}
          <div className="relative z-10">
            <div className="relative rounded-3xl overflow-hidden shadow-2xl">
              <img
                src="https://d64gsuwffb70l.cloudfront.net/6945ed0ba05f1477c272f404_1766190438229_a81b2f9f.jpg"
                alt="Two people communicating - one speaking and one using sign language"
                className="w-full h-auto object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#1a2332]/60 to-transparent"></div>
            </div>

            {/* Floating Cards */}
            <div className="absolute -left-4 sm:-left-8 top-1/4 bg-white rounded-2xl p-4 shadow-xl animate-float">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#00bfa5]/20 rounded-full flex items-center justify-center">
                  <MicrophoneIcon className="text-[#00bfa5]" size={20} />
                </div>
                <div>
                  <div className="text-sm font-semibold text-gray-800">Speech to Text</div>
                  <div className="text-xs text-gray-500">Live transcription</div>
                </div>
              </div>
            </div>

            <div className="absolute -right-4 sm:-right-8 top-1/3 bg-white rounded-2xl p-4 shadow-xl animate-float-delayed">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-purple-500/20 rounded-full flex items-center justify-center">
                  <VideoIcon className="text-purple-500" size={20} />
                </div>
                <div>
                  <div className="text-sm font-semibold text-gray-800">Video Calling</div>
                  <div className="text-xs text-gray-500">With live captions</div>
                </div>
              </div>
            </div>

            <div className="absolute -right-4 sm:-right-8 bottom-1/4 bg-white rounded-2xl p-4 shadow-xl animate-float">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#ff6b35]/20 rounded-full flex items-center justify-center">
                  <TextIcon className="text-[#ff6b35]" size={20} />
                </div>
                <div>
                  <div className="text-sm font-semibold text-gray-800">Text to Speech</div>
                  <div className="text-xs text-gray-500">Natural voices</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Wave Decoration */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1440 120" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M0 120L60 105C120 90 240 60 360 45C480 30 600 30 720 37.5C840 45 960 60 1080 67.5C1200 75 1320 75 1380 75L1440 75V120H1380C1320 120 1200 120 1080 120C960 120 840 120 720 120C600 120 480 120 360 120C240 120 120 120 60 120H0Z" fill="white"/>
        </svg>
      </div>

      <style>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-10px); }
        }
        .animate-float {
          animation: float 3s ease-in-out infinite;
        }
        .animate-float-delayed {
          animation: float 3s ease-in-out infinite 1.5s;
        }
      `}</style>
    </section>
  );
};

export default HeroSection;
