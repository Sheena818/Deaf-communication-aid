import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { SettingsIcon, MenuIcon, EarIcon, HeartIcon, UserIcon, LogoutIcon, CloudIcon, ChevronDownIcon, CreditCardIcon } from './icons/Icons';

interface HeaderProps {
  onOpenSettings: () => void;
  onOpenMenu: () => void;
  onOpenAuth: () => void;
}

const Header: React.FC<HeaderProps> = ({ onOpenSettings, onOpenMenu, onOpenAuth }) => {
  const { user, isAuthenticated, signOut } = useAuth();
  const [showUserMenu, setShowUserMenu] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  // Close menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setShowUserMenu(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSignOut = async () => {
    await signOut();
    setShowUserMenu(false);
  };

  return (
    <header className="bg-[#1a2332] text-white shadow-lg sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Logo and Brand */}
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-[#00bfa5] to-[#00897b] rounded-xl flex items-center justify-center shadow-lg">
                <EarIcon className="text-white" size={24} />
              </div>
              <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-[#ff6b35] rounded-full flex items-center justify-center">
                <HeartIcon className="text-white" size={10} />
              </div>
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-bold tracking-tight">
                Bridge<span className="text-[#00bfa5]">Talk</span>
              </h1>
              <p className="text-xs text-gray-400 hidden sm:block">Connecting Every Voice</p>
            </div>
          </div>

          {/* Navigation - Desktop */}
          <nav className="hidden md:flex items-center gap-6">
            <a href="#communicate" className="text-gray-300 hover:text-[#00bfa5] transition-colors font-medium">
              Communicate
            </a>
            <a href="#phrases" className="text-gray-300 hover:text-[#00bfa5] transition-colors font-medium">
              Quick Phrases
            </a>
            <a href="#video-call" className="text-gray-300 hover:text-[#00bfa5] transition-colors font-medium">
              Video Call
            </a>
            <a href="#asl-translator" className="text-gray-300 hover:text-[#00bfa5] transition-colors font-medium">
              ASL Translator
            </a>
            <a href="#pricing" className="text-gray-300 hover:text-[#00bfa5] transition-colors font-medium">
              Pricing
            </a>
          </nav>

          {/* Actions */}
          <div className="flex items-center gap-2 sm:gap-4">
            {/* User Menu / Sign In */}
            {isAuthenticated ? (
              <div className="relative" ref={menuRef}>
                <button
                  onClick={() => setShowUserMenu(!showUserMenu)}
                  className="flex items-center gap-2 px-3 py-2 rounded-xl bg-white/10 hover:bg-white/20 transition-all duration-200"
                >
                  <div className="w-8 h-8 bg-gradient-to-br from-[#00bfa5] to-[#00897b] rounded-full flex items-center justify-center">
                    <UserIcon className="text-white" size={16} />
                  </div>
                  <span className="hidden sm:block text-sm font-medium max-w-[120px] truncate">
                    {user?.displayName || user?.email?.split('@')[0]}
                  </span>
                  <ChevronDownIcon 
                    className={`transition-transform duration-200 ${showUserMenu ? 'rotate-180' : ''}`} 
                    size={16} 
                  />
                </button>

                {showUserMenu && (
                  <div className="absolute right-0 mt-2 w-64 bg-white rounded-xl shadow-xl border border-gray-100 overflow-hidden animate-in fade-in slide-in-from-top-2 duration-200">
                    <div className="p-4 bg-gradient-to-r from-[#00bfa5]/10 to-[#00897b]/10 border-b border-gray-100">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-gradient-to-br from-[#00bfa5] to-[#00897b] rounded-full flex items-center justify-center">
                          <UserIcon className="text-white" size={20} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-gray-800 truncate">
                            {user?.displayName || 'User'}
                          </p>
                          <p className="text-xs text-gray-500 truncate">{user?.email}</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="p-2">
                      <a
                        href="/account"
                        className="w-full flex items-center gap-2 px-3 py-2 text-sm text-gray-700 hover:bg-gray-50 rounded-lg transition-colors"
                      >
                        <UserIcon size={16} />
                        Account Dashboard
                      </a>
                      <a
                        href="/account"
                        className="w-full flex items-center gap-2 px-3 py-2 text-sm text-gray-700 hover:bg-gray-50 rounded-lg transition-colors"
                      >
                        <CreditCardIcon size={16} />
                        Billing & Subscription
                      </a>
                      <div className="flex items-center gap-2 px-3 py-2 text-sm text-[#00bfa5]">
                        <CloudIcon size={16} />
                        <span>Data synced across devices</span>
                      </div>
                      
                      <button
                        onClick={handleSignOut}
                        className="w-full flex items-center gap-2 px-3 py-2 text-sm text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                      >
                        <LogoutIcon size={16} />
                        Sign Out
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <button
                onClick={onOpenAuth}
                className="flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 rounded-xl font-medium transition-all duration-200 hover:scale-105"
              >
                <UserIcon size={18} />
                <span className="hidden sm:inline">Sign In</span>
              </button>
            )}

            <button
              onClick={onOpenSettings}
              className="p-2 sm:p-3 rounded-xl bg-white/10 hover:bg-white/20 transition-all duration-200 hover:scale-105"
              aria-label="Open settings"
            >
              <SettingsIcon className="text-white" size={20} />
            </button>
            <button
              onClick={onOpenMenu}
              className="md:hidden p-2 sm:p-3 rounded-xl bg-white/10 hover:bg-white/20 transition-all duration-200"
              aria-label="Open menu"
            >
              <MenuIcon className="text-white" size={20} />
            </button>
            <a 
              href="#emergency"
              className="hidden sm:flex items-center gap-2 px-4 py-2 bg-[#ff6b35] hover:bg-[#e55a2b] rounded-xl font-semibold transition-all duration-200 hover:scale-105 shadow-lg"
            >
              <AlertIcon size={18} />
              Emergency
            </a>
          </div>
        </div>
      </div>
    </header>
  );
};

const AlertIcon: React.FC<{ size: number }> = ({ size }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/>
    <path d="M12 9v4"/>
    <path d="M12 17h.01"/>
  </svg>
);

export default Header;
