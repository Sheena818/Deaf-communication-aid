import React, { useState } from 'react';
import { Settings } from '@/types';
import {
  CloseIcon,
  SpeakerIcon,
  TextIcon,
  CheckIcon,
} from './icons/Icons';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: Settings;
  onUpdateSettings: (settings: Settings) => void;
}

const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
}) => {
  const [localSettings, setLocalSettings] = useState<Settings>(settings);

  if (!isOpen) return null;

  const handleSave = () => {
    onUpdateSettings(localSettings);
    onClose();
  };

  const textSizeOptions = [
    { value: 'small', label: 'Small', size: '16px' },
    { value: 'medium', label: 'Medium', size: '20px' },
    { value: 'large', label: 'Large', size: '24px' },
    { value: 'extra-large', label: 'Extra Large', size: '28px' },
  ];

  const themeOptions = [
    { value: 'light', label: 'Light', bg: 'bg-white', text: 'text-gray-800' },
    { value: 'dark', label: 'Dark', bg: 'bg-gray-900', text: 'text-white' },
    { value: 'high-contrast', label: 'High Contrast', bg: 'bg-black', text: 'text-yellow-400' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Modal */}
      <div className="relative bg-white rounded-3xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 rounded-t-3xl flex items-center justify-between">
          <h2 className="text-2xl font-bold text-[#1a2332]">Settings</h2>
          <button
            onClick={onClose}
            className="w-10 h-10 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center transition-colors"
            aria-label="Close settings"
          >
            <CloseIcon size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-8">
          {/* Text Size */}
          <div>
            <h3 className="text-lg font-semibold text-[#1a2332] mb-4 flex items-center gap-2">
              <TextIcon size={20} />
              Text Size
            </h3>
            <div className="grid grid-cols-2 gap-3">
              {textSizeOptions.map((option) => (
                <button
                  key={option.value}
                  onClick={() => setLocalSettings(prev => ({ ...prev, textSize: option.value as Settings['textSize'] }))}
                  className={`p-4 rounded-xl border-2 transition-all ${
                    localSettings.textSize === option.value
                      ? 'border-[#00bfa5] bg-[#00bfa5]/10'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <span style={{ fontSize: option.size }} className="font-medium text-[#1a2332]">
                    {option.label}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Theme */}
          <div>
            <h3 className="text-lg font-semibold text-[#1a2332] mb-4">
              Display Theme
            </h3>
            <div className="grid grid-cols-3 gap-3">
              {themeOptions.map((option) => (
                <button
                  key={option.value}
                  onClick={() => setLocalSettings(prev => ({ ...prev, theme: option.value as Settings['theme'] }))}
                  className={`p-4 rounded-xl border-2 transition-all ${
                    localSettings.theme === option.value
                      ? 'border-[#00bfa5] ring-2 ring-[#00bfa5]/50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className={`w-full h-12 rounded-lg ${option.bg} ${option.text} flex items-center justify-center text-sm font-medium mb-2`}>
                    Aa
                  </div>
                  <span className="text-sm text-gray-600">{option.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Speech Settings */}
          <div>
            <h3 className="text-lg font-semibold text-[#1a2332] mb-4 flex items-center gap-2">
              <SpeakerIcon size={20} />
              Speech Settings
            </h3>
            <div className="space-y-4">
              {/* Speech Rate */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-sm font-medium text-gray-600">Speech Speed</label>
                  <span className="text-sm font-bold text-[#00bfa5]">{localSettings.speechRate}x</span>
                </div>
                <input
                  type="range"
                  min="0.5"
                  max="2"
                  step="0.1"
                  value={localSettings.speechRate}
                  onChange={(e) => setLocalSettings(prev => ({ ...prev, speechRate: parseFloat(e.target.value) }))}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-[#00bfa5]"
                />
                <div className="flex justify-between text-xs text-gray-400 mt-1">
                  <span>Slower</span>
                  <span>Faster</span>
                </div>
              </div>

              {/* Speech Pitch */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-sm font-medium text-gray-600">Voice Pitch</label>
                  <span className="text-sm font-bold text-[#00bfa5]">{localSettings.speechPitch}</span>
                </div>
                <input
                  type="range"
                  min="0.5"
                  max="2"
                  step="0.1"
                  value={localSettings.speechPitch}
                  onChange={(e) => setLocalSettings(prev => ({ ...prev, speechPitch: parseFloat(e.target.value) }))}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-[#00bfa5]"
                />
                <div className="flex justify-between text-xs text-gray-400 mt-1">
                  <span>Lower</span>
                  <span>Higher</span>
                </div>
              </div>

              {/* Volume */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-sm font-medium text-gray-600">Volume</label>
                  <span className="text-sm font-bold text-[#00bfa5]">{Math.round(localSettings.speechVolume * 100)}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.1"
                  value={localSettings.speechVolume}
                  onChange={(e) => setLocalSettings(prev => ({ ...prev, speechVolume: parseFloat(e.target.value) }))}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-[#00bfa5]"
                />
              </div>
            </div>
          </div>

          {/* Vibration */}
          <div>
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
              <div>
                <h4 className="font-medium text-[#1a2332]">Vibration Feedback</h4>
                <p className="text-sm text-gray-500">Vibrate on important actions</p>
              </div>
              <button
                onClick={() => setLocalSettings(prev => ({ ...prev, vibrationEnabled: !prev.vibrationEnabled }))}
                className={`w-14 h-8 rounded-full transition-colors ${
                  localSettings.vibrationEnabled ? 'bg-[#00bfa5]' : 'bg-gray-300'
                }`}
              >
                <div
                  className={`w-6 h-6 bg-white rounded-full shadow-md transition-transform ${
                    localSettings.vibrationEnabled ? 'translate-x-7' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>
          </div>

          {/* Preferred Mode */}
          <div>
            <h3 className="text-lg font-semibold text-[#1a2332] mb-4">
              Default Communication Mode
            </h3>
            <div className="space-y-2">
              {[
                { value: 'speech-to-text', label: 'Speech to Text', desc: 'Convert spoken words to text' },
                { value: 'text-to-speech', label: 'Text to Speech', desc: 'Convert typed text to speech' },
                { value: 'both', label: 'Both Modes', desc: 'Show both options equally' },
              ].map((option) => (
                <button
                  key={option.value}
                  onClick={() => setLocalSettings(prev => ({ ...prev, preferredMode: option.value as Settings['preferredMode'] }))}
                  className={`w-full flex items-center justify-between p-4 rounded-xl border-2 transition-all ${
                    localSettings.preferredMode === option.value
                      ? 'border-[#00bfa5] bg-[#00bfa5]/10'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="text-left">
                    <div className="font-medium text-[#1a2332]">{option.label}</div>
                    <div className="text-sm text-gray-500">{option.desc}</div>
                  </div>
                  {localSettings.preferredMode === option.value && (
                    <div className="w-6 h-6 bg-[#00bfa5] rounded-full flex items-center justify-center">
                      <CheckIcon size={14} className="text-white" />
                    </div>
                  )}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="sticky bottom-0 bg-white border-t border-gray-200 px-6 py-4 rounded-b-3xl flex gap-3">
          <button
            onClick={onClose}
            className="flex-1 py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl font-semibold transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            className="flex-1 py-3 bg-[#00bfa5] hover:bg-[#00a08a] text-white rounded-xl font-semibold transition-colors"
          >
            Save Changes
          </button>
        </div>
      </div>
    </div>
  );
};

export default SettingsModal;
