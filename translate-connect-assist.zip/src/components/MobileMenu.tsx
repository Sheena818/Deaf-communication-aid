import React from 'react';
import { useAuth } from '@/contexts/AuthContext';
import {
  CloseIcon,
  MicrophoneIcon,
  TextIcon,
  HandsIcon,
  AlertIcon,
  SettingsIcon,
  HeartIcon,
  UserIcon,
  LogoutIcon,
  VideoIcon,
  CreditCardIcon,
} from './icons/Icons';


interface MobileMenuProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenSettings: () => void;
  onOpenAuth?: () => void;
}

const MobileMenu: React.FC<MobileMenuProps> = ({ isOpen, onClose, onOpenSettings, onOpenAuth }) => {
  const { user, isAuthenticated, signOut } = useAuth();
  
  if (!isOpen) return null;

  const menuItems = [
    { label: 'Communicate', href: '#communicate', icon: <MicrophoneIcon size={20} /> },
    { label: 'Quick Phrases', href: '#phrases', icon: <TextIcon size={20} /> },
    { label: 'Video Call', href: '#video-call', icon: <VideoIcon size={20} /> },
    { label: 'ASL Translator', href: '#asl-translator', icon: <HandsIcon size={20} /> },
    { label: 'Pricing', href: '#pricing', icon: <CreditCardIcon size={20} /> },
    { label: 'Emergency', href: '#emergency', icon: <AlertIcon size={20} /> },
  ];


  const handleNavClick = (href: string) => {
    onClose();
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSignOut = async () => {
    await signOut();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 md:hidden">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Menu Panel */}
      <div className="absolute right-0 top-0 bottom-0 w-80 max-w-[85vw] bg-[#1a2332] shadow-2xl overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-[#00bfa5] to-[#00897b] rounded-xl flex items-center justify-center">
              <HeartIcon className="text-white" size={20} />
            </div>
            <span className="text-xl font-bold text-white">BridgeTalk</span>
          </div>
          <button
            onClick={onClose}
            className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors"
            aria-label="Close menu"
          >
            <CloseIcon size={20} className="text-white" />
          </button>
        </div>

        {/* Navigation */}
        <nav className="p-4">
          <ul className="space-y-2">
            {menuItems.map((item) => (
              <li key={item.label}>
                <button
                  onClick={() => handleNavClick(item.href)}
                  className="w-full flex items-center gap-4 px-4 py-4 text-white hover:bg-white/10 rounded-xl transition-colors"
                >
                  <span className="text-[#00bfa5]">{item.icon}</span>
                  <span className="font-medium">{item.label}</span>
                </button>
              </li>
            ))}
          </ul>
        </nav>

        {/* User Section */}
        <div className="p-4 border-t border-white/10">
          {isAuthenticated ? (
            <div className="space-y-2">
              <div className="flex items-center gap-3 px-4 py-3 bg-white/5 rounded-xl">
                <div className="w-10 h-10 bg-gradient-to-br from-[#00bfa5] to-[#00897b] rounded-full flex items-center justify-center">
                  <UserIcon className="text-white" size={18} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-white font-medium truncate">
                    {user?.displayName || user?.email?.split('@')[0]}
                  </p>
                  <p className="text-xs text-gray-400 truncate">{user?.email}</p>
                </div>
              </div>
              <a
                href="/account"
                onClick={onClose}
                className="w-full flex items-center gap-4 px-4 py-3 text-white hover:bg-white/10 rounded-xl transition-colors"
              >
                <UserIcon size={20} className="text-[#00bfa5]" />
                <span className="font-medium">Account Dashboard</span>
              </a>
              <a
                href="/account"
                onClick={onClose}
                className="w-full flex items-center gap-4 px-4 py-3 text-white hover:bg-white/10 rounded-xl transition-colors"
              >
                <CreditCardIcon size={20} className="text-[#00bfa5]" />
                <span className="font-medium">Billing & Subscription</span>
              </a>
              <button
                onClick={handleSignOut}
                className="w-full flex items-center gap-4 px-4 py-3 text-red-400 hover:bg-red-500/10 rounded-xl transition-colors"
              >
                <LogoutIcon size={20} />
                <span className="font-medium">Sign Out</span>
              </button>
            </div>
          ) : (
            <button
              onClick={() => {
                onClose();
                onOpenAuth?.();
              }}
              className="w-full flex items-center gap-4 px-4 py-4 text-white bg-[#00bfa5] hover:bg-[#00a08a] rounded-xl transition-colors"
            >
              <UserIcon size={20} />
              <span className="font-medium">Sign In / Sign Up</span>
            </button>
          )}
        </div>

        {/* Settings */}
        <div className="p-4 border-t border-white/10">
          <button
            onClick={() => {
              onClose();
              onOpenSettings();
            }}
            className="w-full flex items-center gap-4 px-4 py-4 text-white hover:bg-white/10 rounded-xl transition-colors"
          >
            <span className="text-[#00bfa5]"><SettingsIcon size={20} /></span>
            <span className="font-medium">Settings</span>
          </button>
        </div>

        {/* Emergency Button */}
        <div className="p-4 pb-24 border-t border-white/10">
          <a
            href="tel:911"
            className="flex items-center justify-center gap-3 w-full py-4 bg-[#ff6b35] hover:bg-[#e55a2b] text-white rounded-xl font-bold transition-colors"
          >
            <AlertIcon size={20} />
            Emergency Call
          </a>
        </div>
      </div>
    </div>
  );
};

export default MobileMenu;
