import React, { useState } from 'react';
import { Check, Zap, Building2, Crown, X } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import SubscriptionModal from './SubscriptionModal';

interface PricingPlan {
  id: string;
  name: string;
  price: number;
  priceDisplay: string;
  description: string;
  features: string[];
  highlighted?: boolean;
  planType: 'free' | 'pro' | 'enterprise';
  icon: React.ReactNode;
  buttonText: string;
}

const plans: PricingPlan[] = [
  {
    id: 'free',
    name: 'Free',
    price: 0,
    priceDisplay: '$0',
    description: 'Perfect for getting started with accessible communication',
    features: [
      '30 minutes of video calls per month',
      'Basic text-to-speech',
      'Standard video quality',
      '5 quick phrases',
      'Community support',
    ],
    planType: 'free',
    icon: <Zap className="w-6 h-6" />,
    buttonText: 'Get Started Free',
  },
  {
    id: 'pro',
    name: 'Pro',
    price: 999,
    priceDisplay: '$9.99',
    description: 'For individuals who need unlimited communication',
    features: [
      'Unlimited video calls',
      'HD video quality',
      'Advanced noise cancellation',
      'Priority support',
      'Unlimited quick phrases',
      'ASL learning tools',
      'Call recording',
      'Custom virtual backgrounds',
    ],
    highlighted: true,
    planType: 'pro',
    icon: <Crown className="w-6 h-6" />,
    buttonText: 'Upgrade to Pro',
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    price: 2999,
    priceDisplay: '$29.99',
    description: 'For teams and organizations with advanced needs',
    features: [
      'Everything in Pro',
      'Team collaboration',
      'Analytics dashboard',
      'Custom branding',
      'API access',
      'Dedicated account manager',
      'SSO integration',
      'Admin controls',
      'Audit logs',
    ],
    planType: 'enterprise',
    icon: <Building2 className="w-6 h-6" />,
    buttonText: 'Contact Sales',
  },
];

const PricingSection: React.FC = () => {
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<'pro' | 'enterprise'>('pro');
  const { isAuthenticated, user } = useAuth();

  const handleSelectPlan = (planType: 'free' | 'pro' | 'enterprise') => {
    if (planType === 'free') {
      // Free plan - just scroll to communication section
      const communicationSection = document.getElementById('communication');
      if (communicationSection) {
        communicationSection.scrollIntoView({ behavior: 'smooth' });
      }
      return;
    }

    setSelectedPlan(planType);
    setShowSubscriptionModal(true);
  };

  return (
    <section id="pricing" className="py-20 bg-gradient-to-b from-white to-indigo-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <span className="inline-block px-4 py-1.5 bg-indigo-100 text-indigo-700 rounded-full text-sm font-semibold mb-4">
            Pricing Plans
          </span>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Choose Your Perfect Plan
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Start free and upgrade as you grow. All plans include our core accessibility features.
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan) => (
            <div
              key={plan.id}
              className={`relative rounded-2xl p-8 transition-all duration-300 ${
                plan.highlighted
                  ? 'bg-gradient-to-br from-indigo-600 to-purple-700 text-white shadow-2xl scale-105 z-10'
                  : 'bg-white text-gray-900 shadow-lg hover:shadow-xl border border-gray-100'
              }`}
            >
              {plan.highlighted && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <span className="bg-gradient-to-r from-amber-400 to-orange-500 text-white px-4 py-1 rounded-full text-sm font-bold shadow-lg">
                    Most Popular
                  </span>
                </div>
              )}

              {/* Plan Icon & Name */}
              <div className="flex items-center gap-3 mb-4">
                <div
                  className={`p-2 rounded-lg ${
                    plan.highlighted ? 'bg-white/20' : 'bg-indigo-100'
                  }`}
                >
                  <div className={plan.highlighted ? 'text-white' : 'text-indigo-600'}>
                    {plan.icon}
                  </div>
                </div>
                <h3 className="text-2xl font-bold">{plan.name}</h3>
              </div>

              {/* Price */}
              <div className="mb-4">
                <span className="text-4xl font-bold">{plan.priceDisplay}</span>
                {plan.price > 0 && (
                  <span className={plan.highlighted ? 'text-indigo-200' : 'text-gray-500'}>
                    /month
                  </span>
                )}
              </div>

              {/* Description */}
              <p
                className={`mb-6 ${
                  plan.highlighted ? 'text-indigo-100' : 'text-gray-600'
                }`}
              >
                {plan.description}
              </p>

              {/* Features */}
              <ul className="space-y-3 mb-8">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <Check
                      className={`w-5 h-5 flex-shrink-0 mt-0.5 ${
                        plan.highlighted ? 'text-indigo-200' : 'text-green-500'
                      }`}
                    />
                    <span
                      className={`text-sm ${
                        plan.highlighted ? 'text-indigo-100' : 'text-gray-600'
                      }`}
                    >
                      {feature}
                    </span>
                  </li>
                ))}
              </ul>

              {/* CTA Button */}
              <button
                onClick={() => handleSelectPlan(plan.planType)}
                className={`w-full py-3 px-6 rounded-xl font-semibold transition-all duration-200 ${
                  plan.highlighted
                    ? 'bg-white text-indigo-600 hover:bg-indigo-50 shadow-lg'
                    : 'bg-indigo-600 text-white hover:bg-indigo-700'
                }`}
              >
                {plan.buttonText}
              </button>
            </div>
          ))}
        </div>

        {/* Trust Badges */}
        <div className="mt-16 text-center">
          <p className="text-gray-500 mb-6">Trusted by thousands of users worldwide</p>
          <div className="flex flex-wrap justify-center gap-8 items-center">
            <div className="flex items-center gap-2 text-gray-400">
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 5.225-3.34 9.67-8 11.317C5.34 16.67 2 12.225 2 7c0-.682.057-1.35.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
              </svg>
              <span className="text-sm font-medium">SSL Secured</span>
            </div>
            <div className="flex items-center gap-2 text-gray-400">
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                <path d="M4 4a2 2 0 00-2 2v4a2 2 0 002 2V6h10a2 2 0 00-2-2H4zm2 6a2 2 0 012-2h8a2 2 0 012 2v4a2 2 0 01-2 2H8a2 2 0 01-2-2v-4zm6 4a2 2 0 100-4 2 2 0 000 4z" />
              </svg>
              <span className="text-sm font-medium">Cancel Anytime</span>
            </div>
            <div className="flex items-center gap-2 text-gray-400">
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
              </svg>
              <span className="text-sm font-medium">30-Day Money Back</span>
            </div>
            <div className="flex items-center gap-2 text-gray-400">
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                <path d="M2 10a8 8 0 018-8v8h8a8 8 0 11-16 0z" />
                <path d="M12 2.252A8.014 8.014 0 0117.748 8H12V2.252z" />
              </svg>
              <span className="text-sm font-medium">99.9% Uptime</span>
            </div>
          </div>
        </div>

        {/* FAQ Preview */}
        <div className="mt-20 max-w-3xl mx-auto">
          <h3 className="text-2xl font-bold text-center text-gray-900 mb-8">
            Frequently Asked Questions
          </h3>
          <div className="space-y-4">
            <details className="group bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
              <summary className="flex items-center justify-between p-6 cursor-pointer">
                <span className="font-semibold text-gray-900">Can I switch plans anytime?</span>
                <svg className="w-5 h-5 text-gray-500 group-open:rotate-180 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </summary>
              <div className="px-6 pb-6 text-gray-600">
                Yes! You can upgrade or downgrade your plan at any time. When upgrading, you'll be charged the prorated difference. When downgrading, the change takes effect at the end of your billing period.
              </div>
            </details>
            <details className="group bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
              <summary className="flex items-center justify-between p-6 cursor-pointer">
                <span className="font-semibold text-gray-900">What happens when I reach my call limit?</span>
                <svg className="w-5 h-5 text-gray-500 group-open:rotate-180 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </summary>
              <div className="px-6 pb-6 text-gray-600">
                On the Free plan, once you've used your 30 minutes, you'll be prompted to upgrade to Pro for unlimited calls. Your limit resets at the beginning of each month.
              </div>
            </details>
            <details className="group bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
              <summary className="flex items-center justify-between p-6 cursor-pointer">
                <span className="font-semibold text-gray-900">Is there a free trial for Pro?</span>
                <svg className="w-5 h-5 text-gray-500 group-open:rotate-180 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </summary>
              <div className="px-6 pb-6 text-gray-600">
                We offer a 30-day money-back guarantee on all paid plans. Try Pro risk-free and if it's not right for you, we'll refund your payment in full.
              </div>
            </details>
          </div>
        </div>
      </div>

      {/* Subscription Modal */}
      <SubscriptionModal
        isOpen={showSubscriptionModal}
        onClose={() => setShowSubscriptionModal(false)}
        planType={selectedPlan}
      />
    </section>
  );
};

export default PricingSection;
