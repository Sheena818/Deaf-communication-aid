import React from 'react';
import {
  MicrophoneIcon,
  SpeakerIcon,
  TextIcon,
  HandsIcon,
  AlertIcon,
  HistoryIcon,
  VideoIcon,
  SettingsIcon,
  CaptionsIcon,
} from './icons/Icons';

const FeaturesSection: React.FC = () => {
  const features = [
    {
      icon: <MicrophoneIcon size={28} />,
      title: 'Speech to Text',
      description: 'Real-time voice recognition converts spoken words into readable text instantly with 95% accuracy.',
      color: 'bg-[#00bfa5]',
      lightColor: 'bg-[#00bfa5]/10',
    },
    {
      icon: <SpeakerIcon size={28} />,
      title: 'Text to Speech',
      description: 'Type your message and let natural-sounding voices speak for you with adjustable speed and pitch.',
      color: 'bg-[#ff6b35]',
      lightColor: 'bg-[#ff6b35]/10',
    },
    {
      icon: <VideoIcon size={28} />,
      title: 'Video Calling',
      description: 'Make video calls with built-in real-time captions so deaf users can follow conversations easily.',
      color: 'bg-purple-500',
      lightColor: 'bg-purple-500/10',
    },
    {
      icon: <CaptionsIcon size={28} />,
      title: 'Live Captions',
      description: 'Automatic speech-to-text captions during video calls displayed at the bottom of the screen.',
      color: 'bg-pink-500',
      lightColor: 'bg-pink-500/10',
    },
    {
      icon: <TextIcon size={28} />,
      title: 'Quick Phrases',
      description: 'Access 40+ pre-written phrases organized by category for instant communication in any situation.',
      color: 'bg-blue-500',
      lightColor: 'bg-blue-500/10',
    },
    {
      icon: <HandsIcon size={28} />,
      title: 'ASL Learning',
      description: 'Learn American Sign Language basics with our interactive fingerspelling guide and common signs.',
      color: 'bg-indigo-500',
      lightColor: 'bg-indigo-500/10',
    },
    {
      icon: <AlertIcon size={28} />,
      title: 'Emergency Features',
      description: 'Quick access to emergency phrases, contacts, and location sharing for safety situations.',
      color: 'bg-red-500',
      lightColor: 'bg-red-500/10',
    },
    {
      icon: <SettingsIcon size={28} />,
      title: 'Accessibility Options',
      description: 'Customize text size, contrast themes, vibration feedback, and preferred communication modes.',
      color: 'bg-teal-500',
      lightColor: 'bg-teal-500/10',
    },
  ];


  return (
    <section className="py-12 sm:py-20 bg-gradient-to-b from-white to-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12 sm:mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-[#1a2332] mb-4">
            Powerful Features for Seamless Communication
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Everything you need to bridge the communication gap, designed with 
            accessibility and ease of use at its core.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <div
              key={index}
              className="group relative bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border border-gray-100"
            >
              {/* Icon */}
              <div className={`w-14 h-14 ${feature.lightColor} rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                <div className={`${feature.color} bg-clip-text text-transparent`} style={{ color: feature.color.replace('bg-', '').includes('[') ? feature.color.match(/\[(.*?)\]/)?.[1] : '' }}>
                  <span className={feature.color.replace('bg-', 'text-')}>{feature.icon}</span>
                </div>
              </div>

              {/* Content */}
              <h3 className="text-lg font-bold text-[#1a2332] mb-2">
                {feature.title}
              </h3>
              <p className="text-gray-600 text-sm leading-relaxed">
                {feature.description}
              </p>

              {/* Hover Accent */}
              <div className={`absolute bottom-0 left-0 right-0 h-1 ${feature.color} rounded-b-2xl opacity-0 group-hover:opacity-100 transition-opacity`} />
            </div>
          ))}
        </div>

        {/* Stats Banner */}
        <div className="mt-16 bg-[#1a2332] rounded-3xl p-8 sm:p-12">
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 text-center">
            {[
              { value: '48M+', label: 'Deaf Americans Served' },
              { value: '95%', label: 'Speech Recognition Accuracy' },
              { value: '40+', label: 'Quick Phrases Available' },
              { value: '24/7', label: 'Offline Capability' },
            ].map((stat, index) => (
              <div key={index}>
                <div className="text-4xl sm:text-5xl font-bold text-[#00bfa5] mb-2">
                  {stat.value}
                </div>
                <div className="text-gray-400">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Technology Banner */}
        <div className="mt-12 flex flex-col sm:flex-row items-center justify-center gap-6 text-center">
          <span className="text-gray-500">Powered by</span>
          <div className="flex flex-wrap items-center justify-center gap-6">
            {['Web Speech API', 'React', 'Tailwind CSS', 'TypeScript'].map((tech) => (
              <span
                key={tech}
                className="px-4 py-2 bg-gray-100 rounded-full text-sm font-medium text-gray-600"
              >
                {tech}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;
