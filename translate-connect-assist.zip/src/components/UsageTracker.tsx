import React, { useState, useEffect } from 'react';
import { Clock, Phone, MessageSquare, Hand, TrendingUp, Crown, AlertTriangle, Loader2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';

interface UsageData {
  call_minutes_used: number;
  calls_made: number;
  messages_sent: number;
  asl_translations: number;
}

interface UsageLimits {
  call_minutes: number;
  remaining_minutes: number;
}

interface UsageTrackerProps {
  onUpgrade?: () => void;
}

const UsageTracker: React.FC<UsageTrackerProps> = ({ onUpgrade }) => {
  const [usage, setUsage] = useState<UsageData | null>(null);
  const [limits, setLimits] = useState<UsageLimits | null>(null);
  const [plan, setPlan] = useState<string>('Free');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user, anonymousId } = useAuth();

  const userId = user?.id || anonymousId;

  useEffect(() => {
    fetchUsage();
  }, [userId]);

  const fetchUsage = async () => {
    if (!userId) return;
    
    setLoading(true);
    setError(null);

    try {
      const { data, error: fnError } = await supabase.functions.invoke('track-usage', {
        body: { action: 'get', userId }
      });

      if (fnError || data?.error) {
        throw new Error(data?.error || fnError?.message || 'Failed to fetch usage');
      }

      setUsage(data.usage);
      setLimits(data.limits);
      setPlan(data.plan);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
        <div className="flex items-center justify-center py-8">
          <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
        <div className="flex items-center gap-3 text-red-600">
          <AlertTriangle className="w-5 h-5" />
          <span>Failed to load usage data</span>
        </div>
      </div>
    );
  }

  const usagePercentage = limits && limits.call_minutes !== Infinity
    ? Math.min(100, ((usage?.call_minutes_used || 0) / limits.call_minutes) * 100)
    : 0;

  const isNearLimit = usagePercentage >= 80;
  const isAtLimit = usagePercentage >= 100;
  const isUnlimited = limits?.call_minutes === Infinity || plan !== 'Free';

  return (
    <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-100 rounded-lg">
            <TrendingUp className="w-5 h-5 text-indigo-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">Usage This Month</h3>
            <p className="text-sm text-gray-500">
              Current plan: <span className="font-medium text-indigo-600">{plan}</span>
            </p>
          </div>
        </div>
        {!isUnlimited && onUpgrade && (
          <button
            onClick={onUpgrade}
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg text-sm font-medium hover:from-indigo-700 hover:to-purple-700 transition-all"
          >
            <Crown className="w-4 h-4" />
            Upgrade
          </button>
        )}
      </div>

      {/* Call Minutes Progress */}
      {!isUnlimited && (
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-gray-700">Video Call Minutes</span>
            <span className="text-sm text-gray-500">
              {usage?.call_minutes_used || 0} / {limits?.call_minutes || 30} min
            </span>
          </div>
          <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                isAtLimit
                  ? 'bg-red-500'
                  : isNearLimit
                  ? 'bg-amber-500'
                  : 'bg-gradient-to-r from-indigo-500 to-purple-500'
              }`}
              style={{ width: `${usagePercentage}%` }}
            />
          </div>
          {isNearLimit && !isAtLimit && (
            <p className="text-xs text-amber-600 mt-2 flex items-center gap-1">
              <AlertTriangle className="w-3 h-3" />
              You're approaching your monthly limit
            </p>
          )}
          {isAtLimit && (
            <p className="text-xs text-red-600 mt-2 flex items-center gap-1">
              <AlertTriangle className="w-3 h-3" />
              You've reached your monthly limit. Upgrade to continue calling.
            </p>
          )}
        </div>
      )}

      {isUnlimited && (
        <div className="mb-6 p-4 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl">
          <div className="flex items-center gap-2 text-indigo-700">
            <Crown className="w-5 h-5" />
            <span className="font-medium">Unlimited video calls included with {plan}</span>
          </div>
        </div>
      )}

      {/* Usage Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-gray-50 rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <Clock className="w-4 h-4 text-indigo-500" />
            <span className="text-xs font-medium text-gray-500">Minutes Used</span>
          </div>
          <p className="text-2xl font-bold text-gray-900">{usage?.call_minutes_used || 0}</p>
        </div>
        
        <div className="bg-gray-50 rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <Phone className="w-4 h-4 text-green-500" />
            <span className="text-xs font-medium text-gray-500">Calls Made</span>
          </div>
          <p className="text-2xl font-bold text-gray-900">{usage?.calls_made || 0}</p>
        </div>
        
        <div className="bg-gray-50 rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <MessageSquare className="w-4 h-4 text-blue-500" />
            <span className="text-xs font-medium text-gray-500">Messages</span>
          </div>
          <p className="text-2xl font-bold text-gray-900">{usage?.messages_sent || 0}</p>
        </div>
        
        <div className="bg-gray-50 rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <Hand className="w-4 h-4 text-purple-500" />
            <span className="text-xs font-medium text-gray-500">ASL Translations</span>
          </div>
          <p className="text-2xl font-bold text-gray-900">{usage?.asl_translations || 0}</p>
        </div>
      </div>

      {/* Refresh Button */}
      <button
        onClick={fetchUsage}
        className="mt-4 text-sm text-indigo-600 hover:text-indigo-700 font-medium"
      >
        Refresh usage data
      </button>
    </div>
  );
};

export default UsageTracker;
