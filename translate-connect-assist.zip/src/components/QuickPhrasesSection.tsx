import React, { useState, useEffect } from 'react';
import { quickPhrases, categories } from '@/data/quickPhrases';
import { Message } from '@/types';
import { useTextToSpeech } from '@/hooks/useTextToSpeech';
import { useAuth } from '@/contexts/AuthContext';
import { DbCustomPhrase, phrasesService } from '@/lib/database';
import {
  SpeakerIcon,
  PlusIcon,
  CheckIcon,
  AlertIcon,
  HeartIcon,
  UserIcon,
  PhoneIcon,
  HandsIcon,
  TrashIcon,
} from './icons/Icons';

interface QuickPhrasesSectionProps {
  onAddMessage: (message: Omit<Message, 'id' | 'timestamp'>) => void;
}

const QuickPhrasesSection: React.FC<QuickPhrasesSectionProps> = ({ onAddMessage }) => {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [customPhrases, setCustomPhrases] = useState<DbCustomPhrase[]>([]);
  const [newPhrase, setNewPhrase] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [recentlyUsed, setRecentlyUsed] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const { speak, isSpeaking } = useTextToSpeech();
  const { anonymousId, user } = useAuth();
  const userId = user?.id || anonymousId;

  // Load custom phrases from database
  useEffect(() => {
    const loadPhrases = async () => {
      setIsLoading(true);
      const phrases = await phrasesService.getAll(userId);
      setCustomPhrases(phrases);
      setIsLoading(false);
    };

    loadPhrases();

    // Subscribe to real-time changes
    const unsubscribe = phrasesService.subscribeToChanges(userId, (phrases) => {
      setCustomPhrases(phrases);
    });

    return () => {
      unsubscribe();
    };
  }, [userId]);

  const filteredPhrases = selectedCategory === 'All'
    ? quickPhrases
    : quickPhrases.filter(p => p.category === selectedCategory);

  const handlePhraseClick = (text: string, phraseId?: string) => {
    speak(text);
    onAddMessage({
      text,
      sender: 'user',
      type: 'phrase',
    });
    
    // Increment usage if it's a custom phrase
    if (phraseId) {
      phrasesService.incrementUsage(phraseId);
    }
    
    // Add to recently used
    setRecentlyUsed(prev => {
      const updated = [text, ...prev.filter(p => p !== text)].slice(0, 5);
      return updated;
    });
  };

  const handleAddCustomPhrase = async () => {
    if (newPhrase.trim()) {
      setIsSaving(true);
      const phrase = await phrasesService.add(userId, newPhrase.trim());
      if (phrase) {
        setNewPhrase('');
        setShowAddForm(false);
      }
      setIsSaving(false);
    }
  };

  const handleDeletePhrase = async (phraseId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    await phrasesService.delete(phraseId);
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Greetings': return <HeartIcon size={16} />;
      case 'Questions': return <UserIcon size={16} />;
      case 'Responses': return <CheckIcon size={16} />;
      case 'Emergencies': return <AlertIcon size={16} />;
      case 'Social': return <HandsIcon size={16} />;
      case 'Medical': return <PhoneIcon size={16} />;
      default: return null;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'Greetings': return 'bg-pink-100 text-pink-700 border-pink-200';
      case 'Questions': return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'Responses': return 'bg-green-100 text-green-700 border-green-200';
      case 'Emergencies': return 'bg-red-100 text-red-700 border-red-200';
      case 'Social': return 'bg-purple-100 text-purple-700 border-purple-200';
      case 'Medical': return 'bg-orange-100 text-orange-700 border-orange-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  return (
    <section id="phrases" className="py-12 sm:py-20 bg-gradient-to-br from-gray-50 to-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-[#1a2332] mb-4">
            Quick Phrases
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Tap any phrase to speak it instantly. Perfect for common conversations 
            and emergencies. Add your own custom phrases for personalized communication.
          </p>
        </div>

        {/* Recently Used */}
        {recentlyUsed.length > 0 && (
          <div className="mb-8">
            <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-3">
              Recently Used
            </h3>
            <div className="flex flex-wrap gap-2">
              {recentlyUsed.map((phrase, index) => (
                <button
                  key={index}
                  onClick={() => handlePhraseClick(phrase)}
                  className="flex items-center gap-2 px-4 py-2 bg-[#00bfa5]/10 text-[#00bfa5] border border-[#00bfa5]/30 rounded-full hover:bg-[#00bfa5] hover:text-white transition-all duration-200"
                >
                  <SpeakerIcon size={14} />
                  <span className="text-sm font-medium">{phrase}</span>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Category Filters */}
        <div className="flex flex-wrap justify-center gap-2 sm:gap-3 mb-8">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`flex items-center gap-2 px-4 sm:px-6 py-2 sm:py-3 rounded-full font-medium transition-all duration-200 ${
                selectedCategory === category
                  ? 'bg-[#1a2332] text-white shadow-lg'
                  : 'bg-white text-gray-600 hover:bg-gray-100 border border-gray-200'
              }`}
            >
              {getCategoryIcon(category)}
              {category}
            </button>
          ))}
        </div>

        {/* Phrases Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 mb-8">
          {filteredPhrases.map((phrase) => (
            <button
              key={phrase.id}
              onClick={() => handlePhraseClick(phrase.text)}
              disabled={isSpeaking}
              className={`group relative p-5 rounded-2xl border-2 text-left transition-all duration-200 hover:scale-[1.02] hover:shadow-lg ${getCategoryColor(phrase.category)} disabled:opacity-50`}
            >
              <div className="flex items-start justify-between gap-3">
                <p className="font-medium text-base leading-relaxed">{phrase.text}</p>
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-white/50 flex items-center justify-center group-hover:bg-white transition-colors">
                  <SpeakerIcon size={16} />
                </div>
              </div>
              <div className="mt-3 flex items-center gap-2 text-xs opacity-75">
                {getCategoryIcon(phrase.category)}
                <span>{phrase.category}</span>
              </div>
            </button>
          ))}

          {/* Custom Phrases from Database */}
          {isLoading ? (
            <div className="p-5 rounded-2xl border-2 border-dashed border-gray-300 bg-white/50 flex items-center justify-center">
              <div className="animate-spin w-6 h-6 border-2 border-[#00bfa5] border-t-transparent rounded-full"></div>
            </div>
          ) : (
            customPhrases.map((phrase) => (
              <button
                key={phrase.id}
                onClick={() => handlePhraseClick(phrase.text, phrase.id)}
                disabled={isSpeaking}
                className="group relative p-5 rounded-2xl border-2 border-dashed border-[#00bfa5] bg-[#00bfa5]/5 text-left transition-all duration-200 hover:scale-[1.02] hover:shadow-lg hover:bg-[#00bfa5]/10 disabled:opacity-50"
              >
                <div className="flex items-start justify-between gap-3">
                  <p className="font-medium text-base leading-relaxed text-[#00bfa5]">{phrase.text}</p>
                  <div className="flex-shrink-0 w-8 h-8 rounded-full bg-[#00bfa5]/20 flex items-center justify-center group-hover:bg-[#00bfa5]/30 transition-colors">
                    <SpeakerIcon size={16} className="text-[#00bfa5]" />
                  </div>
                </div>
                <div className="mt-3 flex items-center justify-between text-xs text-[#00bfa5] opacity-75">
                  <span>Custom Phrase</span>
                  <button
                    onClick={(e) => handleDeletePhrase(phrase.id, e)}
                    className="p-1 hover:bg-red-100 rounded transition-colors"
                    aria-label="Delete phrase"
                  >
                    <TrashIcon size={14} className="text-red-500" />
                  </button>
                </div>
              </button>
            ))
          )}

          {/* Add Custom Phrase Button */}
          {!showAddForm ? (
            <button
              onClick={() => setShowAddForm(true)}
              className="p-5 rounded-2xl border-2 border-dashed border-gray-300 bg-white/50 text-gray-500 hover:border-[#00bfa5] hover:text-[#00bfa5] transition-all duration-200 flex flex-col items-center justify-center gap-2 min-h-[120px]"
            >
              <PlusIcon size={24} />
              <span className="font-medium">Add Custom Phrase</span>
            </button>
          ) : (
            <div className="p-5 rounded-2xl border-2 border-[#00bfa5] bg-white shadow-lg">
              <textarea
                value={newPhrase}
                onChange={(e) => setNewPhrase(e.target.value)}
                placeholder="Type your custom phrase..."
                className="w-full h-20 p-3 border border-gray-200 rounded-xl resize-none focus:outline-none focus:border-[#00bfa5] text-sm"
                autoFocus
              />
              <div className="flex gap-2 mt-3">
                <button
                  onClick={handleAddCustomPhrase}
                  disabled={!newPhrase.trim() || isSaving}
                  className="flex-1 flex items-center justify-center gap-2 py-2 bg-[#00bfa5] text-white rounded-lg font-medium disabled:opacity-50 transition-colors hover:bg-[#00a08a]"
                >
                  {isSaving ? (
                    <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full"></div>
                  ) : (
                    <CheckIcon size={16} />
                  )}
                  {isSaving ? 'Saving...' : 'Add'}
                </button>
                <button
                  onClick={() => {
                    setShowAddForm(false);
                    setNewPhrase('');
                  }}
                  className="px-4 py-2 bg-gray-100 text-gray-600 rounded-lg font-medium hover:bg-gray-200 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Info Banner */}
        <div className="bg-gradient-to-r from-[#1a2332] to-[#2d3e50] rounded-2xl p-6 sm:p-8 text-white">
          <div className="flex flex-col sm:flex-row items-center gap-6">
            <div className="flex-shrink-0">
              <div className="w-16 h-16 bg-[#ff6b35] rounded-2xl flex items-center justify-center">
                <HandsIcon size={32} />
              </div>
            </div>
            <div className="flex-1 text-center sm:text-left">
              <h3 className="text-xl font-bold mb-2">Your Phrases Sync Everywhere</h3>
              <p className="text-gray-300">
                Custom phrases are automatically saved to the cloud and synced across all your devices.
                Access your personalized phrases anytime, anywhere.
              </p>
            </div>
            <div className="flex-shrink-0 flex items-center gap-2 text-sm text-gray-400">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span>Auto-synced</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default QuickPhrasesSection;
