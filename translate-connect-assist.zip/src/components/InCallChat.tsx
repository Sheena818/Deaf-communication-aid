import React, { useState, useRef, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';

// Icons
const SendIcon: React.FC<{ size?: number; className?: string }> = ({ size = 24, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <line x1="22" y1="2" x2="11" y2="13" />
    <polygon points="22 2 15 22 11 13 2 9 22 2" />
  </svg>
);

const MessageCircleIcon: React.FC<{ size?: number; className?: string }> = ({ size = 24, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" />
  </svg>
);

const XIcon: React.FC<{ size?: number; className?: string }> = ({ size = 24, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <line x1="18" y1="6" x2="6" y2="18" />
    <line x1="6" y1="6" x2="18" y2="18" />
  </svg>
);

const SmileIcon: React.FC<{ size?: number; className?: string }> = ({ size = 24, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <circle cx="12" cy="12" r="10" />
    <path d="M8 14s1.5 2 4 2 4-2 4-2" />
    <line x1="9" y1="9" x2="9.01" y2="9" />
    <line x1="15" y1="9" x2="15.01" y2="9" />
  </svg>
);

const PaperclipIcon: React.FC<{ size?: number; className?: string }> = ({ size = 24, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48" />
  </svg>
);

const ImageIcon: React.FC<{ size?: number; className?: string }> = ({ size = 24, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <rect x="3" y="3" width="18" height="18" rx="2" ry="2" />
    <circle cx="8.5" cy="8.5" r="1.5" />
    <polyline points="21 15 16 10 5 21" />
  </svg>
);

const FileIcon: React.FC<{ size?: number; className?: string }> = ({ size = 24, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
    <polyline points="14 2 14 8 20 8" />
    <line x1="16" y1="13" x2="8" y2="13" />
    <line x1="16" y1="17" x2="8" y2="17" />
    <polyline points="10 9 9 9 8 9" />
  </svg>
);

const DownloadIcon: React.FC<{ size?: number; className?: string }> = ({ size = 24, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
    <polyline points="7 10 12 15 17 10" />
    <line x1="12" y1="15" x2="12" y2="3" />
  </svg>
);

const UploadCloudIcon: React.FC<{ size?: number; className?: string }> = ({ size = 24, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <polyline points="16 16 12 12 8 16" />
    <line x1="12" y1="12" x2="12" y2="21" />
    <path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3" />
    <polyline points="16 16 12 12 8 16" />
  </svg>
);

const LoaderIcon: React.FC<{ size?: number; className?: string }> = ({ size = 24, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={`animate-spin ${className}`}>
    <line x1="12" y1="2" x2="12" y2="6" />
    <line x1="12" y1="18" x2="12" y2="22" />
    <line x1="4.93" y1="4.93" x2="7.76" y2="7.76" />
    <line x1="16.24" y1="16.24" x2="19.07" y2="19.07" />
    <line x1="2" y1="12" x2="6" y2="12" />
    <line x1="18" y1="12" x2="22" y2="12" />
    <line x1="4.93" y1="19.07" x2="7.76" y2="16.24" />
    <line x1="16.24" y1="7.76" x2="19.07" y2="4.93" />
  </svg>
);

interface FileAttachment {
  url: string;
  fileName: string;
  fileType: string;
  fileSize: number;
  isImage: boolean;
  thumbnailUrl?: string | null;
}

interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  message: string;
  timestamp: string;
  isSystem?: boolean;
  isLocal?: boolean;
  attachment?: FileAttachment | null;
}

interface InCallChatProps {
  roomCode: string;
  participantId: string;
  displayName: string;
  isOpen: boolean;
  onClose: () => void;
  onNewMessage?: () => void;
}

// Common emoji shortcuts for quick access
const quickEmojis = ['👍', '👋', '😊', '❤️', '🎉', '👏', '🤔', '✅'];

// URL regex for detecting links
const urlRegex = /(https?:\/\/[^\s]+)/g;

// Allowed file types
const ALLOWED_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
const ALLOWED_DOC_TYPES = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'text/plain', 'application/zip', 'application/x-zip-compressed'];
const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB

// Function to render message with clickable links
const renderMessageWithLinks = (message: string) => {
  if (!message) return null;
  const parts = message.split(urlRegex);
  
  return parts.map((part, index) => {
    if (urlRegex.test(part)) {
      urlRegex.lastIndex = 0;
      return (
        <a
          key={index}
          href={part}
          target="_blank"
          rel="noopener noreferrer"
          className="text-blue-400 hover:text-blue-300 underline break-all"
          onClick={(e) => e.stopPropagation()}
        >
          {part}
        </a>
      );
    }
    return <span key={index}>{part}</span>;
  });
};

// Format file size
const formatFileSize = (bytes: number): string => {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
};

// Get file extension
const getFileExtension = (fileName: string): string => {
  const parts = fileName.split('.');
  return parts.length > 1 ? parts.pop()?.toUpperCase() || 'FILE' : 'FILE';
};

const InCallChat: React.FC<InCallChatProps> = ({
  roomCode,
  participantId,
  displayName,
  isOpen,
  onClose,
  onNewMessage,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [lastMessageId, setLastMessageId] = useState<string | null>(null);
  const [isDragOver, setIsDragOver] = useState(false);
  const [uploadingFile, setUploadingFile] = useState<File | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [pendingAttachment, setPendingAttachment] = useState<FileAttachment | null>(null);
  const [imagePreviewUrl, setImagePreviewUrl] = useState<string | null>(null);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const pollingRef = useRef<NodeJS.Timeout | null>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  // Scroll to bottom when new messages arrive
  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, []);

  // Fetch chat messages
  const fetchMessages = useCallback(async (isInitial = false) => {
    if (!roomCode) return;

    try {
      const { data, error } = await supabase.functions.invoke('video-signaling', {
        body: {
          action: 'get-chat',
          roomCode,
          participantId,
          lastMessageId: isInitial ? null : lastMessageId,
          limit: isInitial ? 100 : 20,
        },
      });

      if (error) {
        console.error('Error fetching chat:', error);
        return;
      }

      if (data?.messages && Array.isArray(data.messages)) {
        const newMessages = data.messages.map((msg: ChatMessage) => ({
          ...msg,
          isLocal: msg.senderId === participantId,
        }));

        if (isInitial) {
          setMessages(newMessages);
        } else if (newMessages.length > 0) {
          setMessages(prev => {
            const existingIds = new Set(prev.map(m => m.id));
            const uniqueNew = newMessages.filter((m: ChatMessage) => !existingIds.has(m.id));
            if (uniqueNew.length > 0) {
              onNewMessage?.();
              return [...prev, ...uniqueNew];
            }
            return prev;
          });
        }

        if (data.messages.length > 0) {
          const lastMsg = data.messages[data.messages.length - 1];
          setLastMessageId(lastMsg.id);
        }
      }
    } catch (err) {
      console.error('Failed to fetch chat:', err);
    }
  }, [roomCode, participantId, lastMessageId, onNewMessage]);

  // Upload file to Supabase storage
  const uploadFile = useCallback(async (file: File): Promise<FileAttachment | null> => {
    const isImage = ALLOWED_IMAGE_TYPES.includes(file.type);
    const isDoc = ALLOWED_DOC_TYPES.includes(file.type);

    if (!isImage && !isDoc) {
      alert('File type not supported. Please upload images (JPEG, PNG, GIF, WebP) or documents (PDF, DOC, DOCX, TXT, ZIP).');
      return null;
    }

    if (file.size > MAX_FILE_SIZE) {
      alert('File is too large. Maximum size is 10MB.');
      return null;
    }

    setUploadingFile(file);
    setUploadProgress(0);

    try {
      // Generate unique file path
      const timestamp = Date.now();
      const sanitizedName = file.name.replace(/[^a-zA-Z0-9.-]/g, '_');
      const filePath = `${roomCode}/${participantId}/${timestamp}_${sanitizedName}`;

      // Upload to Supabase storage
      const { data, error } = await supabase.storage
        .from('call-attachments')
        .upload(filePath, file, {
          cacheControl: '3600',
          upsert: false,
        });

      if (error) {
        console.error('Upload error:', error);
        throw new Error('Failed to upload file');
      }

      // Get public URL
      const { data: urlData } = supabase.storage
        .from('call-attachments')
        .getPublicUrl(data.path);

      setUploadProgress(100);

      const attachment: FileAttachment = {
        url: urlData.publicUrl,
        fileName: file.name,
        fileType: file.type,
        fileSize: file.size,
        isImage,
        thumbnailUrl: isImage ? urlData.publicUrl : null,
      };

      return attachment;
    } catch (err) {
      console.error('File upload failed:', err);
      alert('Failed to upload file. Please try again.');
      return null;
    } finally {
      setUploadingFile(null);
      setUploadProgress(0);
    }
  }, [roomCode, participantId]);

  // Handle file selection
  const handleFileSelect = useCallback(async (files: FileList | null) => {
    if (!files || files.length === 0) return;

    const file = files[0];
    const attachment = await uploadFile(file);
    
    if (attachment) {
      setPendingAttachment(attachment);
      if (attachment.isImage) {
        setImagePreviewUrl(attachment.url);
      }
    }
  }, [uploadFile]);

  // Handle drag events
  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);

    const files = e.dataTransfer.files;
    handleFileSelect(files);
  }, [handleFileSelect]);

  // Clear pending attachment
  const clearPendingAttachment = useCallback(() => {
    setPendingAttachment(null);
    setImagePreviewUrl(null);
  }, []);

  // Send a message
  const sendMessage = useCallback(async () => {
    if ((!inputValue.trim() && !pendingAttachment) || isSending) return;

    const messageText = inputValue.trim();
    setInputValue('');
    setIsSending(true);

    const optimisticMessage: ChatMessage = {
      id: `temp-${Date.now()}`,
      senderId: participantId,
      senderName: displayName,
      message: messageText,
      timestamp: new Date().toISOString(),
      isLocal: true,
      attachment: pendingAttachment,
    };
    setMessages(prev => [...prev, optimisticMessage]);
    clearPendingAttachment();
    scrollToBottom();

    try {
      const { data, error } = await supabase.functions.invoke('video-signaling', {
        body: {
          action: 'send-chat',
          roomCode,
          participantId,
          senderName: displayName,
          message: messageText,
          attachment: pendingAttachment,
        },
      });

      if (error) {
        console.error('Error sending message:', error);
        setMessages(prev => prev.filter(m => m.id !== optimisticMessage.id));
        setInputValue(messageText);
        if (pendingAttachment) setPendingAttachment(pendingAttachment);
      } else if (data?.chatMessage) {
        setMessages(prev => 
          prev.map(m => 
            m.id === optimisticMessage.id 
              ? { ...data.chatMessage, isLocal: true }
              : m
          )
        );
      }
    } catch (err) {
      console.error('Failed to send message:', err);
      setMessages(prev => prev.filter(m => m.id !== optimisticMessage.id));
      setInputValue(messageText);
    } finally {
      setIsSending(false);
    }
  }, [inputValue, isSending, roomCode, participantId, displayName, scrollToBottom, pendingAttachment, clearPendingAttachment]);

  // Handle key press
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  // Add emoji to input
  const addEmoji = (emoji: string) => {
    setInputValue(prev => prev + emoji);
    setShowEmojiPicker(false);
    inputRef.current?.focus();
  };

  // Format timestamp
  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  // Start polling for messages
  useEffect(() => {
    if (isOpen && roomCode) {
      fetchMessages(true);

      pollingRef.current = setInterval(() => {
        fetchMessages(false);
      }, 2000);

      return () => {
        if (pollingRef.current) {
          clearInterval(pollingRef.current);
        }
      };
    }
  }, [isOpen, roomCode, fetchMessages]);

  // Scroll to bottom when messages change
  useEffect(() => {
    scrollToBottom();
  }, [messages, scrollToBottom]);

  // Focus input when chat opens
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div 
      ref={chatContainerRef}
      className={`absolute right-0 top-0 bottom-0 w-80 sm:w-96 bg-gray-900/95 backdrop-blur-sm border-l border-gray-700 flex flex-col z-20 ${
        isDragOver ? 'ring-2 ring-purple-500 ring-inset' : ''
      }`}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
    >
      {/* Drag overlay */}
      {isDragOver && (
        <div className="absolute inset-0 bg-purple-900/80 backdrop-blur-sm z-30 flex flex-col items-center justify-center">
          <UploadCloudIcon size={64} className="text-purple-300 mb-4" />
          <p className="text-white text-lg font-semibold">Drop file to share</p>
          <p className="text-purple-200 text-sm mt-2">Images, PDFs, documents up to 10MB</p>
        </div>
      )}

      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-gray-700 bg-gray-800/50">
        <div className="flex items-center gap-2">
          <MessageCircleIcon className="text-purple-400" size={20} />
          <h3 className="text-white font-semibold">In-Call Chat</h3>
          <span className="text-xs text-gray-400 bg-gray-700 px-2 py-0.5 rounded-full">
            {messages.length}
          </span>
        </div>
        <button
          onClick={onClose}
          className="p-1 hover:bg-gray-700 rounded-lg transition-colors"
          title="Close chat"
        >
          <XIcon className="text-gray-400 hover:text-white" size={20} />
        </button>
      </div>

      {/* Info Banner */}
      <div className="px-4 py-2 bg-purple-900/30 border-b border-purple-800/50">
        <p className="text-xs text-purple-200">
          Share messages, links & files. Drag & drop or click the attachment icon.
        </p>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <MessageCircleIcon className="text-gray-600 mb-3" size={48} />
            <p className="text-gray-400 text-sm">No messages yet</p>
            <p className="text-gray-500 text-xs mt-1">
              Start the conversation or share a file!
            </p>
          </div>
        ) : (
          messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex flex-col ${msg.isLocal ? 'items-end' : 'items-start'}`}
            >
              {/* Sender name (only for others) */}
              {!msg.isLocal && (
                <span className="text-xs text-gray-400 mb-1 ml-1">
                  {msg.senderName}
                </span>
              )}
              
              {/* Message bubble */}
              <div
                className={`max-w-[85%] px-3 py-2 rounded-2xl ${
                  msg.isLocal
                    ? 'bg-purple-600 text-white rounded-br-md'
                    : 'bg-gray-700 text-white rounded-bl-md'
                } ${msg.isSystem ? 'bg-gray-800 italic text-gray-400 text-center w-full' : ''}`}
              >
                {/* Attachment preview */}
                {msg.attachment && (
                  <div className="mb-2">
                    {msg.attachment.isImage ? (
                      <a 
                        href={msg.attachment.url} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="block"
                      >
                        <img 
                          src={msg.attachment.url} 
                          alt={msg.attachment.fileName}
                          className="max-w-full rounded-lg max-h-48 object-cover hover:opacity-90 transition-opacity cursor-pointer"
                        />
                      </a>
                    ) : (
                      <a
                        href={msg.attachment.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className={`flex items-center gap-3 p-3 rounded-lg transition-colors ${
                          msg.isLocal 
                            ? 'bg-purple-700/50 hover:bg-purple-700/70' 
                            : 'bg-gray-600/50 hover:bg-gray-600/70'
                        }`}
                      >
                        <div className={`p-2 rounded-lg ${msg.isLocal ? 'bg-purple-500' : 'bg-gray-500'}`}>
                          <FileIcon size={20} className="text-white" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">{msg.attachment.fileName}</p>
                          <p className="text-xs opacity-70">
                            {getFileExtension(msg.attachment.fileName)} • {formatFileSize(msg.attachment.fileSize)}
                          </p>
                        </div>
                        <DownloadIcon size={18} className="text-white/70" />
                      </a>
                    )}
                  </div>
                )}

                {/* Text message */}
                {msg.message && (
                  <p className="text-sm break-words whitespace-pre-wrap">
                    {renderMessageWithLinks(msg.message)}
                  </p>
                )}
              </div>
              
              {/* Timestamp */}
              <span className="text-[10px] text-gray-500 mt-1 mx-1">
                {formatTime(msg.timestamp)}
              </span>
            </div>
          ))
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Pending Attachment Preview */}
      {pendingAttachment && (
        <div className="px-4 py-3 bg-gray-800 border-t border-gray-700">
          <div className="flex items-center gap-3">
            {pendingAttachment.isImage && imagePreviewUrl ? (
              <img 
                src={imagePreviewUrl} 
                alt="Preview" 
                className="w-16 h-16 object-cover rounded-lg"
              />
            ) : (
              <div className="w-16 h-16 bg-gray-700 rounded-lg flex items-center justify-center">
                <FileIcon size={24} className="text-gray-400" />
              </div>
            )}
            <div className="flex-1 min-w-0">
              <p className="text-sm text-white font-medium truncate">{pendingAttachment.fileName}</p>
              <p className="text-xs text-gray-400">
                {formatFileSize(pendingAttachment.fileSize)} • Ready to send
              </p>
            </div>
            <button
              onClick={clearPendingAttachment}
              className="p-2 hover:bg-gray-700 rounded-lg transition-colors"
              title="Remove attachment"
            >
              <XIcon size={18} className="text-gray-400 hover:text-white" />
            </button>
          </div>
        </div>
      )}

      {/* Upload Progress */}
      {uploadingFile && (
        <div className="px-4 py-3 bg-gray-800 border-t border-gray-700">
          <div className="flex items-center gap-3">
            <LoaderIcon size={20} className="text-purple-400" />
            <div className="flex-1">
              <p className="text-sm text-white truncate">{uploadingFile.name}</p>
              <div className="mt-1 h-1.5 bg-gray-700 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-purple-500 transition-all duration-300"
                  style={{ width: `${uploadProgress}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Quick Emoji Bar */}
      {showEmojiPicker && (
        <div className="px-4 py-2 bg-gray-800 border-t border-gray-700">
          <div className="flex items-center gap-2 flex-wrap">
            {quickEmojis.map((emoji) => (
              <button
                key={emoji}
                onClick={() => addEmoji(emoji)}
                className="text-xl hover:scale-125 transition-transform p-1"
              >
                {emoji}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Input Area */}
      <div className="p-3 border-t border-gray-700 bg-gray-800/50">
        <div className="flex items-center gap-2">
          {/* Emoji toggle */}
          <button
            onClick={() => setShowEmojiPicker(!showEmojiPicker)}
            className={`p-2 rounded-lg transition-colors ${
              showEmojiPicker 
                ? 'bg-purple-600 text-white' 
                : 'hover:bg-gray-700 text-gray-400'
            }`}
            title="Quick emojis"
          >
            <SmileIcon size={20} />
          </button>

          {/* File attachment button */}
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={!!uploadingFile}
            className={`p-2 rounded-lg transition-colors ${
              uploadingFile 
                ? 'bg-gray-700 text-gray-500 cursor-not-allowed' 
                : 'hover:bg-gray-700 text-gray-400 hover:text-white'
            }`}
            title="Attach file"
          >
            <PaperclipIcon size={20} />
          </button>
          <input
            ref={fileInputRef}
            type="file"
            className="hidden"
            accept={[...ALLOWED_IMAGE_TYPES, ...ALLOWED_DOC_TYPES].join(',')}
            onChange={(e) => handleFileSelect(e.target.files)}
          />

          {/* Input field */}
          <div className="flex-1 relative">
            <input
              ref={inputRef}
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder={pendingAttachment ? "Add a message..." : "Type a message..."}
              className="w-full px-4 py-2 bg-gray-700 text-white rounded-full border border-gray-600 focus:border-purple-500 focus:outline-none focus:ring-1 focus:ring-purple-500 placeholder-gray-400 text-sm"
              disabled={isSending || !!uploadingFile}
            />
          </div>

          {/* Send button */}
          <button
            onClick={sendMessage}
            disabled={(!inputValue.trim() && !pendingAttachment) || isSending || !!uploadingFile}
            className={`p-2 rounded-full transition-all ${
              (inputValue.trim() || pendingAttachment) && !isSending && !uploadingFile
                ? 'bg-purple-600 hover:bg-purple-700 text-white'
                : 'bg-gray-700 text-gray-500 cursor-not-allowed'
            }`}
            title="Send message"
          >
            <SendIcon size={20} />
          </button>
        </div>

        {/* Character count for long messages */}
        {inputValue.length > 200 && (
          <div className="text-right mt-1">
            <span className={`text-xs ${inputValue.length > 500 ? 'text-red-400' : 'text-gray-500'}`}>
              {inputValue.length}/500
            </span>
          </div>
        )}
      </div>

      {/* Accessibility hint */}
      <div className="px-4 py-2 bg-gray-900 border-t border-gray-800">
        <p className="text-[10px] text-gray-500 text-center">
          Press Enter to send • Drag & drop files • Great for deaf users
        </p>
      </div>
    </div>
  );
};

export default InCallChat;
