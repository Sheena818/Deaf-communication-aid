import React, { useState, useRef, useEffect } from 'react';
import { useSpeechRecognition } from '@/hooks/useSpeechRecognition';
import { useTextToSpeech } from '@/hooks/useTextToSpeech';
import { Message } from '@/types';
import {
  MicrophoneIcon,
  SpeakerIcon,
  SendIcon,
  StopIcon,
  PlayIcon,
  PauseIcon,
  CopyIcon,
  TrashIcon,
  WaveformIcon,
} from './icons/Icons';


interface CommunicationPanelProps {
  messages: Message[];
  onAddMessage: (message: Omit<Message, 'id' | 'timestamp'>) => void;
  onClearMessages: () => void;
  isLoading?: boolean;
}

const CommunicationPanel: React.FC<CommunicationPanelProps> = ({
  messages,
  onAddMessage,
  onClearMessages,
  isLoading = false,
}) => {
  const [mode, setMode] = useState<'speech-to-text' | 'text-to-speech'>('speech-to-text');
  const [textInput, setTextInput] = useState('');
  const [copied, setCopied] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const {
    transcript,
    interimTranscript,
    isListening,
    isSupported: speechSupported,
    startListening,
    stopListening,
    resetTranscript,
  } = useSpeechRecognition();

  const {
    speak,
    stop: stopSpeaking,
    pause,
    resume,
    isSpeaking,
    isPaused,
    isSupported: ttsSupported,
    rate,
    setRate,
  } = useTextToSpeech();

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendTranscript = () => {
    if (transcript.trim()) {
      onAddMessage({
        text: transcript.trim(),
        sender: 'other',
        type: 'speech',
      });
      resetTranscript();
    }
  };

  const handleSendText = () => {
    if (textInput.trim()) {
      onAddMessage({
        text: textInput.trim(),
        sender: 'user',
        type: 'text',
      });
      speak(textInput.trim());
      setTextInput('');
    }
  };

  const handleCopyTranscript = () => {
    navigator.clipboard.writeText(transcript);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendText();
    }
  };

  return (
    <section id="communicate" className="py-12 sm:py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-[#1a2332] mb-4">
            Real-Time Communication
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Choose your preferred mode and start communicating instantly. 
            Speech is converted to text, and text is spoken aloud.
          </p>
        </div>

        {/* Mode Toggle */}
        <div className="flex justify-center mb-8">
          <div className="inline-flex bg-gray-100 rounded-2xl p-1.5">
            <button
              onClick={() => setMode('speech-to-text')}
              className={`flex items-center gap-2 px-6 py-3 rounded-xl font-semibold transition-all duration-200 ${
                mode === 'speech-to-text'
                  ? 'bg-[#00bfa5] text-white shadow-lg'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              <MicrophoneIcon size={20} />
              Speech to Text
            </button>
            <button
              onClick={() => setMode('text-to-speech')}
              className={`flex items-center gap-2 px-6 py-3 rounded-xl font-semibold transition-all duration-200 ${
                mode === 'text-to-speech'
                  ? 'bg-[#ff6b35] text-white shadow-lg'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              <SpeakerIcon size={20} />
              Text to Speech
            </button>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Communication Interface */}
          <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-3xl p-6 sm:p-8 shadow-xl">
            {mode === 'speech-to-text' ? (
              /* Speech to Text Mode */
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-xl font-bold text-[#1a2332]">
                    Listening Mode
                  </h3>
                  {!speechSupported && (
                    <span className="text-sm text-red-500">
                      Speech recognition not supported in this browser
                    </span>
                  )}
                </div>

                {/* Transcript Display */}
                <div className="bg-white rounded-2xl p-6 min-h-[200px] shadow-inner border-2 border-gray-200">
                  {isListening && (
                    <div className="flex items-center gap-2 mb-4">
                      <div className="flex gap-1">
                        <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></span>
                        <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse delay-75"></span>
                        <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse delay-150"></span>
                      </div>
                      <span className="text-sm text-red-500 font-medium">Recording...</span>
                    </div>
                  )}
                  
                  <p className="text-xl sm:text-2xl leading-relaxed text-gray-800">
                    {transcript || interimTranscript || (
                      <span className="text-gray-400 italic">
                        {isListening ? 'Speak now...' : 'Press the microphone to start listening'}
                      </span>
                    )}
                    {interimTranscript && (
                      <span className="text-gray-400">{interimTranscript}</span>
                    )}
                  </p>
                </div>

                {/* Controls */}
                <div className="flex flex-wrap items-center justify-center gap-4">
                  <button
                    onClick={isListening ? stopListening : startListening}
                    disabled={!speechSupported}
                    className={`flex items-center justify-center w-16 h-16 sm:w-20 sm:h-20 rounded-full transition-all duration-300 shadow-lg ${
                      isListening
                        ? 'bg-red-500 hover:bg-red-600 animate-pulse'
                        : 'bg-[#00bfa5] hover:bg-[#00a08a]'
                    } text-white disabled:opacity-50 disabled:cursor-not-allowed`}
                    aria-label={isListening ? 'Stop listening' : 'Start listening'}
                  >
                    {isListening ? <StopIcon size={32} /> : <MicrophoneIcon size={32} />}
                  </button>

                  {transcript && (
                    <>
                      <button
                        onClick={handleCopyTranscript}
                        className="flex items-center gap-2 px-4 py-3 bg-gray-200 hover:bg-gray-300 rounded-xl transition-colors"
                      >
                        <CopyIcon size={18} />
                        {copied ? 'Copied!' : 'Copy'}
                      </button>
                      <button
                        onClick={handleSendTranscript}
                        className="flex items-center gap-2 px-6 py-3 bg-[#00bfa5] hover:bg-[#00a08a] text-white rounded-xl font-semibold transition-colors"
                      >
                        <SendIcon size={18} />
                        Save to History
                      </button>
                      <button
                        onClick={resetTranscript}
                        className="flex items-center gap-2 px-4 py-3 bg-gray-200 hover:bg-gray-300 rounded-xl transition-colors"
                      >
                        <TrashIcon size={18} />
                        Clear
                      </button>
                    </>
                  )}
                </div>
              </div>
            ) : (
              /* Text to Speech Mode */
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-xl font-bold text-[#1a2332]">
                    Type to Speak
                  </h3>
                  {!ttsSupported && (
                    <span className="text-sm text-red-500">
                      Text-to-speech not supported in this browser
                    </span>
                  )}
                </div>

                {/* Text Input */}
                <div className="relative">
                  <textarea
                    value={textInput}
                    onChange={(e) => setTextInput(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="Type your message here..."
                    className="w-full h-40 p-6 text-xl rounded-2xl border-2 border-gray-200 focus:border-[#ff6b35] focus:ring-4 focus:ring-[#ff6b35]/20 outline-none resize-none transition-all"
                    aria-label="Message input"
                  />
                  {isSpeaking && (
                    <div className="absolute top-4 right-4 flex items-center gap-2 text-[#ff6b35]">
                      <WaveformIcon size={20} className="animate-pulse" />
                      <span className="text-sm font-medium">Speaking...</span>
                    </div>
                  )}
                </div>

                {/* Speed Control */}
                <div className="flex items-center gap-4">
                  <label className="text-sm font-medium text-gray-600">Speed:</label>
                  <input
                    type="range"
                    min="0.5"
                    max="2"
                    step="0.1"
                    value={rate}
                    onChange={(e) => setRate(parseFloat(e.target.value))}
                    className="flex-1 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-[#ff6b35]"
                  />
                  <span className="text-sm font-medium text-gray-600 w-12">{rate}x</span>
                </div>

                {/* Controls */}
                <div className="flex flex-wrap items-center justify-center gap-4">
                  <button
                    onClick={handleSendText}
                    disabled={!textInput.trim() || !ttsSupported}
                    className="flex items-center gap-2 px-8 py-4 bg-[#ff6b35] hover:bg-[#e55a2b] text-white rounded-xl font-semibold transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg"
                  >
                    <SpeakerIcon size={20} />
                    Speak Message
                  </button>

                  {isSpeaking && (
                    <>
                      <button
                        onClick={isPaused ? resume : pause}
                        className="flex items-center gap-2 px-4 py-3 bg-gray-200 hover:bg-gray-300 rounded-xl transition-colors"
                      >
                        {isPaused ? <PlayIcon size={18} /> : <PauseIcon size={18} />}
                        {isPaused ? 'Resume' : 'Pause'}
                      </button>
                      <button
                        onClick={stopSpeaking}
                        className="flex items-center gap-2 px-4 py-3 bg-red-100 hover:bg-red-200 text-red-600 rounded-xl transition-colors"
                      >
                        <StopIcon size={18} />
                        Stop
                      </button>
                    </>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Conversation History */}
          <div className="bg-[#1a2332] rounded-3xl p-6 sm:p-8 shadow-xl">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-white flex items-center gap-2">
                Conversation History
                {isLoading && (
                  <span className="w-2 h-2 bg-[#00bfa5] rounded-full animate-pulse"></span>
                )}
              </h3>
              {messages.length > 0 && (
                <button
                  onClick={onClearMessages}
                  className="text-sm text-gray-400 hover:text-white transition-colors"
                >
                  Clear All
                </button>
              )}
            </div>

            <div className="h-[400px] overflow-y-auto space-y-4 pr-2 custom-scrollbar">
              {messages.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-gray-500">
                  <WaveformIcon size={48} className="mb-4 opacity-50" />
                  <p className="text-center">
                    Your conversation history will appear here.
                    <br />
                    Start communicating to see messages.
                  </p>
                </div>
              ) : (
                messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-[80%] rounded-2xl p-4 ${
                        message.sender === 'user'
                          ? 'bg-[#ff6b35] text-white'
                          : 'bg-[#00bfa5] text-white'
                      }`}
                    >
                      <p className="text-lg">{message.text}</p>
                      <div className="flex items-center justify-between mt-2 text-xs opacity-75">
                        <span>{message.type === 'speech' ? 'Speech' : message.type === 'phrase' ? 'Quick Phrase' : 'Text'}</span>
                        <span>
                          {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                    </div>
                  </div>
                ))
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Sync indicator */}
            <div className="mt-4 pt-4 border-t border-white/10 flex items-center justify-center gap-2 text-xs text-gray-400">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span>Synced across devices</span>
            </div>
          </div>
        </div>
      </div>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: rgba(255, 255, 255, 0.1);
          border-radius: 3px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(255, 255, 255, 0.3);
          border-radius: 3px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(255, 255, 255, 0.5);
        }
      `}</style>
    </section>
  );
};

export default CommunicationPanel;
