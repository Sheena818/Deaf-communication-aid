import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useWebRTC } from '@/hooks/useWebRTC';
import { useVideoReactions } from '@/hooks/useVideoReactions';
import { useVirtualBackground } from '@/hooks/useVirtualBackground';
import { useNoiseCancellation } from '@/hooks/useNoiseCancellation';
import InCallChat from './InCallChat';
import { ReactionOverlay, ReactionButton } from './VideoReactions';
import VirtualBackgroundPanel, { VirtualBackgroundButton } from './VirtualBackgroundPanel';
import {
  VideoIcon,
  VideoOffIcon,
  MicrophoneIcon,
  MicOffIcon,
  PhoneOffIcon,
  CaptionsIcon,
  ScreenShareIcon,
  MaximizeIcon,
  MinimizeIcon,
  UsersIcon,
  LinkIcon,
  CopyIcon,
  CheckIcon,
  GridIcon,
  SpeakerViewIcon,
} from './icons/Icons';

interface Caption {
  id: string;
  text: string;
  speaker: string;
  timestamp: Date;
  isFinal: boolean;
}

interface Participant {
  id: string;
  name: string;
  isLocal: boolean;
  isMuted: boolean;
  isVideoOff: boolean;
  stream?: MediaStream;
}

interface IceServerInfo {
  provider: string;
  hasTurn: boolean;
  message: string;
}

// Shield icon for TURN/security
const ShieldIcon: React.FC<{ size?: number; className?: string }> = ({ size = 24, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
  </svg>
);

// Signal icon for connection type
const SignalIcon: React.FC<{ size?: number; className?: string }> = ({ size = 24, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M2 20h.01" />
    <path d="M7 20v-4" />
    <path d="M12 20v-8" />
    <path d="M17 20V8" />
    <path d="M22 4v16" />
  </svg>
);

// Relay icon
const RelayIcon: React.FC<{ size?: number; className?: string }> = ({ size = 24, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <circle cx="12" cy="12" r="3" />
    <path d="M12 2v4" />
    <path d="M12 18v4" />
    <path d="M4.93 4.93l2.83 2.83" />
    <path d="M16.24 16.24l2.83 2.83" />
    <path d="M2 12h4" />
    <path d="M18 12h4" />
    <path d="M4.93 19.07l2.83-2.83" />
    <path d="M16.24 7.76l2.83-2.83" />
  </svg>
);

// Chat icon
const MessageCircleIcon: React.FC<{ size?: number; className?: string }> = ({ size = 24, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" />
  </svg>
);

// Smile icon for reactions
const SmileIcon: React.FC<{ size?: number; className?: string }> = ({ size = 24, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <circle cx="12" cy="12" r="10" />
    <path d="M8 14s1.5 2 4 2 4-2 4-2" />
    <line x1="9" y1="9" x2="9.01" y2="9" />
    <line x1="15" y1="9" x2="15.01" y2="9" />
  </svg>
);

// Image icon for virtual backgrounds
const ImageIcon: React.FC<{ size?: number; className?: string }> = ({ size = 24, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <rect x="3" y="3" width="18" height="18" rx="2" ry="2" />
    <circle cx="8.5" cy="8.5" r="1.5" />
    <polyline points="21 15 16 10 5 21" />
  </svg>
);

// Noise cancellation icon
const NoiseIcon: React.FC<{ size?: number; className?: string }> = ({ size = 24, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M2 12h2" />
    <path d="M6 8v8" />
    <path d="M10 4v16" />
    <path d="M14 6v12" />
    <path d="M18 9v6" />
    <path d="M22 12h-2" />
  </svg>
);

// Waveform icon for audio visualization
const WaveformIcon: React.FC<{ size?: number; className?: string }> = ({ size = 24, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M2 12h2" />
    <path d="M6 8v8" />
    <path d="M10 5v14" />
    <path d="M14 7v10" />
    <path d="M18 10v4" />
    <path d="M22 12h-2" />
  </svg>
);

const VideoCallSection: React.FC = () => {
  const { user } = useAuth();
  const [isInCall, setIsInCall] = useState(false);
  const [isJoining, setIsJoining] = useState(false);
  const [roomId, setRoomId] = useState('');
  const [generatedRoomId, setGeneratedRoomId] = useState('');
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [isCaptionsEnabled, setIsCaptionsEnabled] = useState(true);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [viewMode, setViewMode] = useState<'speaker' | 'grid'>('speaker');
  const [captions, setCaptions] = useState<Caption[]>([]);
  const [currentTranscript, setCurrentTranscript] = useState('');
  const [copied, setCopied] = useState(false);
  const [callDuration, setCallDuration] = useState(0);
  const [participants, setParticipants] = useState<Participant[]>([]);
  const [connectionStatus, setConnectionStatus] = useState<string>('');
  const [remoteStreams, setRemoteStreams] = useState<Map<string, MediaStream>>(new Map());
  const [iceServerInfo, setIceServerInfo] = useState<IceServerInfo | null>(null);
  const [showNetworkInfo, setShowNetworkInfo] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [unreadMessages, setUnreadMessages] = useState(0);
  const [isVirtualBgPanelOpen, setIsVirtualBgPanelOpen] = useState(false);
  const [virtualBgEnabled, setVirtualBgEnabled] = useState(false);
  const [noiseCancellationEnabled, setNoiseCancellationEnabled] = useState(false);
  const [showNoiseStats, setShowNoiseStats] = useState(false);

  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRefs = useRef<Map<string, HTMLVideoElement>>(new Map());
  const containerRef = useRef<HTMLDivElement>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const screenStreamRef = useRef<MediaStream | null>(null);
  const recognitionRef = useRef<any>(null);
  const callTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Generate unique participant ID
  const participantId = useRef(
    user?.id || `guest-${Math.random().toString(36).substring(2, 9)}`
  ).current;

  // Current room code for WebRTC
  const currentRoomCode = generatedRoomId || roomId;

  // Noise Cancellation hook
  const {
    isProcessing: ncProcessing,
    processedStream: ncProcessedStream,
    noiseStats,
    error: ncError,
  } = useNoiseCancellation({
    inputStream: localStreamRef.current,
    enabled: noiseCancellationEnabled,
  });

  // Virtual Background hook
  const {
    isLoading: vbLoading,
    isModelLoaded: vbModelLoaded,
    error: vbError,
    selectedBackground,
    customBackgrounds,
    allBackgrounds,
    processedStream,
    selectBackground,
    addCustomBackground,
    removeCustomBackground,
  } = useVirtualBackground({
    inputStream: localStreamRef.current,
    enabled: virtualBgEnabled && selectedBackground.type !== 'none',
  });

  // Video Reactions hook
  const {
    animatedReactions,
    isPickerOpen,
    setIsPickerOpen,
    sendReaction,
  } = useVideoReactions({
    roomCode: currentRoomCode,
    participantId,
    displayName: user?.displayName || 'Guest',
    isInCall,
  });

  // WebRTC hook
  const {
    isConnected,
    connectionState,
    iceConnectionType,
    turnProvider,
    joinRoom,
    createRoom,
    leaveRoom,
    forceTurnRelay,
    participants: rtcParticipants,
  } = useWebRTC({
    roomCode: currentRoomCode,
    participantId,
    displayName: user?.displayName || 'Guest',
    onParticipantJoined: (participant) => {
      console.log('Participant joined:', participant);
      setParticipants(prev => {
        if (prev.find(p => p.id === participant.id)) return prev;
        return [...prev, participant];
      });
      setConnectionStatus(`${participant.name} joined`);
      setTimeout(() => setConnectionStatus(''), 3000);
    },
    onParticipantLeft: (leftParticipantId) => {
      console.log('Participant left:', leftParticipantId);
      setParticipants(prev => prev.filter(p => p.id !== leftParticipantId));
      setRemoteStreams(prev => {
        const newMap = new Map(prev);
        newMap.delete(leftParticipantId);
        return newMap;
      });
      setConnectionStatus('Participant left');
      setTimeout(() => setConnectionStatus(''), 3000);
    },
    onRemoteStream: (remoteParticipantId, stream) => {
      console.log('Received remote stream from:', remoteParticipantId);
      setRemoteStreams(prev => {
        const newMap = new Map(prev);
        newMap.set(remoteParticipantId, stream);
        return newMap;
      });
      
      // Update participant with stream
      setParticipants(prev => 
        prev.map(p => 
          p.id === remoteParticipantId 
            ? { ...p, stream } 
            : p
        )
      );
    },
    onError: (error) => {
      console.error('WebRTC error:', error);
      setConnectionStatus(`Error: ${error.message}`);
    },
    onIceServerInfo: (info) => {
      console.log('ICE server info:', info);
      setIceServerInfo(info);
    },
  });

  // Update local video when processed stream changes
  useEffect(() => {
    if (localVideoRef.current && processedStream && virtualBgEnabled) {
      localVideoRef.current.srcObject = processedStream;
    } else if (localVideoRef.current && localStreamRef.current && !virtualBgEnabled) {
      localVideoRef.current.srcObject = localStreamRef.current;
    }
  }, [processedStream, virtualBgEnabled]);

  // Generate a random room ID
  const generateRoomId = () => {
    const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < 3; i++) {
      for (let j = 0; j < 3; j++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      if (i < 2) result += '-';
    }
    return result;
  };

  // Initialize speech recognition for captions
  const initSpeechRecognition = useCallback(() => {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      console.warn('Speech recognition not supported');
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'en-US';

    recognition.onresult = (event: any) => {
      let interimTranscript = '';
      let finalTranscript = '';

      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          finalTranscript += transcript;
        } else {
          interimTranscript += transcript;
        }
      }

      setCurrentTranscript(interimTranscript);

      if (finalTranscript) {
        const newCaption: Caption = {
          id: Date.now().toString(),
          text: finalTranscript,
          speaker: user?.displayName || 'You',
          timestamp: new Date(),
          isFinal: true,
        };
        setCaptions(prev => [...prev.slice(-10), newCaption]);
        setCurrentTranscript('');
      }
    };

    recognition.onerror = (event: any) => {
      console.error('Speech recognition error:', event.error);
      if (event.error !== 'no-speech') {
        setTimeout(() => {
          if (recognitionRef.current && isInCall && isCaptionsEnabled) {
            try {
              recognitionRef.current.start();
            } catch (e) {
              // Already started
            }
          }
        }, 1000);
      }
    };

    recognition.onend = () => {
      if (isInCall && isCaptionsEnabled) {
        try {
          recognition.start();
        } catch (e) {
          // Already started
        }
      }
    };

    recognitionRef.current = recognition;
    return recognition;
  }, [user, isInCall, isCaptionsEnabled]);

  // Start local video stream
  const startLocalStream = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true,
      });
      
      localStreamRef.current = stream;
      
      if (localVideoRef.current) {
        localVideoRef.current.srcObject = stream;
      }

      return stream;
    } catch (error) {
      console.error('Error accessing media devices:', error);
      throw error;
    }
  };

  // Stop local stream
  const stopLocalStream = () => {
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach(track => track.stop());
      localStreamRef.current = null;
    }
    if (screenStreamRef.current) {
      screenStreamRef.current.getTracks().forEach(track => track.stop());
      screenStreamRef.current = null;
    }
  };

  // Start call
  const startCall = async (isNewRoom: boolean = true) => {
    setIsJoining(true);
    setConnectionStatus('Starting call...');
    
    try {
      const stream = await startLocalStream();
      
      let newRoomId = roomId;
      if (isNewRoom) {
        newRoomId = generateRoomId();
        setGeneratedRoomId(newRoomId);
        setRoomId(newRoomId);
      }
      
      // Add local participant
      setParticipants([{
        id: participantId,
        name: user?.displayName || 'You',
        isLocal: true,
        isMuted: false,
        isVideoOff: false,
        stream,
      }]);
      
      setIsInCall(true);
      setConnectionStatus('Connecting...');
      
      // Create or join room via WebRTC
      if (isNewRoom) {
        await createRoom(stream);
        setConnectionStatus('Waiting for others to join...');
      } else {
        await joinRoom(stream);
        setConnectionStatus('Connected');
      }
      
      // Start call timer
      callTimerRef.current = setInterval(() => {
        setCallDuration(prev => prev + 1);
      }, 1000);

      // Start speech recognition for captions
      if (isCaptionsEnabled) {
        const recognition = initSpeechRecognition();
        if (recognition) {
          try {
            recognition.start();
          } catch (e) {
            // Already started
          }
        }
      }

    } catch (error) {
      console.error('Failed to start call:', error);
      setConnectionStatus('Failed to start call');
      alert('Failed to access camera/microphone. Please check permissions.');
      setIsInCall(false);
    } finally {
      setIsJoining(false);
    }
  };

  // End call
  const endCall = async () => {
    stopLocalStream();
    await leaveRoom();
    
    setIsInCall(false);
    setCallDuration(0);
    setCaptions([]);
    setCurrentTranscript('');
    setParticipants([]);
    setRemoteStreams(new Map());
    setIsScreenSharing(false);
    setConnectionStatus('');
    setGeneratedRoomId('');
    setIceServerInfo(null);
    setIsChatOpen(false);
    setUnreadMessages(0);
    setVirtualBgEnabled(false);
    setNoiseCancellationEnabled(false);
    setShowNoiseStats(false);
    
    if (callTimerRef.current) {
      clearInterval(callTimerRef.current);
      callTimerRef.current = null;
    }
    
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (e) {
        // Already stopped
      }
    }
  };

  // Toggle mute
  const toggleMute = () => {
    if (localStreamRef.current) {
      const audioTrack = localStreamRef.current.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = isMuted;
        setIsMuted(!isMuted);
      }
    }
  };

  // Toggle video
  const toggleVideo = () => {
    if (localStreamRef.current) {
      const videoTrack = localStreamRef.current.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.enabled = isVideoOff;
        setIsVideoOff(!isVideoOff);
      }
    }
  };

  // Toggle captions
  const toggleCaptions = () => {
    setIsCaptionsEnabled(!isCaptionsEnabled);
    
    if (!isCaptionsEnabled && recognitionRef.current) {
      try {
        recognitionRef.current.start();
      } catch (e) {
        // Already started
      }
    } else if (isCaptionsEnabled && recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (e) {
        // Already stopped
      }
    }
  };

  // Toggle noise cancellation
  const toggleNoiseCancellation = () => {
    setNoiseCancellationEnabled(!noiseCancellationEnabled);
  };

  // Toggle screen share
  const toggleScreenShare = async () => {
    if (!isScreenSharing) {
      try {
        const screenStream = await navigator.mediaDevices.getDisplayMedia({
          video: true,
          audio: true,
        });
        
        screenStreamRef.current = screenStream;
        
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = screenStream;
        }
        
        setIsScreenSharing(true);
        
        screenStream.getVideoTracks()[0].onended = () => {
          if (localStreamRef.current && localVideoRef.current) {
            localVideoRef.current.srcObject = localStreamRef.current;
          }
          setIsScreenSharing(false);
        };
      } catch (error) {
        console.error('Error sharing screen:', error);
      }
    } else {
      if (screenStreamRef.current) {
        screenStreamRef.current.getTracks().forEach(track => track.stop());
        screenStreamRef.current = null;
      }
      
      if (localStreamRef.current && localVideoRef.current) {
        localVideoRef.current.srcObject = localStreamRef.current;
      }
      
      setIsScreenSharing(false);
    }
  };

  // Toggle fullscreen
  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  // Toggle chat
  const toggleChat = () => {
    setIsChatOpen(!isChatOpen);
    if (!isChatOpen) {
      setUnreadMessages(0);
    }
  };

  // Handle new chat message
  const handleNewChatMessage = () => {
    if (!isChatOpen) {
      setUnreadMessages(prev => prev + 1);
    }
  };

  // Copy room link
  const copyRoomLink = () => {
    const link = `${window.location.origin}?room=${generatedRoomId || roomId}`;
    navigator.clipboard.writeText(link);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Format call duration
  const formatDuration = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    if (hrs > 0) {
      return `${hrs}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  // Get connection type display info
  const getConnectionTypeInfo = () => {
    switch (iceConnectionType) {
      case 'relay':
        return {
          label: 'TURN Relay',
          color: 'text-yellow-400',
          bgColor: 'bg-yellow-500/20',
          icon: RelayIcon,
          description: 'Connection via TURN server (may have higher latency)'
        };
      case 'direct':
        return {
          label: 'Direct P2P',
          color: 'text-green-400',
          bgColor: 'bg-green-500/20',
          icon: SignalIcon,
          description: 'Direct peer-to-peer connection (optimal performance)'
        };
      default:
        return {
          label: 'Connecting...',
          color: 'text-gray-400',
          bgColor: 'bg-gray-500/20',
          icon: SignalIcon,
          description: 'Establishing connection...'
        };
    }
  };

  // Set remote video ref
  const setRemoteVideoRef = useCallback((participantId: string, element: HTMLVideoElement | null) => {
    if (element) {
      remoteVideoRefs.current.set(participantId, element);
      const stream = remoteStreams.get(participantId);
      if (stream) {
        element.srcObject = stream;
      }
    } else {
      remoteVideoRefs.current.delete(participantId);
    }
  }, [remoteStreams]);

  // Update remote video elements when streams change
  useEffect(() => {
    remoteStreams.forEach((stream, participantId) => {
      const videoElement = remoteVideoRefs.current.get(participantId);
      if (videoElement && videoElement.srcObject !== stream) {
        videoElement.srcObject = stream;
      }
    });
  }, [remoteStreams]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopLocalStream();
      if (callTimerRef.current) {
        clearInterval(callTimerRef.current);
      }
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (e) {
          // Already stopped
        }
      }
    };
  }, []);

  // Handle fullscreen change
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  // Check for room code in URL
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const roomFromUrl = urlParams.get('room');
    if (roomFromUrl) {
      setRoomId(roomFromUrl);
    }
  }, []);

  // Get remote participants (non-local)
  const remoteParticipants = participants.filter(p => !p.isLocal);
  const connectionTypeInfo = getConnectionTypeInfo();

  return (
    <section id="video-call" className="py-16 sm:py-24 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-purple-100 text-purple-700 rounded-full text-sm font-medium mb-4">
            <VideoIcon size={16} />
            Video Calling with Live Captions
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            Accessible Video Calls
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Make video calls with built-in real-time speech-to-text captions, virtual backgrounds, noise cancellation, and more. 
            Connect with anyone using WebRTC peer-to-peer technology.
          </p>
        </div>

        {!isInCall ? (
          /* Pre-call Interface */
          <div className="max-w-2xl mx-auto">
            <div className="bg-white rounded-3xl shadow-xl border border-gray-100 overflow-hidden">
              {/* Header */}
              <div className="bg-gradient-to-r from-purple-600 to-indigo-600 p-6 text-white">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center">
                    <VideoIcon size={32} />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold">Start a Video Call</h3>
                    <p className="text-purple-100">With captions, chat, reactions, noise cancellation & virtual backgrounds</p>
                  </div>
                </div>
              </div>

              {/* Content */}
              <div className="p-6 space-y-6">
                {/* Start New Call */}
                <div className="space-y-4">
                  <button
                    onClick={() => startCall(true)}
                    disabled={isJoining}
                    className="w-full flex items-center justify-center gap-3 px-6 py-4 bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-2xl font-semibold text-lg hover:from-purple-700 hover:to-indigo-700 transition-all duration-200 hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed shadow-lg"
                  >
                    <VideoIcon size={24} />
                    {isJoining ? 'Starting...' : 'Start New Call'}
                  </button>
                </div>

                {/* Divider */}
                <div className="relative">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-gray-200" />
                  </div>
                  <div className="relative flex justify-center text-sm">
                    <span className="px-4 bg-white text-gray-500">or join existing</span>
                  </div>
                </div>

                {/* Join Call */}
                <div className="space-y-3">
                  <label className="block text-sm font-medium text-gray-700">
                    Enter Room Code
                  </label>
                  <div className="flex gap-3">
                    <input
                      type="text"
                      value={roomId}
                      onChange={(e) => setRoomId(e.target.value.toLowerCase())}
                      placeholder="abc-123-xyz"
                      className="flex-1 px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all text-lg font-mono"
                    />
                    <button
                      onClick={() => startCall(false)}
                      disabled={!roomId || isJoining}
                      className="px-6 py-3 bg-gray-900 text-white rounded-xl font-semibold hover:bg-gray-800 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      Join
                    </button>
                  </div>
                </div>

                {/* Features */}
                <div className="grid grid-cols-2 gap-4 pt-4">
                  <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
                    <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                      <CaptionsIcon className="text-purple-600" size={20} />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">Live Captions</p>
                      <p className="text-xs text-gray-500">Real-time transcription</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
                    <div className="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center">
                      <ImageIcon className="text-indigo-600" size={20} />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">Virtual Backgrounds</p>
                      <p className="text-xs text-gray-500">Blur, colors & images</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
                    <div className="w-10 h-10 bg-cyan-100 rounded-lg flex items-center justify-center">
                      <NoiseIcon className="text-cyan-600" size={20} />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">Noise Cancellation</p>
                      <p className="text-xs text-gray-500">AI-powered filtering</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
                    <div className="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center">
                      <SmileIcon className="text-yellow-600" size={20} />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">Reactions</p>
                      <p className="text-xs text-gray-500">Emoji reactions</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
                    <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                      <ShieldIcon className="text-orange-600" size={20} />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">TURN Relay</p>
                      <p className="text-xs text-gray-500">Works everywhere</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
                    <div className="w-10 h-10 bg-teal-100 rounded-lg flex items-center justify-center">
                      <MessageCircleIcon className="text-teal-600" size={20} />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">In-Call Chat</p>
                      <p className="text-xs text-gray-500">Text & file sharing</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* In-call Interface */
          <div 
            ref={containerRef}
            className={`bg-gray-900 rounded-3xl overflow-hidden shadow-2xl ${isFullscreen ? 'fixed inset-0 z-50 rounded-none' : ''}`}
          >
            {/* Call Header */}
            <div className="flex items-center justify-between px-4 py-3 bg-gray-800/50 backdrop-blur-sm">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <div className={`w-3 h-3 rounded-full animate-pulse ${isConnected ? 'bg-green-500' : 'bg-yellow-500'}`} />
                  <span className="text-white font-medium">{formatDuration(callDuration)}</span>
                </div>
                <div className="flex items-center gap-2 px-3 py-1 bg-gray-700 rounded-full">
                  <LinkIcon className="text-gray-400" size={14} />
                  <span className="text-gray-300 text-sm font-mono">{generatedRoomId || roomId}</span>
                  <button
                    onClick={copyRoomLink}
                    className="p-1 hover:bg-gray-600 rounded transition-colors"
                  >
                    {copied ? (
                      <CheckIcon className="text-green-400" size={14} />
                    ) : (
                      <CopyIcon className="text-gray-400" size={14} />
                    )}
                  </button>
                </div>
                {connectionStatus && (
                  <span className="text-sm text-gray-400">{connectionStatus}</span>
                )}
              </div>
              
              <div className="flex items-center gap-2">
                {/* Noise Cancellation Indicator */}
                {noiseCancellationEnabled && (
                  <button
                    onClick={() => setShowNoiseStats(!showNoiseStats)}
                    className="flex items-center gap-1.5 px-3 py-1 bg-cyan-500/20 rounded-full cursor-pointer hover:opacity-80 transition-opacity"
                    title="Noise cancellation active - click for details"
                  >
                    <NoiseIcon className="text-cyan-400" size={14} />
                    <span className="text-xs font-medium text-cyan-400">NC Active</span>
                    {ncProcessing && (
                      <span className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse" />
                    )}
                  </button>
                )}

                {/* Connection Type Indicator */}
                <button
                  onClick={() => setShowNetworkInfo(!showNetworkInfo)}
                  className={`flex items-center gap-1.5 px-3 py-1 ${connectionTypeInfo.bgColor} rounded-full cursor-pointer hover:opacity-80 transition-opacity`}
                  title={connectionTypeInfo.description}
                >
                  <connectionTypeInfo.icon className={connectionTypeInfo.color} size={14} />
                  <span className={`text-xs font-medium ${connectionTypeInfo.color}`}>
                    {connectionTypeInfo.label}
                  </span>
                </button>

                <div className="flex items-center gap-1 px-3 py-1 bg-gray-700 rounded-full">
                  <UsersIcon className="text-gray-400" size={14} />
                  <span className="text-gray-300 text-sm">{participants.length}</span>
                </div>
                <button
                  onClick={() => setViewMode(viewMode === 'speaker' ? 'grid' : 'speaker')}
                  className="p-2 hover:bg-gray-700 rounded-lg transition-colors"
                  title={viewMode === 'speaker' ? 'Grid View' : 'Speaker View'}
                >
                  {viewMode === 'speaker' ? (
                    <GridIcon className="text-gray-400" size={18} />
                  ) : (
                    <SpeakerViewIcon className="text-gray-400" size={18} />
                  )}
                </button>
                <button
                  onClick={toggleFullscreen}
                  className="p-2 hover:bg-gray-700 rounded-lg transition-colors"
                >
                  {isFullscreen ? (
                    <MinimizeIcon className="text-gray-400" size={18} />
                  ) : (
                    <MaximizeIcon className="text-gray-400" size={18} />
                  )}
                </button>
              </div>
            </div>

            {/* Noise Stats Panel */}
            {showNoiseStats && noiseCancellationEnabled && (
              <div className="px-4 py-3 bg-cyan-900/30 border-t border-cyan-700/50">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-6">
                    <div className="flex items-center gap-2">
                      <WaveformIcon className="text-cyan-400" size={16} />
                      <span className="text-gray-300 text-sm">Noise Cancellation Stats</span>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="flex items-center gap-2">
                        <span className="text-gray-400 text-xs">Input:</span>
                        <div className="w-24 h-2 bg-gray-700 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-cyan-500 transition-all duration-100"
                            style={{ width: `${Math.min(noiseStats.inputLevel, 100)}%` }}
                          />
                        </div>
                        <span className="text-cyan-400 text-xs font-mono">{noiseStats.inputLevel}%</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-gray-400 text-xs">Output:</span>
                        <div className="w-24 h-2 bg-gray-700 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-green-500 transition-all duration-100"
                            style={{ width: `${Math.min(noiseStats.outputLevel, 100)}%` }}
                          />
                        </div>
                        <span className="text-green-400 text-xs font-mono">{noiseStats.outputLevel}%</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-gray-400 text-xs">Reduction:</span>
                        <span className="text-cyan-400 text-sm font-bold">{noiseStats.noiseReduction}%</span>
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={() => setShowNoiseStats(false)}
                    className="text-gray-400 hover:text-white text-xs"
                  >
                    Hide
                  </button>
                </div>
                {ncError && (
                  <p className="text-red-400 text-xs mt-2">{ncError}</p>
                )}
              </div>
            )}

            {/* Network Info Panel */}
            {showNetworkInfo && (
              <div className="px-4 py-3 bg-gray-800/80 border-t border-gray-700">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      <ShieldIcon className="text-blue-400" size={16} />
                      <span className="text-gray-300 text-sm">
                        TURN Provider: <span className="text-white font-medium">{turnProvider || 'Loading...'}</span>
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <connectionTypeInfo.icon className={connectionTypeInfo.color} size={16} />
                      <span className="text-gray-300 text-sm">
                        Connection: <span className={`font-medium ${connectionTypeInfo.color}`}>{connectionTypeInfo.label}</span>
                      </span>
                    </div>
                    {iceServerInfo && (
                      <div className="flex items-center gap-2">
                        <span className={`px-2 py-0.5 rounded text-xs ${iceServerInfo.hasTurn ? 'bg-green-500/20 text-green-400' : 'bg-yellow-500/20 text-yellow-400'}`}>
                          {iceServerInfo.hasTurn ? 'TURN Available' : 'STUN Only'}
                        </span>
                      </div>
                    )}
                  </div>
                  <button
                    onClick={forceTurnRelay}
                    className="px-3 py-1 bg-yellow-600 hover:bg-yellow-700 text-white text-xs rounded-lg transition-colors"
                    title="Force connection through TURN relay (useful for troubleshooting)"
                  >
                    Force TURN Relay
                  </button>
                </div>
                {iceServerInfo?.message && (
                  <p className="text-gray-400 text-xs mt-2">{iceServerInfo.message}</p>
                )}
              </div>
            )}

            {/* Video Grid */}
            <div className={`relative ${isFullscreen ? 'h-[calc(100vh-180px)]' : 'aspect-video'}`}>
              {/* Reaction Overlay - positioned over the video area */}
              <ReactionOverlay animatedReactions={animatedReactions} />

              {viewMode === 'speaker' ? (
                /* Speaker View */
                <>
                  {/* Main Video (Remote or Waiting) */}
                  <div className={`absolute inset-0 bg-gray-800 ${isChatOpen ? 'mr-80 sm:mr-96' : ''} transition-all duration-300`}>
                    {remoteParticipants.length > 0 ? (
                      <div className="w-full h-full">
                        {remoteStreams.get(remoteParticipants[0].id) ? (
                          <video
                            ref={(el) => setRemoteVideoRef(remoteParticipants[0].id, el)}
                            autoPlay
                            playsInline
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <div className="text-center">
                              <div className="w-32 h-32 bg-gradient-to-br from-purple-500 to-indigo-500 rounded-full flex items-center justify-center mx-auto mb-4">
                                <span className="text-4xl font-bold text-white">
                                  {remoteParticipants[0].name.charAt(0).toUpperCase()}
                                </span>
                              </div>
                              <p className="text-white text-xl font-medium">
                                {remoteParticipants[0].name}
                              </p>
                              <p className="text-gray-400 text-sm">Connecting...</p>
                            </div>
                          </div>
                        )}
                        <div className="absolute bottom-4 left-4">
                          <span className="px-3 py-1 bg-black/50 rounded-lg text-white text-sm">
                            {remoteParticipants[0].name}
                          </span>
                        </div>
                      </div>
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <div className="text-center">
                          <UsersIcon className="text-gray-600 mx-auto mb-4" size={64} />
                          <p className="text-gray-400 text-lg">Waiting for others to join...</p>
                          <p className="text-gray-500 text-sm mt-2">Share the room code to invite</p>
                          <div className="mt-4 flex items-center justify-center gap-2">
                            <span className="px-4 py-2 bg-gray-700 rounded-lg text-white font-mono">
                              {generatedRoomId || roomId}
                            </span>
                            <button
                              onClick={copyRoomLink}
                              className="px-4 py-2 bg-purple-600 hover:bg-purple-700 rounded-lg text-white transition-colors"
                            >
                              {copied ? 'Copied!' : 'Copy Link'}
                            </button>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Local Video (Picture-in-Picture) */}
                  <div className={`absolute bottom-4 ${isChatOpen ? 'right-[calc(20rem+1rem)] sm:right-[calc(24rem+1rem)]' : 'right-4'} w-48 sm:w-64 aspect-video bg-gray-700 rounded-xl overflow-hidden shadow-xl border-2 border-gray-600 transition-all duration-300`}>
                    <video
                      ref={localVideoRef}
                      autoPlay
                      playsInline
                      muted
                      className={`w-full h-full object-cover ${isVideoOff ? 'hidden' : ''}`}
                    />
                    {isVideoOff && (
                      <div className="w-full h-full flex items-center justify-center bg-gray-800">
                        <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-indigo-500 rounded-full flex items-center justify-center">
                          <span className="text-xl font-bold text-white">
                            {(user?.displayName || 'You').charAt(0).toUpperCase()}
                          </span>
                        </div>
                      </div>
                    )}
                    <div className="absolute bottom-2 left-2 flex items-center gap-1">
                      <span className="px-2 py-0.5 bg-black/50 rounded text-white text-xs">You</span>
                      {isMuted && (
                        <span className="p-1 bg-red-500 rounded">
                          <MicOffIcon className="text-white" size={12} />
                        </span>
                      )}
                      {virtualBgEnabled && selectedBackground.type !== 'none' && (
                        <span className="p-1 bg-purple-500 rounded">
                          <ImageIcon className="text-white" size={12} />
                        </span>
                      )}
                      {noiseCancellationEnabled && (
                        <span className="p-1 bg-cyan-500 rounded">
                          <NoiseIcon className="text-white" size={12} />
                        </span>
                      )}
                    </div>
                  </div>
                </>
              ) : (
                /* Grid View */
                <div className={`grid gap-2 p-2 h-full ${
                  participants.length <= 2 ? 'grid-cols-2' : 
                  participants.length <= 4 ? 'grid-cols-2' : 
                  'grid-cols-3'
                } ${isChatOpen ? 'mr-80 sm:mr-96' : ''} transition-all duration-300`}>
                  {/* Local Video */}
                  <div className="relative bg-gray-800 rounded-xl overflow-hidden">
                    <video
                      ref={localVideoRef}
                      autoPlay
                      playsInline
                      muted
                      className={`w-full h-full object-cover ${isVideoOff ? 'hidden' : ''}`}
                    />
                    {isVideoOff && (
                      <div className="w-full h-full flex items-center justify-center">
                        <div className="w-20 h-20 bg-gradient-to-br from-purple-500 to-indigo-500 rounded-full flex items-center justify-center">
                          <span className="text-2xl font-bold text-white">
                            {(user?.displayName || 'You').charAt(0).toUpperCase()}
                          </span>
                        </div>
                      </div>
                    )}
                    <div className="absolute bottom-2 left-2 flex items-center gap-1">
                      <span className="px-2 py-0.5 bg-black/50 rounded text-white text-xs">You</span>
                      {isMuted && (
                        <span className="p-1 bg-red-500 rounded">
                          <MicOffIcon className="text-white" size={12} />
                        </span>
                      )}
                      {noiseCancellationEnabled && (
                        <span className="p-1 bg-cyan-500 rounded">
                          <NoiseIcon className="text-white" size={12} />
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Remote Participants */}
                  {remoteParticipants.map((participant) => (
                    <div key={participant.id} className="relative bg-gray-800 rounded-xl overflow-hidden">
                      {remoteStreams.get(participant.id) ? (
                        <video
                          ref={(el) => setRemoteVideoRef(participant.id, el)}
                          autoPlay
                          playsInline
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <div className="w-20 h-20 bg-gradient-to-br from-green-500 to-teal-500 rounded-full flex items-center justify-center">
                            <span className="text-2xl font-bold text-white">
                              {participant.name.charAt(0).toUpperCase()}
                            </span>
                          </div>
                        </div>
                      )}
                      <div className="absolute bottom-2 left-2">
                        <span className="px-2 py-0.5 bg-black/50 rounded text-white text-xs">
                          {participant.name}
                        </span>
                      </div>
                    </div>
                  ))}

                  {/* Empty slots */}
                  {participants.length < 2 && (
                    <div className="bg-gray-800 rounded-xl flex items-center justify-center">
                      <div className="text-center">
                        <UsersIcon className="text-gray-600 mx-auto mb-2" size={32} />
                        <p className="text-gray-500 text-sm">Waiting...</p>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* In-Call Chat Panel */}
              <InCallChat
                roomCode={currentRoomCode}
                participantId={participantId}
                displayName={user?.displayName || 'Guest'}
                isOpen={isChatOpen}
                onClose={() => setIsChatOpen(false)}
                onNewMessage={handleNewChatMessage}
              />

              {/* Captions Overlay */}
              {isCaptionsEnabled && (
                <div className={`absolute bottom-0 left-0 ${isChatOpen ? 'right-80 sm:right-96' : 'right-0'} p-4 bg-gradient-to-t from-black/80 to-transparent transition-all duration-300`}>
                  <div className="max-w-3xl mx-auto">
                    {/* Current transcript (interim) */}
                    {currentTranscript && (
                      <div className="text-center mb-2">
                        <span className="inline-block px-4 py-2 bg-gray-800/90 rounded-lg text-white text-lg italic">
                          {currentTranscript}...
                        </span>
                      </div>
                    )}
                    
                    {/* Final captions */}
                    <div className="space-y-2">
                      {captions.slice(-3).map((caption) => (
                        <div key={caption.id} className="text-center animate-in fade-in slide-in-from-bottom-2 duration-300">
                          <span className="inline-block px-4 py-2 bg-black/80 rounded-lg">
                            <span className="text-purple-400 font-medium mr-2">{caption.speaker}:</span>
                            <span className="text-white text-lg">{caption.text}</span>
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Call Controls */}
            <div className="flex items-center justify-center gap-3 sm:gap-4 p-4 bg-gray-800/50 backdrop-blur-sm">
              {/* Mute */}
              <button
                onClick={toggleMute}
                className={`p-4 rounded-full transition-all duration-200 hover:scale-110 ${
                  isMuted 
                    ? 'bg-red-500 hover:bg-red-600 text-white' 
                    : 'bg-gray-700 hover:bg-gray-600 text-white'
                }`}
                title={isMuted ? 'Unmute' : 'Mute'}
              >
                {isMuted ? <MicOffIcon size={24} /> : <MicrophoneIcon size={24} />}
              </button>

              {/* Video */}
              <button
                onClick={toggleVideo}
                className={`p-4 rounded-full transition-all duration-200 hover:scale-110 ${
                  isVideoOff 
                    ? 'bg-red-500 hover:bg-red-600 text-white' 
                    : 'bg-gray-700 hover:bg-gray-600 text-white'
                }`}
                title={isVideoOff ? 'Turn on camera' : 'Turn off camera'}
              >
                {isVideoOff ? <VideoOffIcon size={24} /> : <VideoIcon size={24} />}
              </button>

              {/* Noise Cancellation */}
              <button
                onClick={toggleNoiseCancellation}
                className={`p-4 rounded-full transition-all duration-200 hover:scale-110 relative ${
                  noiseCancellationEnabled 
                    ? 'bg-cyan-500 hover:bg-cyan-600 text-white' 
                    : 'bg-gray-700 hover:bg-gray-600 text-white'
                }`}
                title={noiseCancellationEnabled ? 'Disable noise cancellation' : 'Enable noise cancellation'}
              >
                <NoiseIcon size={24} />
                {noiseCancellationEnabled && ncProcessing && (
                  <span className="absolute -top-1 -right-1 w-3 h-3 bg-cyan-300 rounded-full animate-pulse" />
                )}
              </button>

              {/* Virtual Background */}
              <VirtualBackgroundButton
                onClick={() => setIsVirtualBgPanelOpen(true)}
                isActive={virtualBgEnabled && selectedBackground.type !== 'none'}
              />

              {/* Screen Share */}
              <button
                onClick={toggleScreenShare}
                className={`p-4 rounded-full transition-all duration-200 hover:scale-110 hidden sm:block ${
                  isScreenSharing 
                    ? 'bg-green-500 hover:bg-green-600 text-white' 
                    : 'bg-gray-700 hover:bg-gray-600 text-white'
                }`}
                title={isScreenSharing ? 'Stop sharing' : 'Share screen'}
              >
                <ScreenShareIcon size={24} />
              </button>

              {/* Captions */}
              <button
                onClick={toggleCaptions}
                className={`p-4 rounded-full transition-all duration-200 hover:scale-110 ${
                  isCaptionsEnabled 
                    ? 'bg-purple-500 hover:bg-purple-600 text-white' 
                    : 'bg-gray-700 hover:bg-gray-600 text-white'
                }`}
                title={isCaptionsEnabled ? 'Disable captions' : 'Enable captions'}
              >
                <CaptionsIcon size={24} />
              </button>

              {/* Reactions Button */}
              <ReactionButton
                onSelectReaction={sendReaction}
                isPickerOpen={isPickerOpen}
                setIsPickerOpen={setIsPickerOpen}
              />

              {/* Chat */}
              <button
                onClick={toggleChat}
                className={`p-4 rounded-full transition-all duration-200 hover:scale-110 relative ${
                  isChatOpen 
                    ? 'bg-indigo-500 hover:bg-indigo-600 text-white' 
                    : 'bg-gray-700 hover:bg-gray-600 text-white'
                }`}
                title={isChatOpen ? 'Close chat' : 'Open chat'}
              >
                <MessageCircleIcon size={24} />
                {unreadMessages > 0 && !isChatOpen && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center font-bold">
                    {unreadMessages > 9 ? '9+' : unreadMessages}
                  </span>
                )}
              </button>

              {/* End Call */}
              <button
                onClick={endCall}
                className="p-4 bg-red-500 hover:bg-red-600 text-white rounded-full transition-all duration-200 hover:scale-110"
                title="End call"
              >
                <PhoneOffIcon size={24} />
              </button>
            </div>

            {/* Caption Status Bar */}
            {isCaptionsEnabled && (
              <div className="flex items-center justify-center gap-2 py-2 bg-purple-900/50 text-purple-200 text-sm">
                <CaptionsIcon size={16} />
                <span>Live captions enabled - Speech will be transcribed automatically</span>
              </div>
            )}
          </div>
        )}

        {/* Virtual Background Panel */}
        <VirtualBackgroundPanel
          isOpen={isVirtualBgPanelOpen}
          onClose={() => setIsVirtualBgPanelOpen(false)}
          selectedBackground={selectedBackground}
          allBackgrounds={allBackgrounds}
          customBackgrounds={customBackgrounds}
          onSelectBackground={(bg) => {
            selectBackground(bg);
            setVirtualBgEnabled(bg.type !== 'none');
          }}
          onAddCustomBackground={addCustomBackground}
          onRemoveCustomBackground={removeCustomBackground}
          isLoading={vbLoading}
          error={vbError}
        />

        {/* Info Cards */}
        {!isInCall && (
          <div className="mt-12 grid md:grid-cols-3 lg:grid-cols-6 gap-6">
            <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100">
              <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mb-4">
                <CaptionsIcon className="text-purple-600" size={24} />
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Real-Time Captions</h3>
              <p className="text-gray-600 text-sm">
                Automatic speech-to-text transcription displays at the bottom of the screen.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100">
              <div className="w-12 h-12 bg-cyan-100 rounded-xl flex items-center justify-center mb-4">
                <NoiseIcon className="text-cyan-600" size={24} />
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Noise Cancellation</h3>
              <p className="text-gray-600 text-sm">
                AI-powered audio filtering removes background noise for crystal-clear calls.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100">
              <div className="w-12 h-12 bg-indigo-100 rounded-xl flex items-center justify-center mb-4">
                <ImageIcon className="text-indigo-600" size={24} />
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Virtual Backgrounds</h3>
              <p className="text-gray-600 text-sm">
                Blur your background, use solid colors, or upload custom images.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100">
              <div className="w-12 h-12 bg-teal-100 rounded-xl flex items-center justify-center mb-4">
                <MessageCircleIcon className="text-teal-600" size={24} />
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">In-Call Chat</h3>
              <p className="text-gray-600 text-sm">
                Send text messages and share files during video calls.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100">
              <div className="w-12 h-12 bg-yellow-100 rounded-xl flex items-center justify-center mb-4">
                <SmileIcon className="text-yellow-600" size={24} />
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Emoji Reactions</h3>
              <p className="text-gray-600 text-sm">
                Send real-time emoji reactions that appear as animated overlays.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100">
              <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mb-4">
                <ShieldIcon className="text-blue-600" size={24} />
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">TURN Server</h3>
              <p className="text-gray-600 text-sm">
                Reliable connections even behind restrictive firewalls or NATs.
              </p>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default VideoCallSection;
