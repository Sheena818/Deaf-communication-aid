import React, { useState, useEffect, useRef } from 'react';
import { MicrophoneIcon, StopIcon, PlayIcon, HandsIcon, RefreshIcon } from './icons/Icons';
import { useSpeechRecognition } from '@/hooks/useSpeechRecognition';


// ASL Sign data - mapping words to their ASL representations
const aslSigns: Record<string, { description: string; handShape: string; movement: string }> = {
  'hello': { description: 'Wave hand', handShape: 'Open palm facing out', movement: 'Wave side to side near forehead' },
  'hi': { description: 'Wave hand', handShape: 'Open palm facing out', movement: 'Wave side to side near forehead' },
  'goodbye': { description: 'Wave goodbye', handShape: 'Open palm', movement: 'Wave hand back and forth' },
  'bye': { description: 'Wave goodbye', handShape: 'Open palm', movement: 'Wave hand back and forth' },
  'thank': { description: 'Thank you', handShape: 'Flat hand', movement: 'Touch chin and move forward' },
  'thanks': { description: 'Thank you', handShape: 'Flat hand', movement: 'Touch chin and move forward' },
  'please': { description: 'Please', handShape: 'Flat hand on chest', movement: 'Circular motion on chest' },
  'sorry': { description: 'Sorry', handShape: 'Fist on chest', movement: 'Circular motion' },
  'yes': { description: 'Yes', handShape: 'Fist', movement: 'Nod fist up and down' },
  'no': { description: 'No', handShape: 'Index and middle finger', movement: 'Snap together like closing' },
  'help': { description: 'Help', handShape: 'Thumbs up on flat palm', movement: 'Lift upward' },
  'i': { description: 'I/Me', handShape: 'Point to self', movement: 'Point index finger to chest' },
  'me': { description: 'I/Me', handShape: 'Point to self', movement: 'Point index finger to chest' },
  'you': { description: 'You', handShape: 'Point forward', movement: 'Point index finger outward' },
  'we': { description: 'We', handShape: 'Index finger', movement: 'Touch right shoulder, arc to left' },
  'love': { description: 'Love', handShape: 'Cross arms over chest', movement: 'Hug yourself' },
  'like': { description: 'Like', handShape: 'Thumb and middle finger', movement: 'Pull away from chest' },
  'want': { description: 'Want', handShape: 'Clawed hands', movement: 'Pull toward body' },
  'need': { description: 'Need', handShape: 'X handshape', movement: 'Bend wrist down' },
  'have': { description: 'Have', handShape: 'Bent hands', movement: 'Touch chest' },
  'eat': { description: 'Eat', handShape: 'Flat O hand', movement: 'Move to mouth repeatedly' },
  'drink': { description: 'Drink', handShape: 'C hand', movement: 'Tip toward mouth' },
  'water': { description: 'Water', handShape: 'W hand', movement: 'Tap chin twice' },
  'food': { description: 'Food', handShape: 'Flat O hand', movement: 'Tap lips' },
  'good': { description: 'Good', handShape: 'Flat hand', movement: 'Touch chin, move down to palm' },
  'bad': { description: 'Bad', handShape: 'Flat hand', movement: 'Touch chin, flip down' },
  'happy': { description: 'Happy', handShape: 'Flat hands on chest', movement: 'Brush upward repeatedly' },
  'sad': { description: 'Sad', handShape: 'Open hands on face', movement: 'Move down from eyes' },
  'tired': { description: 'Tired', handShape: 'Bent hands', movement: 'Drop from chest' },
  'sick': { description: 'Sick', handShape: 'Middle fingers', movement: 'Touch forehead and stomach' },
  'pain': { description: 'Pain/Hurt', handShape: 'Index fingers', movement: 'Twist toward each other' },
  'hurt': { description: 'Pain/Hurt', handShape: 'Index fingers', movement: 'Twist toward each other' },
  'doctor': { description: 'Doctor', handShape: 'D hand', movement: 'Tap wrist pulse point' },
  'hospital': { description: 'Hospital', handShape: 'H hand', movement: 'Draw cross on upper arm' },
  'emergency': { description: 'Emergency', handShape: 'E hand', movement: 'Shake back and forth' },
  'call': { description: 'Call/Phone', handShape: 'Y hand', movement: 'Hold to ear' },
  'phone': { description: 'Phone', handShape: 'Y hand', movement: 'Hold to ear' },
  'name': { description: 'Name', handShape: 'H hands', movement: 'Tap together twice' },
  'what': { description: 'What', handShape: 'Open hands', movement: 'Shake side to side' },
  'where': { description: 'Where', handShape: 'Index finger', movement: 'Shake side to side' },
  'when': { description: 'When', handShape: 'Index fingers', movement: 'Circle around each other' },
  'why': { description: 'Why', handShape: 'Y hand', movement: 'Touch forehead, pull away' },
  'how': { description: 'How', handShape: 'Bent hands', movement: 'Knuckles together, roll forward' },
  'who': { description: 'Who', handShape: 'L hand', movement: 'Circle around lips' },
  'can': { description: 'Can/Able', handShape: 'S hands', movement: 'Move down together' },
  'understand': { description: 'Understand', handShape: 'Index finger', movement: 'Flick up near forehead' },
  'know': { description: 'Know', handShape: 'Flat hand', movement: 'Tap forehead' },
  'learn': { description: 'Learn', handShape: 'Flat hand to fist', movement: 'Pull from palm to forehead' },
  'teach': { description: 'Teach', handShape: 'Flat O hands', movement: 'Move forward from temples' },
  'sign': { description: 'Sign language', handShape: 'Index fingers', movement: 'Alternate circular motion' },
  'language': { description: 'Language', handShape: 'L hands', movement: 'Move apart from center' },
  'deaf': { description: 'Deaf', handShape: 'Index finger', movement: 'Touch ear, then mouth' },
  'hearing': { description: 'Hearing', handShape: 'Index finger', movement: 'Circle near ear' },
  'speak': { description: 'Speak', handShape: 'Index finger', movement: 'Move forward from mouth' },
  'talk': { description: 'Talk', handShape: 'Index finger', movement: 'Move forward from mouth' },
  'listen': { description: 'Listen', handShape: 'Cupped hand', movement: 'Cup behind ear' },
  'see': { description: 'See', handShape: 'V hand', movement: 'Move forward from eyes' },
  'look': { description: 'Look', handShape: 'V hand', movement: 'Move forward from eyes' },
  'wait': { description: 'Wait', handShape: 'Open hands', movement: 'Wiggle fingers' },
  'stop': { description: 'Stop', handShape: 'Flat hand', movement: 'Chop into palm' },
  'go': { description: 'Go', handShape: 'Index fingers', movement: 'Point and move forward' },
  'come': { description: 'Come', handShape: 'Index fingers', movement: 'Beckon toward self' },
  'home': { description: 'Home', handShape: 'Flat O hand', movement: 'Touch cheek, then near ear' },
  'work': { description: 'Work', handShape: 'S hands', movement: 'Tap wrist with fist' },
  'school': { description: 'School', handShape: 'Flat hands', movement: 'Clap twice' },
  'friend': { description: 'Friend', handShape: 'Index fingers hooked', movement: 'Link and reverse' },
  'family': { description: 'Family', handShape: 'F hands', movement: 'Circle forward' },
  'mother': { description: 'Mother', handShape: 'Open 5 hand', movement: 'Thumb on chin' },
  'father': { description: 'Father', handShape: 'Open 5 hand', movement: 'Thumb on forehead' },
  'child': { description: 'Child', handShape: 'Flat hand', movement: 'Pat downward' },
  'baby': { description: 'Baby', handShape: 'Cradled arms', movement: 'Rock side to side' },
  'man': { description: 'Man', handShape: 'Flat hand', movement: 'Touch forehead, then chest' },
  'woman': { description: 'Woman', handShape: 'Flat hand', movement: 'Touch chin, then chest' },
  'person': { description: 'Person', handShape: 'P hands', movement: 'Move down parallel' },
  'people': { description: 'People', handShape: 'P hands', movement: 'Alternate circles' },
  'today': { description: 'Today', handShape: 'Y hands', movement: 'Drop down' },
  'tomorrow': { description: 'Tomorrow', handShape: 'A hand', movement: 'Thumb forward from cheek' },
  'yesterday': { description: 'Yesterday', handShape: 'A hand', movement: 'Thumb back to cheek' },
  'now': { description: 'Now', handShape: 'Y hands', movement: 'Drop down sharply' },
  'later': { description: 'Later', handShape: 'L hand', movement: 'Twist forward' },
  'time': { description: 'Time', handShape: 'Index finger', movement: 'Tap wrist' },
  'day': { description: 'Day', handShape: 'D hand', movement: 'Arc across body' },
  'night': { description: 'Night', handShape: 'Bent hand', movement: 'Tap wrist, drop down' },
  'morning': { description: 'Morning', handShape: 'Flat hand', movement: 'Rise from elbow' },
  'afternoon': { description: 'Afternoon', handShape: 'Flat hand', movement: 'Tilt forward from elbow' },
  'evening': { description: 'Evening', handShape: 'Flat hand', movement: 'Drop onto wrist' },
};

// ASL Fingerspelling alphabet
const fingerspellingAlphabet: Record<string, string> = {
  'a': 'Fist with thumb on side',
  'b': 'Flat hand, fingers together, thumb tucked',
  'c': 'Curved hand like holding a ball',
  'd': 'Index up, thumb touches middle finger',
  'e': 'Fingers curled, thumb tucked under',
  'f': 'Circle with thumb and index, other fingers up',
  'g': 'Index and thumb pointing sideways',
  'h': 'Index and middle finger pointing sideways',
  'i': 'Pinky up, other fingers in fist',
  'j': 'Pinky up, trace J shape',
  'k': 'Index and middle up, thumb between',
  'l': 'L shape with index and thumb',
  'm': 'Three fingers over thumb',
  'n': 'Two fingers over thumb',
  'o': 'Fingers curved to touch thumb',
  'p': 'K hand pointing down',
  'q': 'G hand pointing down',
  'r': 'Index and middle crossed',
  's': 'Fist with thumb over fingers',
  't': 'Thumb between index and middle',
  'u': 'Index and middle together, pointing up',
  'v': 'Index and middle apart, pointing up',
  'w': 'Index, middle, ring apart, pointing up',
  'x': 'Index finger hooked',
  'y': 'Thumb and pinky out, other fingers in',
  'z': 'Index finger traces Z shape',
};

interface TranslatedWord {
  word: string;
  sign: typeof aslSigns[string] | null;
  isSpelled: boolean;
}

const ASLTranslator: React.FC = () => {
  const [inputText, setInputText] = useState('');
  const [translatedWords, setTranslatedWords] = useState<TranslatedWord[]>([]);
  const [currentWordIndex, setCurrentWordIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [showFingerspelling, setShowFingerspelling] = useState(false);
  const playIntervalRef = useRef<NodeJS.Timeout | null>(null);

  const {
    isListening,
    transcript,
    startListening,
    stopListening,
    isSupported,
  } = useSpeechRecognition();

  // Update input when speech is recognized
  useEffect(() => {
    if (transcript) {
      setInputText(transcript);
    }
  }, [transcript]);

  // Translate text to ASL
  const translateToASL = () => {
    const words = inputText.toLowerCase().trim().split(/\s+/).filter(w => w);
    const translated: TranslatedWord[] = words.map(word => {
      // Remove punctuation
      const cleanWord = word.replace(/[^a-z]/g, '');
      const sign = aslSigns[cleanWord];
      return {
        word: cleanWord,
        sign: sign || null,
        isSpelled: !sign,
      };
    });
    setTranslatedWords(translated);
    setCurrentWordIndex(0);
    setIsPlaying(false);
  };

  // Play through signs
  const playTranslation = () => {
    if (translatedWords.length === 0) return;
    
    setIsPlaying(true);
    setCurrentWordIndex(0);
    
    playIntervalRef.current = setInterval(() => {
      setCurrentWordIndex(prev => {
        if (prev >= translatedWords.length - 1) {
          setIsPlaying(false);
          if (playIntervalRef.current) {
            clearInterval(playIntervalRef.current);
          }
          return prev;
        }
        return prev + 1;
      });
    }, 2000);
  };

  const stopPlaying = () => {
    setIsPlaying(false);
    if (playIntervalRef.current) {
      clearInterval(playIntervalRef.current);
    }
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (playIntervalRef.current) {
        clearInterval(playIntervalRef.current);
      }
    };
  }, []);

  const handleMicrophoneClick = () => {
    if (isListening) {
      stopListening();
    } else {
      startListening();
    }
  };

  const currentWord = translatedWords[currentWordIndex];

  return (
    <section id="asl-translator" className="py-16 bg-gradient-to-br from-purple-50 to-indigo-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-purple-100 rounded-full text-purple-700 font-medium text-sm mb-4">
            <HandsIcon size={18} />
            Speech to ASL Translation
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            Translate Speech to <span className="text-purple-600">Sign Language</span>
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Speak or type text and see how to sign it in American Sign Language. 
            Perfect for learning ASL or communicating with deaf individuals.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Input Section */}
          <div className="bg-white rounded-2xl shadow-xl p-6">
            <h3 className="text-xl font-bold text-gray-800 mb-4">Input Text or Speech</h3>
            
            {/* Text Input */}
            <div className="mb-4">
              <textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="Type or speak something to translate..."
                className="w-full h-32 p-4 border border-gray-200 rounded-xl resize-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
              />
            </div>

            {/* Controls */}
            <div className="flex flex-wrap gap-3">
              {isSupported && (
                <button
                  onClick={handleMicrophoneClick}
                  className={`flex items-center gap-2 px-4 py-3 rounded-xl font-semibold transition-all duration-200 ${
                    isListening
                      ? 'bg-red-500 text-white animate-pulse'
                      : 'bg-purple-100 text-purple-700 hover:bg-purple-200'
                  }`}
                >
                  {isListening ? <StopIcon size={20} /> : <MicrophoneIcon size={20} />}
                  {isListening ? 'Stop' : 'Speak'}
                </button>
              )}
              
              <button
                onClick={translateToASL}
                disabled={!inputText.trim()}
                className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-xl font-semibold hover:shadow-lg transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <HandsIcon size={20} />
                Translate to ASL
              </button>
            </div>

            {isListening && (
              <div className="mt-4 p-3 bg-purple-50 rounded-lg">
                <div className="flex items-center gap-2 text-purple-700">
                  <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse" />
                  <span className="text-sm font-medium">Listening... Speak now</span>
                </div>
              </div>
            )}
          </div>

          {/* Output Section */}
          <div className="bg-white rounded-2xl shadow-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold text-gray-800">ASL Translation</h3>
              {translatedWords.length > 0 && (
                <div className="flex gap-2">
                  <button
                    onClick={isPlaying ? stopPlaying : playTranslation}
                    className={`flex items-center gap-2 px-3 py-2 rounded-lg font-medium transition-all ${
                      isPlaying
                        ? 'bg-red-100 text-red-700'
                        : 'bg-purple-100 text-purple-700 hover:bg-purple-200'
                    }`}
                  >
                    {isPlaying ? <StopIcon size={18} /> : <PlayIcon size={18} />}
                    {isPlaying ? 'Stop' : 'Play'}
                  </button>
                  <button
                    onClick={() => {
                      setTranslatedWords([]);
                      setInputText('');
                    }}
                    className="p-2 rounded-lg bg-gray-100 text-gray-600 hover:bg-gray-200 transition-all"
                  >
                    <RefreshIcon size={18} />
                  </button>
                </div>
              )}
            </div>

            {translatedWords.length === 0 ? (
              <div className="h-64 flex items-center justify-center text-gray-400">
                <div className="text-center">
                  <HandsIcon size={48} className="mx-auto mb-3 opacity-50" />
                  <p>Enter text and click "Translate to ASL" to see the signs</p>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                {/* Current Sign Display */}
                {currentWord && (
                  <div className="p-6 bg-gradient-to-br from-purple-100 to-indigo-100 rounded-xl">
                    <div className="text-center">
                      <span className="text-4xl font-bold text-purple-800 capitalize">
                        {currentWord.word}
                      </span>
                      
                      {currentWord.sign ? (
                        <div className="mt-4 space-y-2">
                          <div className="inline-flex items-center gap-2 px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm font-medium">
                            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                              <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                            </svg>
                            Known ASL Sign
                          </div>
                          <p className="text-lg text-purple-700 font-medium">{currentWord.sign.description}</p>
                          <div className="grid grid-cols-2 gap-4 mt-4 text-left">
                            <div className="p-3 bg-white/60 rounded-lg">
                              <p className="text-xs text-purple-600 font-semibold uppercase">Hand Shape</p>
                              <p className="text-sm text-gray-700">{currentWord.sign.handShape}</p>
                            </div>
                            <div className="p-3 bg-white/60 rounded-lg">
                              <p className="text-xs text-purple-600 font-semibold uppercase">Movement</p>
                              <p className="text-sm text-gray-700">{currentWord.sign.movement}</p>
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div className="mt-4">
                          <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-100 text-amber-700 rounded-full text-sm font-medium mb-3">
                            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                              <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                            </svg>
                            Fingerspell This Word
                          </div>
                          <div className="flex flex-wrap justify-center gap-2">
                            {currentWord.word.split('').map((letter, idx) => (
                              <div key={idx} className="w-10 h-10 bg-white rounded-lg flex items-center justify-center shadow-sm">
                                <span className="text-lg font-bold text-purple-700 uppercase">{letter}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Word Progress */}
                <div className="flex flex-wrap gap-2">
                  {translatedWords.map((tw, idx) => (
                    <button
                      key={idx}
                      onClick={() => setCurrentWordIndex(idx)}
                      className={`px-3 py-1 rounded-full text-sm font-medium transition-all ${
                        idx === currentWordIndex
                          ? 'bg-purple-600 text-white'
                          : tw.sign
                          ? 'bg-green-100 text-green-700 hover:bg-green-200'
                          : 'bg-amber-100 text-amber-700 hover:bg-amber-200'
                      }`}
                    >
                      {tw.word}
                    </button>
                  ))}
                </div>

                {/* Progress Bar */}
                {isPlaying && (
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-purple-600 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${((currentWordIndex + 1) / translatedWords.length) * 100}%` }}
                    />
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Fingerspelling Reference */}
        <div className="mt-8">
          <button
            onClick={() => setShowFingerspelling(!showFingerspelling)}
            className="flex items-center gap-2 mx-auto px-6 py-3 bg-white rounded-xl shadow-md hover:shadow-lg transition-all font-semibold text-gray-700"
          >
            <HandsIcon size={20} />
            {showFingerspelling ? 'Hide' : 'Show'} Fingerspelling Alphabet
          </button>

          {showFingerspelling && (
            <div className="mt-6 bg-white rounded-2xl shadow-xl p-6 animate-in fade-in slide-in-from-top-4 duration-300">
              <h3 className="text-xl font-bold text-gray-800 mb-4 text-center">ASL Fingerspelling Alphabet</h3>
              <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-9 gap-3">
                {Object.entries(fingerspellingAlphabet).map(([letter, description]) => (
                  <div
                    key={letter}
                    className="p-3 bg-gradient-to-br from-purple-50 to-indigo-50 rounded-xl text-center hover:shadow-md transition-all group cursor-pointer"
                  >
                    <span className="text-2xl font-bold text-purple-700 uppercase">{letter}</span>
                    <p className="text-xs text-gray-600 mt-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      {description}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Tips Section */}
        <div className="mt-8 grid sm:grid-cols-3 gap-4">
          <div className="bg-white rounded-xl p-4 shadow-md">
            <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center mb-3">
              <svg className="w-5 h-5 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <h4 className="font-semibold text-gray-800 mb-1">Known Signs</h4>
            <p className="text-sm text-gray-600">Green words have specific ASL signs. Follow the hand shape and movement instructions.</p>
          </div>
          <div className="bg-white rounded-xl p-4 shadow-md">
            <div className="w-10 h-10 bg-amber-100 rounded-lg flex items-center justify-center mb-3">
              <svg className="w-5 h-5 text-amber-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 8h10M7 12h4m1 8l-4-4H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-3l-4 4z" />
              </svg>
            </div>
            <h4 className="font-semibold text-gray-800 mb-1">Fingerspelling</h4>
            <p className="text-sm text-gray-600">Amber words should be fingerspelled letter by letter using the ASL alphabet.</p>
          </div>
          <div className="bg-white rounded-xl p-4 shadow-md">
            <div className="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center mb-3">
              <svg className="w-5 h-5 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <h4 className="font-semibold text-gray-800 mb-1">Playback</h4>
            <p className="text-sm text-gray-600">Use the Play button to automatically cycle through each word in your translation.</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ASLTranslator;
