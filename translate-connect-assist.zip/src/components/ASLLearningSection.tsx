import React, { useState } from 'react';
import { HandsIcon, PlayIcon, CheckIcon } from './icons/Icons';

const aslAlphabet = [
  { letter: 'A', image: 'https://d64gsuwffb70l.cloudfront.net/6945ed0ba05f1477c272f404_1766190451637_51712906.jpg', description: 'Make a fist with thumb on the side' },
  { letter: 'B', image: 'https://d64gsuwffb70l.cloudfront.net/6945ed0ba05f1477c272f404_1766190453430_64721c8e.jpg', description: 'Flat hand with thumb tucked' },
  { letter: 'C', image: 'https://d64gsuwffb70l.cloudfront.net/6945ed0ba05f1477c272f404_1766190455828_1848ea75.png', description: 'Curved hand like holding a cup' },
  { letter: 'D', image: 'https://d64gsuwffb70l.cloudfront.net/6945ed0ba05f1477c272f404_1766190456177_b9521ca7.png', description: 'Index finger up, others curled' },
];

const commonSigns = [
  { word: 'Hello', description: 'Wave your hand or salute from forehead', difficulty: 'Easy' },
  { word: 'Thank You', description: 'Touch chin with fingertips and move hand forward', difficulty: 'Easy' },
  { word: 'Please', description: 'Rub flat hand in circle on chest', difficulty: 'Easy' },
  { word: 'Sorry', description: 'Make a fist and rub in circle on chest', difficulty: 'Easy' },
  { word: 'Yes', description: 'Make a fist and nod it like a head nodding', difficulty: 'Easy' },
  { word: 'No', description: 'Extend index and middle finger, snap them to thumb', difficulty: 'Easy' },
  { word: 'Help', description: 'Place fist on open palm and raise both hands', difficulty: 'Medium' },
  { word: 'Water', description: 'Make W with 3 fingers and tap chin', difficulty: 'Medium' },
  { word: 'Food', description: 'Bring bunched fingertips to mouth', difficulty: 'Easy' },
  { word: 'Bathroom', description: 'Make T sign and shake it', difficulty: 'Medium' },
  { word: 'Friend', description: 'Hook index fingers together twice', difficulty: 'Medium' },
  { word: 'Love', description: 'Cross arms over chest like hugging', difficulty: 'Easy' },
];

const ASLLearningSection: React.FC = () => {
  const [selectedLetter, setSelectedLetter] = useState<string | null>(null);
  const [learnedSigns, setLearnedSigns] = useState<string[]>([]);

  const toggleLearned = (word: string) => {
    setLearnedSigns(prev =>
      prev.includes(word) ? prev.filter(w => w !== word) : [...prev, word]
    );
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Easy': return 'bg-green-100 text-green-700';
      case 'Medium': return 'bg-yellow-100 text-yellow-700';
      case 'Hard': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <section id="learn" className="py-12 sm:py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#00bfa5]/10 text-[#00bfa5] rounded-full mb-4">
            <HandsIcon size={18} />
            <span className="font-medium">Learn Sign Language</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-[#1a2332] mb-4">
            ASL Basics & Fingerspelling
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Start your journey into American Sign Language. Learn the alphabet 
            and essential signs to enhance your communication skills.
          </p>
        </div>

        {/* Progress Bar */}
        <div className="max-w-md mx-auto mb-12">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-gray-600">Your Progress</span>
            <span className="text-sm font-bold text-[#00bfa5]">
              {learnedSigns.length}/{commonSigns.length} signs learned
            </span>
          </div>
          <div className="h-3 bg-gray-200 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-[#00bfa5] to-[#4dd0e1] transition-all duration-500"
              style={{ width: `${(learnedSigns.length / commonSigns.length) * 100}%` }}
            />
          </div>
        </div>

        {/* ASL Alphabet */}
        <div className="mb-16">
          <h3 className="text-2xl font-bold text-[#1a2332] mb-6 text-center">
            Fingerspelling Alphabet
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 sm:gap-6">
            {aslAlphabet.map((item) => (
              <button
                key={item.letter}
                onClick={() => setSelectedLetter(selectedLetter === item.letter ? null : item.letter)}
                className={`group relative rounded-2xl overflow-hidden transition-all duration-300 ${
                  selectedLetter === item.letter
                    ? 'ring-4 ring-[#00bfa5] scale-105'
                    : 'hover:scale-105'
                }`}
              >
                <img
                  src={item.image}
                  alt={`ASL letter ${item.letter}`}
                  className="w-full aspect-square object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-4">
                  <div className="text-4xl font-bold text-white mb-1">{item.letter}</div>
                  <p className="text-sm text-white/80 line-clamp-2">{item.description}</p>
                </div>
                <div className="absolute top-3 right-3 w-8 h-8 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <PlayIcon size={16} className="text-white" />
                </div>
              </button>
            ))}
          </div>
          <p className="text-center text-gray-500 mt-4 text-sm">
            Click on any letter to see the full hand position
          </p>
        </div>

        {/* Common Signs */}
        <div>
          <h3 className="text-2xl font-bold text-[#1a2332] mb-6 text-center">
            Essential Signs to Know
          </h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {commonSigns.map((sign) => (
              <div
                key={sign.word}
                className={`relative p-5 rounded-2xl border-2 transition-all duration-200 ${
                  learnedSigns.includes(sign.word)
                    ? 'bg-[#00bfa5]/5 border-[#00bfa5]'
                    : 'bg-white border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h4 className="text-xl font-bold text-[#1a2332]">{sign.word}</h4>
                    <span className={`inline-block px-2 py-0.5 rounded-full text-xs font-medium mt-1 ${getDifficultyColor(sign.difficulty)}`}>
                      {sign.difficulty}
                    </span>
                  </div>
                  <button
                    onClick={() => toggleLearned(sign.word)}
                    className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${
                      learnedSigns.includes(sign.word)
                        ? 'bg-[#00bfa5] text-white'
                        : 'bg-gray-100 text-gray-400 hover:bg-gray-200'
                    }`}
                    aria-label={learnedSigns.includes(sign.word) ? 'Mark as not learned' : 'Mark as learned'}
                  >
                    <CheckIcon size={16} />
                  </button>
                </div>
                <p className="text-gray-600 text-sm leading-relaxed">{sign.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Community Banner */}
        <div className="mt-16">
          <div className="relative rounded-3xl overflow-hidden">
            <img
              src="https://d64gsuwffb70l.cloudfront.net/6945ed0ba05f1477c272f404_1766190499001_446fe0b7.png"
              alt="Diverse community communicating"
              className="w-full h-64 sm:h-80 object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-[#1a2332]/90 to-[#1a2332]/60" />
            <div className="absolute inset-0 flex items-center">
              <div className="px-8 sm:px-12 max-w-2xl">
                <h3 className="text-2xl sm:text-3xl font-bold text-white mb-4">
                  Join Our Learning Community
                </h3>
                <p className="text-gray-300 mb-6">
                  Connect with others learning ASL, practice with native signers, 
                  and access exclusive video tutorials and resources.
                </p>
                <div className="flex flex-wrap gap-3">
                  <button className="px-6 py-3 bg-[#00bfa5] hover:bg-[#00a08a] text-white rounded-xl font-semibold transition-colors">
                    Join Free Community
                  </button>
                  <button className="px-6 py-3 bg-white/10 hover:bg-white/20 text-white rounded-xl font-semibold transition-colors">
                    Watch Tutorials
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ASLLearningSection;
