import React, { useState, useRef, useCallback } from 'react';
import { BackgroundOption, DEFAULT_BACKGROUNDS } from '@/hooks/useVirtualBackground';

// Icons
const XIcon: React.FC<{ size?: number; className?: string }> = ({ size = 24, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <line x1="18" y1="6" x2="6" y2="18" />
    <line x1="6" y1="6" x2="18" y2="18" />
  </svg>
);

const UploadIcon: React.FC<{ size?: number; className?: string }> = ({ size = 24, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
    <polyline points="17 8 12 3 7 8" />
    <line x1="12" y1="3" x2="12" y2="15" />
  </svg>
);

const TrashIcon: React.FC<{ size?: number; className?: string }> = ({ size = 24, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <polyline points="3 6 5 6 21 6" />
    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
  </svg>
);

const CheckIcon: React.FC<{ size?: number; className?: string }> = ({ size = 24, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <polyline points="20 6 9 17 4 12" />
  </svg>
);

const BlurIcon: React.FC<{ size?: number; className?: string }> = ({ size = 24, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <circle cx="12" cy="12" r="3" />
    <circle cx="12" cy="12" r="6" opacity="0.5" />
    <circle cx="12" cy="12" r="9" opacity="0.25" />
  </svg>
);

const ImageIcon: React.FC<{ size?: number; className?: string }> = ({ size = 24, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <rect x="3" y="3" width="18" height="18" rx="2" ry="2" />
    <circle cx="8.5" cy="8.5" r="1.5" />
    <polyline points="21 15 16 10 5 21" />
  </svg>
);

const BanIcon: React.FC<{ size?: number; className?: string }> = ({ size = 24, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <circle cx="12" cy="12" r="10" />
    <line x1="4.93" y1="4.93" x2="19.07" y2="19.07" />
  </svg>
);

interface VirtualBackgroundPanelProps {
  isOpen: boolean;
  onClose: () => void;
  selectedBackground: BackgroundOption;
  allBackgrounds: BackgroundOption[];
  customBackgrounds: BackgroundOption[];
  onSelectBackground: (background: BackgroundOption) => void;
  onAddCustomBackground: (imageUrl: string, name: string) => BackgroundOption;
  onRemoveCustomBackground: (id: string) => void;
  isLoading: boolean;
  error: string | null;
}

const VirtualBackgroundPanel: React.FC<VirtualBackgroundPanelProps> = ({
  isOpen,
  onClose,
  selectedBackground,
  allBackgrounds,
  customBackgrounds,
  onSelectBackground,
  onAddCustomBackground,
  onRemoveCustomBackground,
  isLoading,
  error,
}) => {
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Filter backgrounds by type
  const noneOption = allBackgrounds.find(b => b.type === 'none');
  const blurOptions = allBackgrounds.filter(b => b.type === 'blur');
  const colorOptions = allBackgrounds.filter(b => b.type === 'color');
  const imageOptions = allBackgrounds.filter(b => b.type === 'image' && !b.id.startsWith('custom-'));

  // Handle file upload
  const handleFileUpload = useCallback(async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      setUploadError('Please select an image file');
      return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      setUploadError('Image must be less than 5MB');
      return;
    }

    setIsUploading(true);
    setUploadError(null);

    try {
      // Convert to base64 for local storage
      const reader = new FileReader();
      reader.onload = () => {
        const dataUrl = reader.result as string;
        const name = file.name.replace(/\.[^/.]+$/, ''); // Remove extension
        const newBackground = onAddCustomBackground(dataUrl, name);
        onSelectBackground(newBackground);
        setIsUploading(false);
      };
      reader.onerror = () => {
        setUploadError('Failed to read image file');
        setIsUploading(false);
      };
      reader.readAsDataURL(file);
    } catch (err) {
      setUploadError('Failed to upload image');
      setIsUploading(false);
    }

    // Reset input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  }, [onAddCustomBackground, onSelectBackground]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200">
          <div>
            <h2 className="text-xl font-bold text-gray-900">Virtual Background</h2>
            <p className="text-sm text-gray-500 mt-0.5">Choose a background for your video</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <XIcon size={20} className="text-gray-500" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[calc(90vh-140px)]">
          {/* Loading/Error States */}
          {isLoading && (
            <div className="mb-4 p-4 bg-blue-50 border border-blue-200 rounded-xl">
              <div className="flex items-center gap-3">
                <div className="w-5 h-5 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
                <p className="text-blue-700 font-medium">Loading background model...</p>
              </div>
            </div>
          )}

          {error && (
            <div className="mb-4 p-4 bg-yellow-50 border border-yellow-200 rounded-xl">
              <p className="text-yellow-700">{error}</p>
            </div>
          )}

          {/* No Background Option */}
          <div className="mb-6">
            <h3 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
              <BanIcon size={16} />
              No Effect
            </h3>
            {noneOption && (
              <button
                onClick={() => onSelectBackground(noneOption)}
                className={`relative w-20 h-14 rounded-lg border-2 transition-all overflow-hidden ${
                  selectedBackground.id === noneOption.id
                    ? 'border-purple-500 ring-2 ring-purple-200'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="w-full h-full bg-gray-100 flex items-center justify-center">
                  <BanIcon size={20} className="text-gray-400" />
                </div>
                {selectedBackground.id === noneOption.id && (
                  <div className="absolute top-1 right-1 w-4 h-4 bg-purple-500 rounded-full flex items-center justify-center">
                    <CheckIcon size={10} className="text-white" />
                  </div>
                )}
              </button>
            )}
          </div>

          {/* Blur Options */}
          <div className="mb-6">
            <h3 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
              <BlurIcon size={16} />
              Background Blur
            </h3>
            <div className="flex flex-wrap gap-3">
              {blurOptions.map((option) => (
                <button
                  key={option.id}
                  onClick={() => onSelectBackground(option)}
                  className={`relative w-20 h-14 rounded-lg border-2 transition-all overflow-hidden ${
                    selectedBackground.id === option.id
                      ? 'border-purple-500 ring-2 ring-purple-200'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div 
                    className="w-full h-full bg-gradient-to-br from-purple-200 to-indigo-200 flex items-center justify-center"
                    style={{ filter: `blur(${parseInt(option.value || '10') / 4}px)` }}
                  />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-xs font-medium text-gray-700 bg-white/80 px-2 py-0.5 rounded">
                      {option.name}
                    </span>
                  </div>
                  {selectedBackground.id === option.id && (
                    <div className="absolute top-1 right-1 w-4 h-4 bg-purple-500 rounded-full flex items-center justify-center">
                      <CheckIcon size={10} className="text-white" />
                    </div>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Color Options */}
          <div className="mb-6">
            <h3 className="text-sm font-semibold text-gray-700 mb-3">Solid Colors</h3>
            <div className="flex flex-wrap gap-3">
              {colorOptions.map((option) => (
                <button
                  key={option.id}
                  onClick={() => onSelectBackground(option)}
                  className={`relative w-12 h-12 rounded-lg border-2 transition-all ${
                    selectedBackground.id === option.id
                      ? 'border-purple-500 ring-2 ring-purple-200'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                  style={{ backgroundColor: option.value }}
                  title={option.name}
                >
                  {selectedBackground.id === option.id && (
                    <div className="absolute top-1 right-1 w-4 h-4 bg-white rounded-full flex items-center justify-center shadow">
                      <CheckIcon size={10} className="text-purple-500" />
                    </div>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Image Backgrounds */}
          <div className="mb-6">
            <h3 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
              <ImageIcon size={16} />
              Image Backgrounds
            </h3>
            <div className="grid grid-cols-4 gap-3">
              {imageOptions.map((option) => (
                <button
                  key={option.id}
                  onClick={() => onSelectBackground(option)}
                  className={`relative aspect-video rounded-lg border-2 transition-all overflow-hidden ${
                    selectedBackground.id === option.id
                      ? 'border-purple-500 ring-2 ring-purple-200'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <img
                    src={option.thumbnail || option.value}
                    alt={option.name}
                    className="w-full h-full object-cover"
                  />
                  {selectedBackground.id === option.id && (
                    <div className="absolute top-1 right-1 w-5 h-5 bg-purple-500 rounded-full flex items-center justify-center">
                      <CheckIcon size={12} className="text-white" />
                    </div>
                  )}
                  <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-1">
                    <span className="text-xs text-white truncate block">{option.name}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Custom Backgrounds */}
          <div>
            <h3 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
              <UploadIcon size={16} />
              Custom Backgrounds
            </h3>

            {uploadError && (
              <div className="mb-3 p-3 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-sm text-red-600">{uploadError}</p>
              </div>
            )}

            <div className="grid grid-cols-4 gap-3">
              {/* Upload Button */}
              <button
                onClick={() => fileInputRef.current?.click()}
                disabled={isUploading}
                className="aspect-video rounded-lg border-2 border-dashed border-gray-300 hover:border-purple-400 hover:bg-purple-50 transition-all flex flex-col items-center justify-center gap-1 disabled:opacity-50"
              >
                {isUploading ? (
                  <div className="w-6 h-6 border-2 border-purple-500 border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    <UploadIcon size={20} className="text-gray-400" />
                    <span className="text-xs text-gray-500">Upload</span>
                  </>
                )}
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileUpload}
                className="hidden"
              />

              {/* Custom Background Items */}
              {customBackgrounds.map((option) => (
                <div
                  key={option.id}
                  className={`relative aspect-video rounded-lg border-2 transition-all overflow-hidden group ${
                    selectedBackground.id === option.id
                      ? 'border-purple-500 ring-2 ring-purple-200'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <button
                    onClick={() => onSelectBackground(option)}
                    className="w-full h-full"
                  >
                    <img
                      src={option.thumbnail || option.value}
                      alt={option.name}
                      className="w-full h-full object-cover"
                    />
                  </button>
                  
                  {/* Delete button */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onRemoveCustomBackground(option.id);
                    }}
                    className="absolute top-1 left-1 w-6 h-6 bg-red-500 hover:bg-red-600 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <TrashIcon size={12} className="text-white" />
                  </button>

                  {selectedBackground.id === option.id && (
                    <div className="absolute top-1 right-1 w-5 h-5 bg-purple-500 rounded-full flex items-center justify-center">
                      <CheckIcon size={12} className="text-white" />
                    </div>
                  )}
                  
                  <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-1">
                    <span className="text-xs text-white truncate block">{option.name}</span>
                  </div>
                </div>
              ))}
            </div>

            {customBackgrounds.length === 0 && (
              <p className="text-sm text-gray-500 mt-2">
                Upload your own images to use as virtual backgrounds
              </p>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-gray-200 bg-gray-50">
          <div className="flex items-center justify-between">
            <p className="text-sm text-gray-500">
              Selected: <span className="font-medium text-gray-700">{selectedBackground.name}</span>
            </p>
            <button
              onClick={onClose}
              className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg font-medium transition-colors"
            >
              Done
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// Virtual Background Button for call controls
interface VirtualBackgroundButtonProps {
  onClick: () => void;
  isActive: boolean;
}

export const VirtualBackgroundButton: React.FC<VirtualBackgroundButtonProps> = ({
  onClick,
  isActive,
}) => {
  return (
    <button
      onClick={onClick}
      className={`p-4 rounded-full transition-all duration-200 hover:scale-110 ${
        isActive
          ? 'bg-purple-500 hover:bg-purple-600 text-white'
          : 'bg-gray-700 hover:bg-gray-600 text-white'
      }`}
      title="Virtual Background"
    >
      <svg width={24} height={24} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <rect x="3" y="3" width="18" height="18" rx="2" ry="2" />
        <circle cx="8.5" cy="8.5" r="1.5" />
        <polyline points="21 15 16 10 5 21" />
      </svg>
    </button>
  );
};

export default VirtualBackgroundPanel;
