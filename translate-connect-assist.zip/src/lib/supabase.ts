import { createClient } from '@supabase/supabase-js';


// Initialize database client
const supabaseUrl = 'https://wuwbqqskjguxehbhoksb.databasepad.com';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImQ1OTliZDNjLWJjODMtNGJiZS1hMWE1LWRhNmE4OGM1OGI4YiJ9.eyJwcm9qZWN0SWQiOiJ3dXdicXFza2pndXhlaGJob2tzYiIsInJvbGUiOiJhbm9uIiwiaWF0IjoxNzY2MTkwMzY2LCJleHAiOjIwODE1NTAzNjYsImlzcyI6ImZhbW91cy5kYXRhYmFzZXBhZCIsImF1ZCI6ImZhbW91cy5jbGllbnRzIn0.hzz6nj1pjLWBdD9AhxiWveFGN_vGZoZILNW0SC_rDzM';
const supabase = createClient(supabaseUrl, supabaseKey);


export { supabase };