import { supabase } from './supabase';
import { Settings, EmergencyContact, Message } from '@/types';

// Types for database records
export interface DbUser {
  id: string;
  email: string | null;
  display_name: string | null;
  settings: Settings;
  created_at: string;
  updated_at: string;
}

export interface DbCustomPhrase {
  id: string;
  user_id: string;
  text: string;
  category: string;
  usage_count: number;
  created_at: string;
  updated_at: string;
}

export interface DbEmergencyContact {
  id: string;
  user_id: string;
  name: string;
  phone: string;
  relationship: string | null;
  is_primary: boolean;
  created_at: string;
  updated_at: string;
}

export interface DbConversation {
  id: string;
  user_id: string;
  text: string;
  sender: 'user' | 'other';
  message_type: 'speech' | 'text' | 'phrase';
  created_at: string;
}

// User operations
export const userService = {
  async getOrCreateUser(userId: string): Promise<DbUser | null> {
    // Try to get existing user
    const { data: existingUser, error: fetchError } = await supabase
      .from('users')
      .select('*')
      .eq('id', userId)
      .single();

    if (existingUser) {
      return existingUser as DbUser;
    }

    // Create new user if doesn't exist
    const { data: newUser, error: createError } = await supabase
      .from('users')
      .insert([{ id: userId }])
      .select()
      .single();

    if (createError) {
      console.error('Error creating user:', createError);
      return null;
    }

    return newUser as DbUser;
  },

  async updateSettings(userId: string, settings: Settings): Promise<boolean> {
    const { error } = await supabase
      .from('users')
      .update({ settings, updated_at: new Date().toISOString() })
      .eq('id', userId);

    if (error) {
      console.error('Error updating settings:', error);
      return false;
    }
    return true;
  },

  async getSettings(userId: string): Promise<Settings | null> {
    const { data, error } = await supabase
      .from('users')
      .select('settings')
      .eq('id', userId)
      .single();

    if (error) {
      console.error('Error fetching settings:', error);
      return null;
    }
    return data?.settings as Settings;
  },
};

// Custom phrases operations
export const phrasesService = {
  async getAll(userId: string): Promise<DbCustomPhrase[]> {
    const { data, error } = await supabase
      .from('custom_phrases')
      .select('*')
      .eq('user_id', userId)
      .order('usage_count', { ascending: false });

    if (error) {
      console.error('Error fetching phrases:', error);
      return [];
    }
    return data as DbCustomPhrase[];
  },

  async add(userId: string, text: string, category: string = 'Custom'): Promise<DbCustomPhrase | null> {
    const { data, error } = await supabase
      .from('custom_phrases')
      .insert([{ user_id: userId, text, category }])
      .select()
      .single();

    if (error) {
      console.error('Error adding phrase:', error);
      return null;
    }
    return data as DbCustomPhrase;
  },

  async delete(phraseId: string): Promise<boolean> {
    const { error } = await supabase
      .from('custom_phrases')
      .delete()
      .eq('id', phraseId);

    if (error) {
      console.error('Error deleting phrase:', error);
      return false;
    }
    return true;
  },

  async incrementUsage(phraseId: string): Promise<boolean> {
    const { error } = await supabase.rpc('increment_phrase_usage', { phrase_id: phraseId });
    
    // If RPC doesn't exist, do it manually
    if (error) {
      const { data: phrase } = await supabase
        .from('custom_phrases')
        .select('usage_count')
        .eq('id', phraseId)
        .single();
      
      if (phrase) {
        await supabase
          .from('custom_phrases')
          .update({ usage_count: (phrase.usage_count || 0) + 1 })
          .eq('id', phraseId);
      }
    }
    return true;
  },

  subscribeToChanges(userId: string, callback: (phrases: DbCustomPhrase[]) => void) {
    const channel = supabase
      .channel('custom_phrases_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'custom_phrases',
          filter: `user_id=eq.${userId}`,
        },
        async () => {
          // Refetch all phrases when any change occurs
          const phrases = await this.getAll(userId);
          callback(phrases);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  },
};

// Emergency contacts operations
export const contactsService = {
  async getAll(userId: string): Promise<DbEmergencyContact[]> {
    const { data, error } = await supabase
      .from('emergency_contacts')
      .select('*')
      .eq('user_id', userId)
      .order('is_primary', { ascending: false })
      .order('created_at', { ascending: true });

    if (error) {
      console.error('Error fetching contacts:', error);
      return [];
    }
    return data as DbEmergencyContact[];
  },

  async add(userId: string, contact: Omit<EmergencyContact, 'id'>): Promise<DbEmergencyContact | null> {
    const { data, error } = await supabase
      .from('emergency_contacts')
      .insert([{
        user_id: userId,
        name: contact.name,
        phone: contact.phone,
        relationship: contact.relationship,
      }])
      .select()
      .single();

    if (error) {
      console.error('Error adding contact:', error);
      return null;
    }
    return data as DbEmergencyContact;
  },

  async update(contactId: string, updates: Partial<EmergencyContact>): Promise<boolean> {
    const { error } = await supabase
      .from('emergency_contacts')
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', contactId);

    if (error) {
      console.error('Error updating contact:', error);
      return false;
    }
    return true;
  },

  async delete(contactId: string): Promise<boolean> {
    const { error } = await supabase
      .from('emergency_contacts')
      .delete()
      .eq('id', contactId);

    if (error) {
      console.error('Error deleting contact:', error);
      return false;
    }
    return true;
  },

  subscribeToChanges(userId: string, callback: (contacts: DbEmergencyContact[]) => void) {
    const channel = supabase
      .channel('emergency_contacts_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'emergency_contacts',
          filter: `user_id=eq.${userId}`,
        },
        async () => {
          const contacts = await this.getAll(userId);
          callback(contacts);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  },
};

// Conversations operations
export const conversationsService = {
  async getRecent(userId: string, limit: number = 20): Promise<DbConversation[]> {
    const { data, error } = await supabase
      .from('conversations')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(limit);

    if (error) {
      console.error('Error fetching conversations:', error);
      return [];
    }
    // Reverse to get chronological order
    return (data as DbConversation[]).reverse();
  },

  async add(userId: string, message: Omit<Message, 'id' | 'timestamp'>): Promise<DbConversation | null> {
    const { data, error } = await supabase
      .from('conversations')
      .insert([{
        user_id: userId,
        text: message.text,
        sender: message.sender,
        message_type: message.type,
      }])
      .select()
      .single();

    if (error) {
      console.error('Error adding conversation:', error);
      return null;
    }
    return data as DbConversation;
  },

  async clearAll(userId: string): Promise<boolean> {
    const { error } = await supabase
      .from('conversations')
      .delete()
      .eq('user_id', userId);

    if (error) {
      console.error('Error clearing conversations:', error);
      return false;
    }
    return true;
  },

  subscribeToChanges(userId: string, callback: (conversations: DbConversation[]) => void) {
    const channel = supabase
      .channel('conversations_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'conversations',
          filter: `user_id=eq.${userId}`,
        },
        async () => {
          const conversations = await this.getRecent(userId);
          callback(conversations);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  },
};

// Generate or get user ID from localStorage
export const getUserId = (): string => {
  const storageKey = 'bridgetalk_anonymous_id';
  let userId = localStorage.getItem(storageKey);
  
  if (!userId) {
    userId = crypto.randomUUID();
    localStorage.setItem(storageKey, userId);
  }
  
  return userId;
};

// Data migration service for linking anonymous data to authenticated accounts
export const dataMigrationService = {
  async migrateUserData(fromUserId: string, toUserId: string): Promise<boolean> {
    try {
      // Migrate custom phrases
      const { data: phrases } = await supabase
        .from('custom_phrases')
        .select('*')
        .eq('user_id', fromUserId);

      if (phrases && phrases.length > 0) {
        // Check for existing phrases to avoid duplicates
        const { data: existingPhrases } = await supabase
          .from('custom_phrases')
          .select('text')
          .eq('user_id', toUserId);

        const existingTexts = new Set(existingPhrases?.map(p => p.text) || []);
        
        const newPhrases = phrases
          .filter(p => !existingTexts.has(p.text))
          .map(phrase => ({
            user_id: toUserId,
            text: phrase.text,
            category: phrase.category,
            usage_count: phrase.usage_count,
          }));

        if (newPhrases.length > 0) {
          await supabase.from('custom_phrases').insert(newPhrases);
        }
      }

      // Migrate emergency contacts
      const { data: contacts } = await supabase
        .from('emergency_contacts')
        .select('*')
        .eq('user_id', fromUserId);

      if (contacts && contacts.length > 0) {
        // Check for existing contacts to avoid duplicates
        const { data: existingContacts } = await supabase
          .from('emergency_contacts')
          .select('phone')
          .eq('user_id', toUserId);

        const existingPhones = new Set(existingContacts?.map(c => c.phone) || []);
        
        const newContacts = contacts
          .filter(c => !existingPhones.has(c.phone))
          .map(contact => ({
            user_id: toUserId,
            name: contact.name,
            phone: contact.phone,
            relationship: contact.relationship,
            is_primary: contact.is_primary,
          }));

        if (newContacts.length > 0) {
          await supabase.from('emergency_contacts').insert(newContacts);
        }
      }

      // Migrate conversations (last 50)
      const { data: conversations } = await supabase
        .from('conversations')
        .select('*')
        .eq('user_id', fromUserId)
        .order('created_at', { ascending: false })
        .limit(50);

      if (conversations && conversations.length > 0) {
        const newConversations = conversations.map(conv => ({
          user_id: toUserId,
          text: conv.text,
          sender: conv.sender,
          message_type: conv.message_type,
        }));

        await supabase.from('conversations').insert(newConversations);
      }

      // Migrate user settings
      const { data: userData } = await supabase
        .from('users')
        .select('settings')
        .eq('id', fromUserId)
        .single();

      if (userData?.settings) {
        // Check if target user already has settings
        const { data: existingUser } = await supabase
          .from('users')
          .select('settings')
          .eq('id', toUserId)
          .single();

        // Only migrate settings if target user doesn't have custom settings
        if (!existingUser?.settings || Object.keys(existingUser.settings).length === 0) {
          await supabase
            .from('users')
            .upsert({
              id: toUserId,
              settings: userData.settings,
            });
        }
      }

      console.log('Data migration completed successfully');
      return true;
    } catch (error) {
      console.error('Error migrating data:', error);
      return false;
    }
  },

  // Check if user has any data
  async hasUserData(userId: string): Promise<boolean> {
    const { data: phrases } = await supabase
      .from('custom_phrases')
      .select('id')
      .eq('user_id', userId)
      .limit(1);

    const { data: contacts } = await supabase
      .from('emergency_contacts')
      .select('id')
      .eq('user_id', userId)
      .limit(1);

    const { data: conversations } = await supabase
      .from('conversations')
      .select('id')
      .eq('user_id', userId)
      .limit(1);

    return (
      (phrases && phrases.length > 0) ||
      (contacts && contacts.length > 0) ||
      (conversations && conversations.length > 0)
    );
  },
};


// Subscription service
export interface DbSubscription {
  id: string;
  user_id: string;
  plan_id: string | null;
  stripe_customer_id: string | null;
  stripe_subscription_id: string | null;
  status: string;
  current_period_start: string | null;
  current_period_end: string | null;
  cancel_at_period_end: boolean;
  created_at: string;
  updated_at: string;
}

export interface DbUsageTracking {
  id: string;
  user_id: string;
  period_start: string;
  call_minutes_used: number;
  calls_made: number;
  messages_sent: number;
  asl_translations: number;
  created_at: string;
  updated_at: string;
}

export interface DbSubscriptionPlan {
  id: string;
  name: string;
  stripe_product_id: string | null;
  stripe_price_id: string | null;
  price_cents: number;
  interval: string;
  features: string[];
  limits: {
    call_minutes: number;
    hd_video: boolean;
    priority_support: boolean;
    team_features: boolean;
    analytics: boolean;
    custom_branding: boolean;
  };
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export const subscriptionService = {
  async getPlans(): Promise<DbSubscriptionPlan[]> {
    const { data, error } = await supabase
      .from('subscription_plans')
      .select('*')
      .eq('is_active', true)
      .order('price_cents', { ascending: true });

    if (error) {
      console.error('Error fetching plans:', error);
      return [];
    }
    return data as DbSubscriptionPlan[];
  },

  async getUserSubscription(userId: string): Promise<DbSubscription | null> {
    const { data, error } = await supabase
      .from('user_subscriptions')
      .select('*')
      .eq('user_id', userId)
      .single();

    if (error && error.code !== 'PGRST116') {
      console.error('Error fetching subscription:', error);
      return null;
    }
    return data as DbSubscription | null;
  },

  async createOrUpdateSubscription(
    userId: string, 
    subscriptionData: Partial<DbSubscription>
  ): Promise<DbSubscription | null> {
    const { data: existing } = await supabase
      .from('user_subscriptions')
      .select('id')
      .eq('user_id', userId)
      .single();

    if (existing) {
      const { data, error } = await supabase
        .from('user_subscriptions')
        .update({
          ...subscriptionData,
          updated_at: new Date().toISOString(),
        })
        .eq('user_id', userId)
        .select()
        .single();

      if (error) {
        console.error('Error updating subscription:', error);
        return null;
      }
      return data as DbSubscription;
    } else {
      const { data, error } = await supabase
        .from('user_subscriptions')
        .insert([{
          user_id: userId,
          ...subscriptionData,
        }])
        .select()
        .single();

      if (error) {
        console.error('Error creating subscription:', error);
        return null;
      }
      return data as DbSubscription;
    }
  },
};

export const usageService = {
  async getUsage(userId: string): Promise<DbUsageTracking | null> {
    const today = new Date().toISOString().split('T')[0];
    
    const { data, error } = await supabase
      .from('usage_tracking')
      .select('*')
      .eq('user_id', userId)
      .eq('period_start', today)
      .single();

    if (error && error.code !== 'PGRST116') {
      console.error('Error fetching usage:', error);
      return null;
    }
    return data as DbUsageTracking | null;
  },

  async trackCallMinutes(userId: string, minutes: number): Promise<boolean> {
    const today = new Date().toISOString().split('T')[0];
    
    const { data: existing } = await supabase
      .from('usage_tracking')
      .select('*')
      .eq('user_id', userId)
      .eq('period_start', today)
      .single();

    if (existing) {
      const { error } = await supabase
        .from('usage_tracking')
        .update({
          call_minutes_used: existing.call_minutes_used + minutes,
          calls_made: existing.calls_made + 1,
          updated_at: new Date().toISOString(),
        })
        .eq('id', existing.id);

      if (error) {
        console.error('Error updating usage:', error);
        return false;
      }
    } else {
      const { error } = await supabase
        .from('usage_tracking')
        .insert([{
          user_id: userId,
          period_start: today,
          call_minutes_used: minutes,
          calls_made: 1,
        }]);

      if (error) {
        console.error('Error creating usage:', error);
        return false;
      }
    }
    return true;
  },

  async getMonthlyUsage(userId: string): Promise<DbUsageTracking[]> {

    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    const startDate = thirtyDaysAgo.toISOString().split('T')[0];
    
    const { data, error } = await supabase
      .from('usage_tracking')
      .select('*')
      .eq('user_id', userId)
      .gte('period_start', startDate)
      .order('period_start', { ascending: true });

    if (error) {
      console.error('Error fetching monthly usage:', error);
      return [];
    }
    return data as DbUsageTracking[];
  },

  async getTotalUsageThisMonth(userId: string): Promise<{
    totalMinutes: number;
    totalCalls: number;
    totalMessages: number;
    totalASL: number;
  }> {
    const firstOfMonth = new Date();
    firstOfMonth.setDate(1);
    const startDate = firstOfMonth.toISOString().split('T')[0];
    
    const { data, error } = await supabase
      .from('usage_tracking')
      .select('call_minutes_used, calls_made, messages_sent, asl_translations')
      .eq('user_id', userId)
      .gte('period_start', startDate);

    if (error) {
      console.error('Error fetching total usage:', error);
      return { totalMinutes: 0, totalCalls: 0, totalMessages: 0, totalASL: 0 };
    }

    const totals = (data || []).reduce((acc, row) => ({
      totalMinutes: acc.totalMinutes + (row.call_minutes_used || 0),
      totalCalls: acc.totalCalls + (row.calls_made || 0),
      totalMessages: acc.totalMessages + (row.messages_sent || 0),
      totalASL: acc.totalASL + (row.asl_translations || 0),
    }), { totalMinutes: 0, totalCalls: 0, totalMessages: 0, totalASL: 0 });

    return totals;
  },
};

// Billing history service
export interface DbBillingHistory {
  id: string;
  user_id: string;
  stripe_invoice_id: string | null;
  amount_cents: number;
  currency: string;
  status: string;
  description: string;
  invoice_url: string | null;
  created_at: string;
}

export const billingService = {
  async getBillingHistory(userId: string): Promise<DbBillingHistory[]> {
    const { data, error } = await supabase
      .from('billing_history')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching billing history:', error);
      return [];
    }
    return data as DbBillingHistory[];
  },
};
