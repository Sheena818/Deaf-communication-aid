import React, { createContext, useContext, useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { dataMigrationService } from '@/lib/database';
import { toast } from '@/components/ui/use-toast';

interface User {
  id: string;
  email: string;
  displayName?: string;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  anonymousId: string;
  signUp: (email: string, password: string, displayName?: string) => Promise<{ success: boolean; error?: string }>;
  signIn: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  signOut: () => Promise<void>;
  migrateAnonymousData: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// Get or create anonymous ID
const getAnonymousId = (): string => {
  const storageKey = 'bridgetalk_anonymous_id';
  let anonymousId = localStorage.getItem(storageKey);
  
  if (!anonymousId) {
    anonymousId = crypto.randomUUID();
    localStorage.setItem(storageKey, anonymousId);
  }
  
  return anonymousId;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [anonymousId] = useState(getAnonymousId);

  // Check for existing session on mount
  useEffect(() => {
    const checkSession = async () => {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        
        if (session?.user) {
          setUser({
            id: session.user.id,
            email: session.user.email || '',
            displayName: session.user.user_metadata?.display_name,
          });
        }
      } catch (error) {
        console.error('Error checking session:', error);
      } finally {
        setIsLoading(false);
      }
    };

    checkSession();

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (event === 'SIGNED_IN' && session?.user) {
        setUser({
          id: session.user.id,
          email: session.user.email || '',
          displayName: session.user.user_metadata?.display_name,
        });
      } else if (event === 'SIGNED_OUT') {
        setUser(null);
      }
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const signUp = async (email: string, password: string, displayName?: string): Promise<{ success: boolean; error?: string }> => {
    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            display_name: displayName,
          },
        },
      });

      if (error) {
        return { success: false, error: error.message };
      }

      if (data.user) {
        // Migrate anonymous data to the new authenticated user
        const hasData = await dataMigrationService.hasUserData(anonymousId);
        if (hasData) {
          await dataMigrationService.migrateUserData(anonymousId, data.user.id);
        }
        
        setUser({
          id: data.user.id,
          email: data.user.email || '',
          displayName,
        });

        toast({
          title: 'Account created!',
          description: hasData 
            ? 'Your data has been synced to your new account.' 
            : 'Welcome to BridgeTalk!',
        });

        return { success: true };
      }

      return { success: false, error: 'Unknown error occurred' };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  };

  const signIn = async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        return { success: false, error: error.message };
      }

      if (data.user) {
        // Check if there's anonymous data to migrate
        const hasAnonymousData = await dataMigrationService.hasUserData(anonymousId);
        if (hasAnonymousData) {
          // Ask user if they want to merge data or just use their existing data
          await dataMigrationService.migrateUserData(anonymousId, data.user.id);
        }

        setUser({
          id: data.user.id,
          email: data.user.email || '',
          displayName: data.user.user_metadata?.display_name,
        });

        toast({
          title: 'Welcome back!',
          description: 'You have been signed in successfully.',
        });

        return { success: true };
      }

      return { success: false, error: 'Unknown error occurred' };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  };

  const signOut = async () => {
    try {
      await supabase.auth.signOut();
      setUser(null);
      
      toast({
        title: 'Signed out',
        description: 'You have been signed out successfully.',
      });
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  const migrateAnonymousData = async () => {
    if (user) {
      await dataMigrationService.migrateUserData(anonymousId, user.id);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isLoading,
        anonymousId,
        signUp,
        signIn,
        signOut,
        migrateAnonymousData,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};
