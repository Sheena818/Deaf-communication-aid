# Android Build Guide - Deaf Communication Aid

## Quick Start Commands

Run these commands in your terminal to build the Android app:

```bash
# Step 1: Install all dependencies
npm install

# Step 2: Build the web application
npm run build

# Step 3: Add Android platform (creates android/ folder)
npx cap add android

# Step 4: Sync web assets to Android project
npx cap sync android

# Step 5: Open in Android Studio
npx cap open android
```

Or use the single command:
```bash
npm run android:build
```

---

## Prerequisites Checklist

Before running the build commands, ensure you have:

### Required Software
- [ ] **Node.js 18+** - [Download](https://nodejs.org/)
- [ ] **Android Studio** (latest) - [Download](https://developer.android.com/studio)
- [ ] **JDK 17+** - Usually bundled with Android Studio
- [ ] **Android SDK** - Install via Android Studio SDK Manager

### Android Studio Setup
1. Open Android Studio
2. Go to **Tools → SDK Manager**
3. Install:
   - Android SDK Platform 34 (Android 14)
   - Android SDK Build-Tools 34
   - Android Emulator
   - Android SDK Platform-Tools

### Environment Variables
Add to your shell profile (`.bashrc`, `.zshrc`, etc.):

```bash
export ANDROID_HOME=$HOME/Android/Sdk
export PATH=$PATH:$ANDROID_HOME/emulator
export PATH=$PATH:$ANDROID_HOME/platform-tools
export PATH=$PATH:$ANDROID_HOME/tools
export PATH=$PATH:$ANDROID_HOME/tools/bin
```

On macOS, ANDROID_HOME is typically:
```bash
export ANDROID_HOME=$HOME/Library/Android/sdk
```

On Windows, set via System Environment Variables:
```
ANDROID_HOME = C:\Users\<username>\AppData\Local\Android\Sdk
```

---

## Detailed Build Process

### Step 1: Install Dependencies

```bash
npm install
```

This installs:
- Capacitor core and CLI
- Capacitor Android platform
- All required plugins (camera, haptics, keyboard, etc.)

### Step 2: Build Web App

```bash
npm run build
```

Creates the `dist/` folder with the production web app.

### Step 3: Add Android Platform

```bash
npx cap add android
```

This creates the `android/` directory containing:
- Complete Android Studio project
- Gradle build files
- Native Android code
- Resource directories

### Step 4: Configure Android Resources

After adding the platform, copy the resource files:

```bash
# Copy strings.xml
cp android-resources/strings.xml android/app/src/main/res/values/

# Copy colors.xml
cp android-resources/colors.xml android/app/src/main/res/values/

# Merge AndroidManifest.xml permissions
# (manually add permissions from android-resources/AndroidManifest.xml)
```

### Step 5: Sync Web Assets

```bash
npx cap sync android
```

This copies:
- Built web assets to Android project
- Plugin configurations
- Capacitor runtime

### Step 6: Open in Android Studio

```bash
npx cap open android
```

Android Studio will open with the project.

---

## Android Studio Configuration

### First Time Setup

1. **Wait for Gradle Sync** - Android Studio will download dependencies
2. **Accept SDK Licenses** if prompted
3. **Update Gradle** if recommended

### Configure Signing

1. Go to **Build → Generate Signed Bundle / APK**
2. Create a new keystore:
   - **Key store path**: Choose a secure location
   - **Password**: Create a strong password
   - **Alias**: `deafcomm-release`
   - **Validity**: 25+ years
   - **Certificate info**: Fill in your details

3. Save keystore credentials securely!

### Update build.gradle

In `android/app/build.gradle`, update:

```gradle
android {
    namespace "com.deafcomm.app"
    compileSdkVersion 34
    
    defaultConfig {
        applicationId "com.deafcomm.app"
        minSdkVersion 24
        targetSdkVersion 34
        versionCode 1
        versionName "1.0.0"
    }
    
    signingConfigs {
        release {
            storeFile file("path/to/your/keystore.jks")
            storePassword "your-store-password"
            keyAlias "deafcomm-release"
            keyPassword "your-key-password"
        }
    }
    
    buildTypes {
        release {
            signingConfig signingConfigs.release
            minifyEnabled true
            proguardFiles getDefaultProguardFile('proguard-android.txt'), 'proguard-rules.pro'
        }
    }
}
```

---

## Building Release APK/AAB

### Option 1: Android Studio UI

1. Go to **Build → Generate Signed Bundle / APK**
2. Select **Android App Bundle** (recommended for Play Store)
3. Select your keystore
4. Choose **release** build variant
5. Click **Finish**

Output: `android/app/build/outputs/bundle/release/app-release.aab`

### Option 2: Command Line

```bash
cd android

# Build AAB (for Play Store)
./gradlew bundleRelease

# Build APK (for direct installation)
./gradlew assembleRelease
```

---

## Testing

### On Emulator

1. In Android Studio, go to **Tools → Device Manager**
2. Create a virtual device (Pixel 6 recommended)
3. Click **Run** (green play button)

### On Physical Device

1. Enable **Developer Options** on your Android phone:
   - Go to Settings → About Phone
   - Tap "Build Number" 7 times
2. Enable **USB Debugging** in Developer Options
3. Connect phone via USB
4. Select your device in Android Studio
5. Click **Run**

Or via command line:
```bash
npx cap run android --target <device-id>
```

---

## Troubleshooting

### Gradle Sync Failed

```bash
cd android
./gradlew clean
./gradlew build --refresh-dependencies
```

### SDK Not Found

1. Open Android Studio → SDK Manager
2. Install required SDK versions
3. Verify ANDROID_HOME environment variable

### Java Version Mismatch

Check Java version:
```bash
java -version
```

Should be JDK 17+. If not:
1. Install JDK 17 from [Adoptium](https://adoptium.net/)
2. Set JAVA_HOME environment variable

### Build Errors

```bash
# Clean and rebuild
cd android
./gradlew clean
cd ..
npx cap sync android
```

### Permission Issues

Ensure AndroidManifest.xml has all required permissions from `android-resources/AndroidManifest.xml`.

---

## Play Store Submission Checklist

### Required Assets
- [ ] App icon (512x512 PNG)
- [ ] Feature graphic (1024x500 PNG)
- [ ] Screenshots (phone: 1080x1920, tablet: 1200x1920)
- [ ] Short description (80 characters max)
- [ ] Full description (4000 characters max)
- [ ] Privacy policy URL
- [ ] Signed release AAB

### Play Console Steps
1. Create app in [Google Play Console](https://play.google.com/console)
2. Complete store listing
3. Fill content rating questionnaire
4. Complete data safety form
5. Upload signed AAB
6. Submit for review

### Accessibility Documentation
Include in your store listing:
- TalkBack support
- Large text support
- High contrast mode
- Screen reader compatibility
- Haptic feedback for notifications

---

## Useful Commands Reference

```bash
# Install dependencies
npm install

# Build web app
npm run build

# Add Android platform
npx cap add android

# Sync changes
npx cap sync android

# Open in Android Studio
npx cap open android

# Run on emulator/device
npx cap run android

# Copy web assets only (no plugin update)
npx cap copy android

# Update plugins
npx cap update android

# Check Capacitor doctor
npx cap doctor

# List connected devices
adb devices
```

---

## Support Resources

- [Capacitor Android Documentation](https://capacitorjs.com/docs/android)
- [Android Developer Documentation](https://developer.android.com/docs)
- [Google Play Console Help](https://support.google.com/googleplay/android-developer)
- [Android Accessibility Guidelines](https://developer.android.com/guide/topics/ui/accessibility)
