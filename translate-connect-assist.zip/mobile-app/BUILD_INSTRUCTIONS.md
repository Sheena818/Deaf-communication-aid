# Deaf Communication Aid - Native App Build Instructions

## Prerequisites

Before building the native apps, ensure you have the following installed:

### For iOS Development:
- **macOS** (required for iOS development)
- **Xcode 15+** (from Mac App Store)
- **Xcode Command Line Tools**: `xcode-select --install`
- **CocoaPods**: `sudo gem install cocoapods`
- **Apple Developer Account** ($99/year for App Store distribution)

### For Android Development:
- **Android Studio** (latest version)
- **Android SDK** (API level 33+)
- **Java Development Kit (JDK) 17+**
- **Google Play Developer Account** ($25 one-time fee)

### For Both:
- **Node.js 18+** and npm
- **Git**

---

## Step-by-Step Build Process

### Step 1: Install Dependencies

Open your terminal in the project root directory and run:

```bash
# Install all npm dependencies including Capacitor
npm install
```

This will install:
- `@capacitor/core` - Capacitor runtime
- `@capacitor/cli` - Capacitor command line tools
- `@capacitor/ios` - iOS platform support
- `@capacitor/android` - Android platform support
- All Capacitor plugins (camera, haptics, keyboard, etc.)

### Step 2: Build the Web App

```bash
# Build the production web app
npm run build
```

This creates the `dist/` folder with the optimized web app that will be bundled into the native apps.

### Step 3: Initialize Capacitor (if not already done)

```bash
# Initialize Capacitor in the project
npx cap init "Deaf Communication Aid" "com.deafcomm.app" --web-dir dist
```

> Note: This may already be configured via `capacitor.config.ts`

---

## iOS Build Process

### Step 4a: Add iOS Platform

```bash
# Add the iOS platform to your project
npx cap add ios
```

This creates the `ios/` directory with a complete Xcode project.

### Step 5a: Sync Web App to iOS

```bash
# Copy web assets and sync native plugins
npx cap sync ios
```

### Step 6a: Configure iOS Permissions

The following permissions need to be added to `ios/App/App/Info.plist`:

```xml
<!-- Camera Permission -->
<key>NSCameraUsageDescription</key>
<string>This app needs camera access for video calls and visual communication features.</string>

<!-- Microphone Permission -->
<key>NSMicrophoneUsageDescription</key>
<string>This app needs microphone access for speech-to-text transcription and voice communication.</string>

<!-- Speech Recognition Permission -->
<key>NSSpeechRecognitionUsageDescription</key>
<string>This app uses speech recognition to convert spoken words to text for deaf and hard of hearing users.</string>

<!-- Photo Library Permission -->
<key>NSPhotoLibraryUsageDescription</key>
<string>This app needs photo library access to save and share communication content.</string>

<!-- Background Audio -->
<key>UIBackgroundModes</key>
<array>
    <string>audio</string>
    <string>voip</string>
</array>
```

### Step 7a: Open in Xcode

```bash
# Open the iOS project in Xcode
npx cap open ios
```

### Step 8a: Configure Xcode Project

In Xcode:

1. **Select the App target** in the project navigator
2. **Signing & Capabilities tab**:
   - Select your Team (Apple Developer account)
   - Set Bundle Identifier: `com.deafcomm.app`
   - Enable "Automatically manage signing"
3. **Add Capabilities**:
   - Push Notifications
   - Background Modes (Audio, VoIP)
   - Access WiFi Information
4. **General tab**:
   - Set Display Name: "Deaf Comm Aid"
   - Set Version: 1.0.0
   - Set Build: 1
   - Set Deployment Target: iOS 14.0+

### Step 9a: Add App Icons

1. Open `ios/App/App/Assets.xcassets/AppIcon.appiconset`
2. Add icons in all required sizes (see SCREENSHOTS.md)
3. Or use an icon generator tool like [App Icon Generator](https://appicon.co/)

### Step 10a: Build and Test

```bash
# Build for iOS Simulator
npx cap run ios

# Or build for a physical device (requires provisioning profile)
npx cap run ios --device
```

### Step 11a: Archive for App Store

In Xcode:
1. Select "Any iOS Device" as the build target
2. Go to **Product → Archive**
3. Once archived, click **Distribute App**
4. Select **App Store Connect**
5. Follow the upload wizard

---

## Android Build Process

### Step 4b: Add Android Platform

```bash
# Add the Android platform to your project
npx cap add android
```

This creates the `android/` directory with a complete Android Studio project.

### Step 5b: Sync Web App to Android

```bash
# Copy web assets and sync native plugins
npx cap sync android
```

### Step 6b: Configure Android Permissions

The following permissions should be in `android/app/src/main/AndroidManifest.xml`:

```xml
<!-- Camera Permission -->
<uses-permission android:name="android.permission.CAMERA" />

<!-- Microphone Permission -->
<uses-permission android:name="android.permission.RECORD_AUDIO" />

<!-- Internet Access -->
<uses-permission android:name="android.permission.INTERNET" />

<!-- Vibration for Haptic Feedback -->
<uses-permission android:name="android.permission.VIBRATE" />

<!-- Notifications -->
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />

<!-- Storage for saving content -->
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />

<!-- Feature declarations -->
<uses-feature android:name="android.hardware.camera" android:required="false" />
<uses-feature android:name="android.hardware.microphone" android:required="false" />
```

### Step 7b: Open in Android Studio

```bash
# Open the Android project in Android Studio
npx cap open android
```

### Step 8b: Configure Android Project

In Android Studio:

1. **Update `android/app/build.gradle`**:
   ```gradle
   android {
       namespace "com.deafcomm.app"
       compileSdkVersion 34
       
       defaultConfig {
           applicationId "com.deafcomm.app"
           minSdkVersion 24
           targetSdkVersion 34
           versionCode 1
           versionName "1.0.0"
       }
       
       buildTypes {
           release {
               minifyEnabled true
               proguardFiles getDefaultProguardFile('proguard-android.txt'), 'proguard-rules.pro'
           }
       }
   }
   ```

2. **Update `android/app/src/main/res/values/strings.xml`**:
   ```xml
   <resources>
       <string name="app_name">Deaf Comm Aid</string>
       <string name="title_activity_main">Deaf Communication Aid</string>
       <string name="package_name">com.deafcomm.app</string>
   </resources>
   ```

### Step 9b: Add App Icons

1. Right-click on `android/app/src/main/res` → **New → Image Asset**
2. Select your app icon image
3. Generate all required density icons (mdpi, hdpi, xhdpi, xxhdpi, xxxhdpi)

### Step 10b: Build and Test

```bash
# Build for Android Emulator
npx cap run android

# Or build for a physical device (enable USB debugging)
npx cap run android --device
```

### Step 11b: Build Release APK/AAB

In Android Studio:
1. Go to **Build → Generate Signed Bundle / APK**
2. Select **Android App Bundle** (recommended for Play Store)
3. Create or select your keystore
4. Build the release AAB

Or via command line:
```bash
cd android
./gradlew bundleRelease
```

The AAB will be at: `android/app/build/outputs/bundle/release/app-release.aab`

---

## Quick Command Reference

```bash
# Full iOS build process
npm install
npm run build
npx cap add ios
npx cap sync ios
npx cap open ios

# Full Android build process
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android

# After making web changes, sync to native projects
npm run build
npx cap sync

# Run on specific platform
npx cap run ios
npx cap run android

# Copy only (without updating plugins)
npx cap copy ios
npx cap copy android

# Update native plugins
npx cap update ios
npx cap update android
```

---

## Automated Build Script

Create a file called `build-native.sh` in your project root:

```bash
#!/bin/bash

echo "🚀 Deaf Communication Aid - Native Build Script"
echo "================================================"

# Check for required tools
command -v node >/dev/null 2>&1 || { echo "❌ Node.js is required but not installed."; exit 1; }
command -v npm >/dev/null 2>&1 || { echo "❌ npm is required but not installed."; exit 1; }

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Build web app
echo "🔨 Building web app..."
npm run build

if [ ! -d "dist" ]; then
    echo "❌ Build failed - dist folder not created"
    exit 1
fi

echo "✅ Web build complete!"

# Platform selection
echo ""
echo "Select platform to build:"
echo "1) iOS"
echo "2) Android"
echo "3) Both"
read -p "Enter choice [1-3]: " choice

case $choice in
    1)
        echo "🍎 Building for iOS..."
        npx cap add ios 2>/dev/null || echo "iOS platform already exists"
        npx cap sync ios
        echo "✅ iOS build ready! Opening Xcode..."
        npx cap open ios
        ;;
    2)
        echo "🤖 Building for Android..."
        npx cap add android 2>/dev/null || echo "Android platform already exists"
        npx cap sync android
        echo "✅ Android build ready! Opening Android Studio..."
        npx cap open android
        ;;
    3)
        echo "🍎 Building for iOS..."
        npx cap add ios 2>/dev/null || echo "iOS platform already exists"
        npx cap sync ios
        
        echo "🤖 Building for Android..."
        npx cap add android 2>/dev/null || echo "Android platform already exists"
        npx cap sync android
        
        echo "✅ Both platforms ready!"
        echo "Opening Xcode..."
        npx cap open ios
        echo "Opening Android Studio..."
        npx cap open android
        ;;
    *)
        echo "Invalid choice"
        exit 1
        ;;
esac

echo ""
echo "🎉 Build process complete!"
echo "Follow the platform-specific instructions to archive and submit to app stores."
```

Make it executable:
```bash
chmod +x build-native.sh
./build-native.sh
```

---

## Troubleshooting

### iOS Issues

**"No signing certificate" error:**
- Open Xcode → Preferences → Accounts
- Add your Apple Developer account
- Download certificates

**CocoaPods issues:**
```bash
cd ios/App
pod install --repo-update
```

**Build fails with Swift version error:**
- In Xcode, select the project → Build Settings
- Set "Swift Language Version" to 5.0

### Android Issues

**Gradle sync failed:**
```bash
cd android
./gradlew clean
./gradlew build
```

**SDK not found:**
- Open Android Studio → SDK Manager
- Install Android SDK 34
- Set ANDROID_HOME environment variable

**Java version mismatch:**
- Ensure JDK 17 is installed and JAVA_HOME is set

### General Issues

**Changes not appearing in native app:**
```bash
npm run build
npx cap sync
```

**Plugin not working:**
```bash
npx cap sync
# Then rebuild in Xcode/Android Studio
```

---

## App Store Submission Checklist

### iOS (App Store Connect)
- [ ] App icons (all sizes)
- [ ] Screenshots (all device sizes)
- [ ] App description
- [ ] Keywords
- [ ] Privacy policy URL
- [ ] Support URL
- [ ] Age rating questionnaire
- [ ] App Review Information
- [ ] Accessibility documentation

### Android (Google Play Console)
- [ ] App icons (512x512)
- [ ] Feature graphic (1024x500)
- [ ] Screenshots (phone and tablet)
- [ ] Short description (80 chars)
- [ ] Full description (4000 chars)
- [ ] Privacy policy URL
- [ ] Content rating questionnaire
- [ ] Target audience declaration
- [ ] Data safety form
- [ ] Accessibility features list

---

## Support

For issues with:
- **Capacitor**: https://capacitorjs.com/docs
- **iOS Development**: https://developer.apple.com/documentation/
- **Android Development**: https://developer.android.com/docs
- **App Store Guidelines**: https://developer.apple.com/app-store/review/guidelines/
- **Play Store Policies**: https://play.google.com/about/developer-content-policy/
