# Deaf Communication Aid - App Store Metadata

## App Information

### App Name
**Primary**: Deaf Communication Aid
**Subtitle (iOS)**: Real-time Speech to Text & Video Calls

### Bundle/Package ID
- **iOS**: `com.deafcomm.app`
- **Android**: `com.deafcomm.app`

### Category
- **Primary**: Utilities / Accessibility
- **Secondary**: Communication / Social

---

## App Store Connect (iOS)

### App Description (4000 characters max)

```
Deaf Communication Aid bridges the gap between deaf/hard-of-hearing individuals and hearing people through innovative real-time communication tools.

🎯 CORE FEATURES

• Real-Time Speech-to-Text
Convert spoken words to text instantly with industry-leading accuracy. Perfect for conversations, meetings, lectures, and everyday interactions.

• Text-to-Speech
Type your message and let the app speak for you with natural-sounding voices. Choose from multiple voice options and languages.

• Accessible Video Calls
Make video calls with built-in live captions. Never miss a word during important conversations with friends, family, or colleagues.

• Quick Phrases
Access commonly used phrases with one tap. Customize your phrase library for faster communication in any situation.

• ASL Learning Resources
Learn American Sign Language with our integrated learning section featuring common signs and practice materials.

• Emergency Communication
Quickly communicate in emergency situations with pre-set emergency phrases and visual alerts.

🌟 ACCESSIBILITY FIRST

Designed with the deaf and hard-of-hearing community in mind:
- High contrast visual design
- Large, readable text options
- Haptic feedback for notifications
- VoiceOver and TalkBack compatible
- Customizable visual alerts
- Works offline for essential features

💬 COMMUNICATION MODES

1. Live Conversation Mode - Real-time transcription during face-to-face conversations
2. Video Call Mode - Captioned video calls with friends and family
3. Presentation Mode - Follow along with speakers in meetings or lectures
4. Quick Response Mode - Fast communication using preset phrases

🔒 PRIVACY & SECURITY

Your conversations stay private:
- On-device speech processing when possible
- End-to-end encrypted video calls
- No conversation data stored on servers
- HIPAA-compliant for medical settings

📱 WORKS EVERYWHERE

- iPhone, iPad, and Apple Watch support
- Works with hearing aids and cochlear implants
- CarPlay compatible for safe driving communication
- Siri Shortcuts integration

🆓 FREE TO START

Get started with our free tier:
- 60 minutes of speech-to-text per month
- Basic video calling
- Essential quick phrases
- Community support

Upgrade to Premium for unlimited access and advanced features.

---

Deaf Communication Aid is committed to making communication accessible for everyone. We work closely with the deaf community to continuously improve our app.

Questions or feedback? Contact us at support@deafcomm.app

Follow us:
Twitter: @DeafCommApp
Instagram: @DeafCommunicationAid
```

### Promotional Text (170 characters)
```
Break communication barriers! Real-time speech-to-text, accessible video calls, and quick phrases designed for the deaf and hard-of-hearing community.
```

### Keywords (100 characters)
```
deaf,hearing,accessibility,speech to text,captions,ASL,sign language,transcription,video call,a11y
```

### What's New (4000 characters)
```
Version 1.0.0 - Initial Release

We're thrilled to launch Deaf Communication Aid!

NEW FEATURES:
• Real-time speech-to-text transcription
• Text-to-speech with natural voices
• Accessible video calling with live captions
• Quick phrases for fast communication
• ASL learning resources
• Emergency communication tools
• Customizable visual and haptic alerts

ACCESSIBILITY:
• Full VoiceOver support
• Dynamic Type compatibility
• High contrast mode
• Reduced motion options

Thank you to our beta testers from the deaf community who helped shape this app. Your feedback has been invaluable!

Questions? Email support@deafcomm.app
```

### Support URL
`https://deafcomm.app/support`

### Marketing URL
`https://deafcomm.app`

### Privacy Policy URL
`https://deafcomm.app/privacy`

### App Store Rating
- Age Rating: 4+ (No objectionable content)

---

## Google Play Store (Android)

### Short Description (80 characters)
```
Real-time speech-to-text & accessible video calls for deaf communication
```

### Full Description (4000 characters)

```
Deaf Communication Aid bridges the gap between deaf/hard-of-hearing individuals and hearing people through innovative real-time communication tools.

★ CORE FEATURES ★

► Real-Time Speech-to-Text
Convert spoken words to text instantly with industry-leading accuracy. Perfect for conversations, meetings, lectures, and everyday interactions.

► Text-to-Speech
Type your message and let the app speak for you with natural-sounding voices. Choose from multiple voice options and languages.

► Accessible Video Calls
Make video calls with built-in live captions. Never miss a word during important conversations with friends, family, or colleagues.

► Quick Phrases
Access commonly used phrases with one tap. Customize your phrase library for faster communication in any situation.

► ASL Learning Resources
Learn American Sign Language with our integrated learning section featuring common signs and practice materials.

► Emergency Communication
Quickly communicate in emergency situations with pre-set emergency phrases and visual alerts.

★ ACCESSIBILITY FIRST ★

Designed with the deaf and hard-of-hearing community in mind:
• High contrast visual design
• Large, readable text options
• Haptic feedback for notifications
• TalkBack compatible
• Customizable visual alerts
• Works offline for essential features

★ COMMUNICATION MODES ★

1. Live Conversation Mode - Real-time transcription during face-to-face conversations
2. Video Call Mode - Captioned video calls with friends and family
3. Presentation Mode - Follow along with speakers in meetings or lectures
4. Quick Response Mode - Fast communication using preset phrases

★ PRIVACY & SECURITY ★

Your conversations stay private:
• On-device speech processing when possible
• End-to-end encrypted video calls
• No conversation data stored on servers
• HIPAA-compliant for medical settings

★ FREE TO START ★

Get started with our free tier:
• 60 minutes of speech-to-text per month
• Basic video calling
• Essential quick phrases
• Community support

Upgrade to Premium for unlimited access and advanced features.

---

Deaf Communication Aid is committed to making communication accessible for everyone. We work closely with the deaf community to continuously improve our app.

Questions or feedback? Contact us at support@deafcomm.app

Follow us on social media @DeafCommApp
```

### Tags/Categories
- Communication
- Accessibility
- Tools

### Content Rating
- ESRB: Everyone
- PEGI: 3

---

## App Store Assets

### App Icon
- **File**: `app-icon.png`
- **URL**: https://d64gsuwffb70l.cloudfront.net/6945ed0ba05f1477c272f404_1766203738239_3470bc2d.png
- **Sizes needed**:
  - iOS: 1024x1024 (App Store), various sizes for device
  - Android: 512x512 (Play Store), various mipmap sizes

### Feature Graphic (Android)
- **File**: `feature-graphic.png`
- **URL**: https://d64gsuwffb70l.cloudfront.net/6945ed0ba05f1477c272f404_1766203798694_bf6ccc8a.png
- **Size**: 1024x500

### Screenshots
See `SCREENSHOTS.md` for complete screenshot specifications and URLs.

---

## Localization

### Supported Languages (Initial Launch)
1. English (US) - Primary
2. English (UK)
3. Spanish (ES)
4. French (FR)
5. German (DE)

### Future Languages
- Japanese
- Korean
- Portuguese (BR)
- Italian
- Dutch
- Polish
- Arabic
- Chinese (Simplified)

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0.0 | TBD | Initial release |

---

## Contact Information

- **Developer Name**: Deaf Communication Aid Team
- **Support Email**: support@deafcomm.app
- **Website**: https://deafcomm.app
- **Privacy Policy**: https://deafcomm.app/privacy
- **Terms of Service**: https://deafcomm.app/terms
