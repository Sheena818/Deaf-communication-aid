# Deaf Communication Aid - App Store Screenshots

## Screenshot Requirements

### iOS App Store

| Device | Size (pixels) | Required |
|--------|---------------|----------|
| iPhone 6.7" (14 Pro Max, 15 Pro Max) | 1290 x 2796 | Yes |
| iPhone 6.5" (11 Pro Max, XS Max) | 1242 x 2688 | Yes |
| iPhone 5.5" (8 Plus, 7 Plus) | 1242 x 2208 | Optional |
| iPad Pro 12.9" (6th gen) | 2048 x 2732 | If iPad supported |
| iPad Pro 12.9" (2nd gen) | 2048 x 2732 | If iPad supported |

**Maximum**: 10 screenshots per device size
**Minimum**: 3 screenshots per device size

### Google Play Store

| Type | Size (pixels) | Required |
|------|---------------|----------|
| Phone | 1080 x 1920 (min) to 1440 x 2560 | Yes (2-8) |
| 7" Tablet | 1200 x 1920 | Optional |
| 10" Tablet | 1800 x 2560 | Optional |

**Feature Graphic**: 1024 x 500 (Required)

---

## Screenshot Content Strategy

### Screenshot 1: Hero/Main Feature
**Title**: "Real-Time Speech to Text"
**Description**: Shows the main transcription interface with live speech being converted to text
**Key Elements**:
- Active transcription display
- Clear, large text
- Visual indicator of listening state

**Generated Asset**: 
![Screenshot 1](https://d64gsuwffb70l.cloudfront.net/6945ed0ba05f1477c272f404_1766203754617_af8e3f7c.png)

---

### Screenshot 2: Video Calling
**Title**: "Accessible Video Calls"
**Description**: Video call interface with live captions displayed
**Key Elements**:
- Video call in progress
- Live captions overlay
- Call controls visible

**Generated Asset**:
![Screenshot 2](https://d64gsuwffb70l.cloudfront.net/6945ed0ba05f1477c272f404_1766203754898_8047c97d.jpg)

---

### Screenshot 3: Quick Phrases
**Title**: "Quick Communication"
**Description**: Quick phrases grid for fast responses
**Key Elements**:
- Category tabs
- Phrase buttons
- Customization option visible

**Generated Asset**:
![Screenshot 3](https://d64gsuwffb70l.cloudfront.net/6945ed0ba05f1477c272f404_1766203755284_229bb1e4.jpg)

---

### Screenshot 4: Text-to-Speech
**Title**: "Type & Speak"
**Description**: Text-to-speech interface showing typed message
**Key Elements**:
- Text input area
- Voice selection
- Play/speak button

**Generated Asset**:
![Screenshot 4](https://d64gsuwffb70l.cloudfront.net/6945ed0ba05f1477c272f404_1766203771282_ad4b3c75.jpg)

---

### Screenshot 5: ASL Learning
**Title**: "Learn Sign Language"
**Description**: ASL learning section with sign demonstrations
**Key Elements**:
- Sign illustration/video
- Word/phrase label
- Progress indicator

**Generated Asset**:
![Screenshot 5](https://d64gsuwffb70l.cloudfront.net/6945ed0ba05f1477c272f404_1766203774692_6563dc68.png)

---

### Screenshot 6: Settings/Accessibility
**Title**: "Fully Customizable"
**Description**: Settings screen showing accessibility options
**Key Elements**:
- Font size options
- High contrast toggle
- Haptic feedback settings
- Language selection

---

### Screenshot 7: Emergency Mode
**Title**: "Emergency Ready"
**Description**: Emergency communication interface
**Key Elements**:
- Emergency phrases
- Large, clear buttons
- Visual alert indicators

---

### Screenshot 8: Conversation History
**Title**: "Save & Review"
**Description**: Saved conversations list
**Key Elements**:
- Conversation list
- Search functionality
- Export option

---

## Screenshot Text Overlays

### Design Guidelines
- **Font**: SF Pro (iOS) / Roboto (Android)
- **Title Size**: 48-64px bold
- **Subtitle Size**: 24-32px regular
- **Colors**: 
  - Primary: #6366f1 (Indigo)
  - Secondary: #8b5cf6 (Purple)
  - Text: #ffffff (White)
  - Background: #0f172a (Dark slate)

### Overlay Templates

```
┌─────────────────────────────┐
│                             │
│    [TITLE TEXT HERE]        │
│    [Subtitle text here]     │
│                             │
│  ┌───────────────────────┐  │
│  │                       │  │
│  │                       │  │
│  │    APP SCREENSHOT     │  │
│  │                       │  │
│  │                       │  │
│  └───────────────────────┘  │
│                             │
└─────────────────────────────┘
```

---

## Feature Graphic (Android)

**URL**: https://d64gsuwffb70l.cloudfront.net/6945ed0ba05f1477c272f404_1766203798694_bf6ccc8a.png

**Design Elements**:
- App icon prominently displayed
- Key feature highlights
- Tagline: "Communication Without Barriers"
- Gradient background (indigo to purple)

---

## App Preview Videos (Optional but Recommended)

### iOS App Preview
- **Duration**: 15-30 seconds
- **Resolution**: Match screenshot sizes
- **Content Flow**:
  1. App launch (2s)
  2. Speech-to-text demo (8s)
  3. Video call with captions (8s)
  4. Quick phrases (5s)
  5. End card with app icon (2s)

### Google Play Promo Video
- **Duration**: 30 seconds - 2 minutes
- **Resolution**: 1920x1080 (landscape) or 1080x1920 (portrait)
- **YouTube hosting required**

---

## Screenshot Generation Tools

### Recommended Tools
1. **Figma** - Design screenshot frames and overlays
2. **Rotato** - 3D device mockups
3. **Screenshots Pro** - Automated screenshot framing
4. **AppLaunchpad** - Quick screenshot generator

### Device Frame Resources
- Apple Design Resources: https://developer.apple.com/design/resources/
- Android Device Art Generator: https://developer.android.com/distribute/marketing-tools/device-art-generator

---

## Localization Notes

When localizing screenshots:
1. Translate all text overlays
2. Show localized app UI in screenshots
3. Use culturally appropriate imagery
4. Maintain consistent design across languages

### Priority Languages for Screenshots
1. English (US)
2. Spanish
3. French
4. German
5. Japanese
