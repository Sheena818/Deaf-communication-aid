# Deaf Communication Aid - Native Mobile App Setup Guide

This guide covers how to convert the Deaf Communication Aid web app into native mobile apps for iOS App Store and Google Play Store using Capacitor.

## Why Capacitor?

Capacitor is the recommended approach because:
- **Reuses existing codebase**: Your React/TypeScript code works as-is
- **Native performance**: Access to native APIs (camera, microphone, notifications)
- **Single codebase**: Maintain one codebase for web, iOS, and Android
- **Easy updates**: Update web code without app store resubmission for most changes

## Prerequisites

### Development Environment

1. **Node.js** (v18 or higher)
2. **npm** or **yarn**
3. **For iOS**: 
   - macOS computer
   - Xcode 15+ (from Mac App Store)
   - Apple Developer Account ($99/year)
   - CocoaPods (`sudo gem install cocoapods`)
4. **For Android**:
   - Android Studio (latest)
   - Android SDK
   - Google Play Developer Account ($25 one-time)
   - Java JDK 17+

## Step 1: Install Capacitor

```bash
# Install Capacitor core and CLI
npm install @capacitor/core @capacitor/cli

# Initialize Capacitor in your project
npx cap init "Deaf Communication Aid" "com.deafcomm.app" --web-dir dist

# Install platform-specific packages
npm install @capacitor/ios @capacitor/android

# Install essential plugins
npm install @capacitor/camera @capacitor/microphone @capacitor/haptics
npm install @capacitor/push-notifications @capacitor/local-notifications
npm install @capacitor/speech-recognition @capacitor/text-to-speech
npm install @capacitor/screen-reader @capacitor/preferences
```

## Step 2: Configure Capacitor

Create/update `capacitor.config.ts`:

```typescript
import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.deafcomm.app',
  appName: 'Deaf Communication Aid',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 2000,
      backgroundColor: '#0f172a',
      androidSplashResourceName: 'splash',
      showSpinner: false
    },
    PushNotifications: {
      presentationOptions: ['badge', 'sound', 'alert']
    },
    Keyboard: {
      resize: 'body',
      resizeOnFullScreen: true
    }
  },
  ios: {
    contentInset: 'automatic',
    preferredContentMode: 'mobile',
    scheme: 'DeafComm'
  },
  android: {
    allowMixedContent: true,
    captureInput: true,
    webContentsDebuggingEnabled: false
  }
};

export default config;
```

## Step 3: Build and Add Platforms

```bash
# Build the web app first
npm run build

# Add iOS platform
npx cap add ios

# Add Android platform  
npx cap add android

# Sync web code to native projects
npx cap sync
```

## Step 4: Configure iOS Project

### Open in Xcode
```bash
npx cap open ios
```

### Required Permissions (Info.plist)
Add these to `ios/App/App/Info.plist`:

```xml
<key>NSCameraUsageDescription</key>
<string>Camera access is needed for video calls to communicate with others</string>

<key>NSMicrophoneUsageDescription</key>
<string>Microphone access enables speech-to-text transcription for deaf users</string>

<key>NSSpeechRecognitionUsageDescription</key>
<string>Speech recognition converts spoken words to text for deaf users</string>

<key>NSPhotoLibraryUsageDescription</key>
<string>Photo library access allows sharing images during conversations</string>

<key>UIBackgroundModes</key>
<array>
    <string>audio</string>
    <string>voip</string>
    <string>fetch</string>
    <string>remote-notification</string>
</array>

<key>ITSAppUsesNonExemptEncryption</key>
<false/>

<key>UIRequiresFullScreen</key>
<true/>

<key>UISupportedInterfaceOrientations</key>
<array>
    <string>UIInterfaceOrientationPortrait</string>
    <string>UIInterfaceOrientationLandscapeLeft</string>
    <string>UIInterfaceOrientationLandscapeRight</string>
</array>
```

### Accessibility Configuration
Add to Info.plist for accessibility features:

```xml
<key>UIAccessibilityPerformEscapeAction</key>
<true/>

<key>UIAccessibilitySpeakScreenEnabled</key>
<true/>
```

## Step 5: Configure Android Project

### Open in Android Studio
```bash
npx cap open android
```

### Required Permissions (AndroidManifest.xml)
Add to `android/app/src/main/AndroidManifest.xml`:

```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.CAMERA" />
<uses-permission android:name="android.permission.RECORD_AUDIO" />
<uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />
<uses-permission android:name="android.permission.VIBRATE" />
<uses-permission android:name="android.permission.WAKE_LOCK" />
<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />

<uses-feature android:name="android.hardware.camera" android:required="false" />
<uses-feature android:name="android.hardware.camera.autofocus" android:required="false" />
<uses-feature android:name="android.hardware.microphone" android:required="false" />
```

### Gradle Configuration
Update `android/app/build.gradle`:

```gradle
android {
    compileSdkVersion 34
    
    defaultConfig {
        applicationId "com.deafcomm.app"
        minSdkVersion 24
        targetSdkVersion 34
        versionCode 1
        versionName "1.0.0"
    }
}
```

## Step 6: App Icons and Splash Screens

### iOS Icons
Place icons in `ios/App/App/Assets.xcassets/AppIcon.appiconset/`:
- 20x20, 29x29, 40x40, 60x60, 76x76, 83.5x83.5, 1024x1024 (all @1x, @2x, @3x)

### Android Icons
Place icons in `android/app/src/main/res/`:
- `mipmap-mdpi/ic_launcher.png` (48x48)
- `mipmap-hdpi/ic_launcher.png` (72x72)
- `mipmap-xhdpi/ic_launcher.png` (96x96)
- `mipmap-xxhdpi/ic_launcher.png` (144x144)
- `mipmap-xxxhdpi/ic_launcher.png` (192x192)

### Splash Screen
Use `@capacitor/splash-screen` plugin with custom images.

## Step 7: Build for Release

### iOS Release Build
```bash
# Sync latest changes
npx cap sync ios

# Open Xcode
npx cap open ios

# In Xcode:
# 1. Select "Any iOS Device" as target
# 2. Product > Archive
# 3. Distribute App > App Store Connect
```

### Android Release Build
```bash
# Sync latest changes
npx cap sync android

# Generate signed APK/AAB
cd android
./gradlew bundleRelease

# Output: android/app/build/outputs/bundle/release/app-release.aab
```

## Step 8: App Store Submission

See the following files for complete submission details:
- `APP_STORE_METADATA.md` - App descriptions and keywords
- `ACCESSIBILITY_COMPLIANCE.md` - Accessibility review requirements
- `SCREENSHOTS.md` - Screenshot specifications

## Updating the App

```bash
# Make changes to web code
npm run build

# Sync to native projects
npx cap sync

# For minor updates (no native changes):
# - iOS: Can use OTA updates with Capgo/Appflow
# - Android: Can use in-app updates API

# For major updates:
# - Rebuild and resubmit to app stores
```

## Troubleshooting

### Common Issues

1. **Build fails on iOS**: Run `pod install` in `ios/App/`
2. **Android build fails**: Sync Gradle files in Android Studio
3. **Permissions not working**: Check native permission configs
4. **Camera/Mic not working**: Ensure HTTPS in production

### Debug Mode
```bash
# iOS
npx cap run ios --livereload

# Android
npx cap run android --livereload
```

## Support

For issues specific to:
- **Capacitor**: https://capacitorjs.com/docs
- **iOS Development**: https://developer.apple.com/documentation
- **Android Development**: https://developer.android.com/docs
